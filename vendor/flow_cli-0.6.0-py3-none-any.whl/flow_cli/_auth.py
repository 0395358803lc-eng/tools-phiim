"""Cookie auth - parse, validate, fetch bearer token."""

from __future__ import annotations

import json
import time
from typing import Any

import requests

from flow_cli._exceptions import AuthError, SessionExpiredError
from flow_cli._storage import (
    load_config,
    load_cookies_file,
    parse_cookie_string,
    save_config,
    save_cookies,
)

# Endpoints discovered via reverse engineering (adapter-provided)
from flow_cli.adapters import current_adapter

_adapter = current_adapter()
AUTH_ENDPOINT = _adapter.endpoints.auth_session
TRPC_HISTORY_URL = _adapter.endpoints.history
TRPC_PROJECT_CREATE = _adapter.endpoints.project_create

DEFAULT_HEADERS = {
    "Origin": "https://labs.google",
    "Referer": "https://labs.google/",
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    ),
    "Content-Type": "application/json",
    "Accept": "*/*",
    "Accept-Language": "en-US,en;q=0.9,vi;q=0.8",
}

# Valid cookie names that prove login (subset)
REQUIRED_COOKIE_HINTS = [
    "__Secure-1PSID",
    "1PSID",
    "__Secure-1PSIDTS",
    "HSID",
    "SSID",
    "APISID",
    "SAPISID",
]


def build_cookie_header(cookies: dict[str, str]) -> str:
    return "; ".join(f"{k}={v}" for k, v in cookies.items())


def extract_csrf_token(cookies: dict[str, str]) -> str | None:
    for k, v in cookies.items():
        if "csrf-token" in k.lower():
            # format often "token|hash"
            if "|" in v:
                return v.split("|")[0]
            return v
    return None


def extract_authuser(cookies: dict[str, str]) -> str:
    # Try to find authuser from cookies or default 0
    return "0"


def build_headers(cookies: dict[str, str], bearer: str | None = None) -> dict[str, str]:
    headers = dict(DEFAULT_HEADERS)
    headers["Cookie"] = build_cookie_header(cookies)
    headers["x-goog-authuser"] = extract_authuser(cookies)
    csrf = extract_csrf_token(cookies)
    if csrf:
        headers["x-csrf-token"] = csrf
        headers["x-next-auth-csrf-token"] = csrf
    if bearer:
        headers["Authorization"] = (
            f"Bearer {bearer}" if not bearer.startswith("Bearer ") else bearer
        )
    return headers


def fetch_session_token(cookies: dict[str, str], timeout: int = 15) -> str | None:
    """Try to fetch bearer token from labs.google auth/session.
    Returns access_token or None if endpoint not applicable.
    """
    headers = build_headers(cookies)
    try:
        resp = requests.get(AUTH_ENDPOINT, headers=headers, cookies=cookies, timeout=timeout)
        if resp.status_code == 200:
            data = resp.json()
            # Try multiple possible keys
            for key in ["access_token", "accessToken", "token", "id_token"]:
                if data.get(key):
                    return str(data[key])
            # Nested
            if isinstance(data.get("result"), dict):
                for key in ["access_token", "accessToken"]:
                    if data["result"].get(key):
                        return str(data["result"][key])
            # Some deployments return {"user": {"accessToken": ...}}
            if isinstance(data.get("user"), dict) and data["user"].get("accessToken"):
                return str(data["user"]["accessToken"])
        # Fallback: try to sniff SAPISIDHASH approach (for aisandbox-pa)
        # Not needed for tRPC but useful for direct Google API
    except Exception:
        pass
    return None


def validate_cookies(
    cookies: dict[str, str], timeout: int = 15
) -> tuple[bool, str, dict[str, Any] | None]:
    """Validate cookies by calling fetchUserHistoryDirectly (read-only tRPC).
    Returns (is_valid, message, raw_json).
    """
    if not cookies:
        return False, "No cookies provided", None
    # Quick hint check - warn if no known Google auth cookies
    has_hint = any(h in cookies for h in REQUIRED_COOKIE_HINTS)
    if not has_hint:
        # Still try - maybe export is incomplete but could still work
        pass

    bearer = fetch_session_token(cookies, timeout=timeout)
    headers = build_headers(cookies, bearer=bearer)

    # Use tRPC history as validation - safe read-only
    params = {
        "input": json.dumps(
            {
                "json": {
                    "type": "PINHOLE",
                    "pageSize": 1,
                    "responseScope": "RESPONSE_SCOPE_UNSPECIFIED",
                    "cursor": None,
                },
                "meta": {"values": {"cursor": ["undefined"]}},
            }
        )
    }
    try:
        resp = requests.get(
            TRPC_HISTORY_URL, headers=headers, params=params, cookies=cookies, timeout=timeout
        )
        if resp.status_code == 200:
            try:
                data = resp.json()
                return True, "Cookies valid - API connection verified", data
            except Exception:
                return True, "HTTP 200 but non-JSON response (cookies likely valid)", None
        elif resp.status_code == 401:
            return (
                False,
                "Authentication failed (401) - cookies expired or incomplete. "
                "Re-export ALL cookies from labs.google",
                None,
            )
        elif resp.status_code == 403:
            return (
                False,
                "Forbidden (403) - check Google AI Pro/Ultra subscription or re-login. "
                "API returned 403",
                None,
            )
        else:
            # Some 400 are still auth ok but bad params - treat as valid-ish
            body = resp.text[:500]
            return False, f"Validation returned HTTP {resp.status_code}: {body}", None
    except requests.exceptions.RequestException as e:
        return False, f"Network error during validation: {e}", None


def save_cookies_from_input(
    cookie_str: str | None = None,
    cookie_file: str | None = None,
    cookie_dict: dict[str, str] | None = None,
) -> dict[str, str]:
    """Parse cookies from various inputs and persist."""
    cookies: dict[str, str] = {}
    raw_list: list[dict[str, Any]] | None = None
    if cookie_dict:
        cookies.update(cookie_dict)
    if cookie_str:
        cookies.update(parse_cookie_string(cookie_str))
    if cookie_file:
        from pathlib import Path

        from flow_cli._storage import load_cookies_file, parse_netscape_file

        p = Path(cookie_file)
        if not p.exists():
            raise AuthError(f"Cookie file not found: {cookie_file}")
        # Try to preserve raw list with domain attrs
        try:
            text = p.read_text(encoding="utf-8")
            # Try JSON list
            try:
                raw_json = json.loads(text)
                if (
                    isinstance(raw_json, list)
                    and raw_json
                    and isinstance(raw_json[0], dict)
                    and "name" in raw_json[0]
                ):
                    raw_list = raw_json
                    # Also populate dict
                    for item in raw_json:
                        if "name" in item and "value" in item:
                            cookies[str(item["name"])] = str(item["value"])
                else:
                    loaded = load_cookies_file(p)
                    if loaded:
                        cookies.update(loaded)
                    # Try to get raw list if available
                    if isinstance(raw_json, list):
                        raw_list = raw_json if raw_json and isinstance(raw_json[0], dict) else None
            except json.JSONDecodeError:
                # Try netscape
                netscape = parse_netscape_file(text)
                if netscape:
                    cookies.update(netscape)
                    # Reconstruct raw list from netscape text for browser
                    raw_list = []
                    for line in text.splitlines():
                        if line.strip().startswith("#") and "HttpOnly" not in line:
                            continue
                        line2 = line.strip()
                        if line2.startswith("#HttpOnly_"):
                            line2 = line2[len("#HttpOnly_") :]
                        elif line2.startswith("#"):
                            continue
                        parts = line2.split("\t")
                        if len(parts) >= 7:
                            raw_list.append(
                                {
                                    "domain": parts[0],
                                    "name": parts[5],
                                    "value": parts[6],
                                    "path": parts[2],
                                    "secure": parts[3] == "TRUE",
                                    "httpOnly": "HttpOnly" in line,
                                    "sameSite": None,
                                }
                            )
                else:
                    cookies.update(parse_cookie_string(text))
        except Exception:
            # Fallback
            loaded = load_cookies_file(p)
            if loaded:
                cookies.update(loaded)
    if not cookies:
        raise AuthError("No valid cookies found. Provide --cookie or --cookie-file")
    # Persist - preserve raw_list if available for Playwright
    from flow_cli._storage import save_cookies as _save_cookies

    if raw_list is not None:
        _save_cookies(cookies, raw_list=raw_list)
    else:
        save_cookies(cookies)
    # Also store bearer if we can fetch it
    bearer = fetch_session_token(cookies)
    cfg = load_config()
    cfg["last_login"] = int(time.time())
    cfg["cookie_count"] = len(cookies)
    if bearer:
        cfg["has_bearer"] = True
        # Don't store bearer long-term lightly, but keep hint
    save_config(cfg)
    return cookies


def load_saved_cookies() -> dict[str, str]:
    cookies = load_cookies_file()
    if not cookies:
        raise AuthError(
            'No saved cookies found. Run: flow login --cookie "..."  '
            "or flow login --cookie-file cookies.json\n"
            "How to get cookies: F12 > Application > Cookies > https://labs.google > Copy all, "
            "or use Cookie-Editor extension > Export as JSON"
        )
    return cookies


def ensure_valid_session(
    cookies: dict[str, str] | None = None, timeout: int = 15
) -> dict[str, str]:
    cookies = cookies or load_saved_cookies()
    ok, msg, _ = validate_cookies(cookies, timeout=timeout)
    if not ok:
        if "401" in msg or "expired" in msg.lower():
            raise SessionExpiredError(msg)
        raise AuthError(msg)
    return cookies
