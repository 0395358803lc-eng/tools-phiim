"""Adapter versioning - isolates Google Flow upstream dependencies.

When Google changes endpoints, project tool names, UI selectors or response
schemas, only the matching adapter + fixtures need to be updated instead of
editing code scattered across the package.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ProjectToolMapping:
    video: str
    image: str

    def tool_for_media_type(self, media_type: str) -> str:
        mt = media_type.lower()
        if mt == "video":
            return self.video
        if mt == "image":
            return self.image
        raise ValueError(f"Unknown media type: {media_type!r}")


@dataclass(frozen=True)
class Endpoints:
    trpc_base: str
    history: str
    project_create: str
    project_list: str
    credits: str
    auth_session: str
    aisandbox_base: str


class FlowAdapter(ABC):
    """Interface implemented by concrete upstream adapters."""

    name: str = "base"

    @property
    @abstractmethod
    def endpoints(self) -> Endpoints: ...

    @property
    @abstractmethod
    def project_tools(self) -> ProjectToolMapping: ...

    @property
    @abstractmethod
    def history_type_params(self) -> dict[str, str]:
        """Map normalized media type (video/image) to history 'type' param."""
        ...

    @abstractmethod
    def parse_generation_response(self, body: dict[str, Any]) -> dict[str, Any]:
        """Extract operation_name / media_name / images from a generation response.

        Returns a dict with keys: operation_name (Optional[str]),
        media_name (Optional[str]), images (list[dict]).
        """
        ...

    @abstractmethod
    def unwrap_trpc(self, data: dict[str, Any]) -> dict[str, Any] | None:
        """Unwrap a tRPC envelope to its inner dict, or None."""
        ...
