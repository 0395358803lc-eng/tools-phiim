"""Concrete adapter for the current Google Flow web API/UI profile.

This is versioned so that when upstream changes, a new adapter (e.g.
flow_web_v2) plus fixtures are added without touching core logic.
"""

from __future__ import annotations

from typing import Any

from flow_cli.adapters.base import Endpoints, FlowAdapter, ProjectToolMapping


class FlowWebV1Adapter(FlowAdapter):
    name = "flow_web_v1"

    # Public Firebase browser API key for the gweb-ai-sandbox-prod project, as
    # embedded in the Flow web client and sent by the app itself (see
    # aisandbox-pa.googleapis.com/v1/credits?key=...). It is not a secret
    # credential; it is required as a query param by the credits endpoint.
    AISANDBOX_API_KEY = "AIzaSyBtrm0o5ab1c-Ec8ZuLcGt3oJAA5VWt3pY"

    @property
    def endpoints(self) -> Endpoints:
        return Endpoints(
            trpc_base="https://labs.google/fx/api/trpc",
            history="https://labs.google/fx/api/trpc/media.fetchUserHistoryDirectly",
            project_create="https://labs.google/fx/api/trpc/project.createProject",
            project_list="https://labs.google/fx/api/trpc/project.searchUserProjects",
            credits=(
                f"https://aisandbox-pa.googleapis.com/v1/credits?key={self.AISANDBOX_API_KEY}"
            ),
            auth_session="https://labs.google/fx/api/auth/session",
            aisandbox_base="https://aisandbox-pa.googleapis.com",
        )

    @property
    def project_tools(self) -> ProjectToolMapping:
        return ProjectToolMapping(video="VIDEO_FX", image="ASSET_MANAGER")

    @property
    def history_type_params(self) -> dict[str, str]:
        return {"video": "PINHOLE", "image": "ASSET_MANAGER"}

    def unwrap_trpc(self, data: dict[str, Any]) -> dict[str, Any] | None:
        try:
            inner = data["result"]["data"]["json"]
            if isinstance(inner, dict):
                return inner
        except Exception:
            pass
        try:
            return data.get("result", {}).get("data", {}).get("json", None)
        except Exception:
            return None

    def parse_generation_response(self, body: dict[str, Any]) -> dict[str, Any]:
        """Extract distinct upstream identifiers from a generation response."""
        operation_name: str | None = None
        workflow_id: str | None = None
        media_id: str | None = None
        resource_name: str | None = None
        images: list[dict[str, Any]] = []

        operation = body.get("operation")
        if isinstance(operation, dict):
            operation_name = operation.get("name")
        if not operation_name and isinstance(body.get("operations"), list) and body["operations"]:
            first_operation = body["operations"][0]
            if isinstance(first_operation, dict):
                operation_name = first_operation.get("name")

        top_name = body.get("name")
        if isinstance(top_name, str):
            if top_name.startswith("operations/"):
                operation_name = operation_name or top_name
            else:
                resource_name = top_name

        media_generation_id = body.get("mediaGenerationId")
        if isinstance(media_generation_id, dict):
            media_id = media_generation_id.get("mediaId") or media_generation_id.get("id")
            resource_name = resource_name or media_generation_id.get("name")
        elif media_generation_id:
            media_id = str(media_generation_id)

        media_id = media_id or body.get("mediaId")
        workflow_id = body.get("workflowId")
        resource_name = resource_name or body.get("resourceName")

        media_items = body.get("media")
        if isinstance(media_items, list) and media_items and isinstance(media_items[0], dict):
            first_media = media_items[0]
            nested_generation = first_media.get("mediaGenerationId")
            if isinstance(nested_generation, dict):
                media_id = (
                    media_id or nested_generation.get("mediaId") or nested_generation.get("id")
                )
            media_id = media_id or first_media.get("mediaId") or first_media.get("id")
            workflow_id = workflow_id or first_media.get("workflowId")
            resource_name = resource_name or first_media.get("name")

        workflows = body.get("workflows")
        if isinstance(workflows, list) and workflows and isinstance(workflows[0], dict):
            first_workflow = workflows[0]
            workflow_id = (
                workflow_id
                or first_workflow.get("workflowId")
                or first_workflow.get("id")
                or first_workflow.get("name")
            )
            resource_name = resource_name or first_workflow.get("name")

        if resource_name and str(resource_name).startswith("workflows/"):
            workflow_id = workflow_id or resource_name

        for item in body.get("media", []) if isinstance(body.get("media"), list) else []:
            if not isinstance(item, dict):
                continue
            img_data = None
            if isinstance(item.get("image"), dict):
                img_data = item["image"].get("generatedImage") or item["image"]
            elif isinstance(item.get("generatedImage"), dict):
                img_data = item["generatedImage"]
            else:
                img_data = item
            if isinstance(img_data, dict):
                images.append(img_data)

        return {
            "operation_name": operation_name,
            "workflow_id": workflow_id,
            "media_id": media_id,
            "resource_name": resource_name,
            # Backward-compatible display field; never use this to populate all IDs.
            "media_name": resource_name or media_id or workflow_id,
            "images": images,
        }


_DEFAULT_ADAPTER = FlowWebV1Adapter()


def get_adapter(name: str | None = None) -> FlowAdapter:
    """Return the adapter for the given version profile, defaulting to current."""
    if name is None or name == FlowWebV1Adapter.name:
        return _DEFAULT_ADAPTER
    raise ValueError(f"Unknown adapter: {name!r}")


def current_adapter() -> FlowAdapter:
    return _DEFAULT_ADAPTER
