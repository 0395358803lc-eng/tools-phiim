"""Debug artifact collection - evidence when upstream changes.

Writes to:
    artifacts/<timestamp>-<job-id>/
      screenshot.png
      page.html
      console.jsonl
      network-summary.json
"""

from __future__ import annotations

import json
import re
import time
from pathlib import Path
from typing import Any

from flow_cli._logging import (
    json_dumps_redacted,
    redact_body,
    redact_headers,
    scrub_string_secrets,
)

# Cookie names whose values embedded in HTML must be scrubbed (not just the header).
_SENSITIVE_HTML_KEYS = re.compile(
    r"\b(SID|SSID|HSID|APISID|SAPISID|PSID|__Secure-[A-Za-z0-9_]+|"
    r"[A-Za-z0-9_]*[Tt]oken[A-Za-z0-9_]*|csrf[A-Za-z0-9_]*|"
    r"authorization|bearer)\b",
    re.IGNORECASE,
)


class ArtifactCollector:
    def __init__(self, root: Path, job_id: str):
        self.root = Path(root) / f"{int(time.time() * 1000)}-{job_id or 'job'}"
        self.enabled = True

    def ensure_dir(self) -> Path:
        self.root.mkdir(parents=True, exist_ok=True)
        return self.root

    async def capture_page(self, page: Any) -> None:
        try:
            d = self.ensure_dir()
            await page.screenshot(path=str(d / "screenshot.png"))
        except Exception:
            pass

    async def capture_html(self, page: Any) -> None:
        try:
            d = self.ensure_dir()
            html = await page.content()
            (d / "page.html").write_text(_scrub_html(html), encoding="utf-8")
        except Exception:
            pass

    def write_console(self, messages: list[dict[str, Any]]) -> None:
        try:
            d = self.ensure_dir()
            with (d / "console.jsonl").open("w", encoding="utf-8") as f:
                for m in messages:
                    f.write(json_dumps_redacted(m) + "\n")
        except Exception:
            pass

    def write_network_summary(self, entries: list[dict[str, Any]]) -> None:
        try:
            d = self.ensure_dir()
            redacted = []
            for e in entries:
                entry = redact_body(dict(e))
                if "requestHead" in entry:
                    entry["requestHead"] = redact_headers(entry["requestHead"])
                if "responseHead" in entry:
                    entry["responseHead"] = redact_headers(entry["responseHead"])
                if "headers" in entry and isinstance(entry["headers"], dict):
                    entry["headers"] = redact_headers(entry["headers"])
                if "responseHeaders" in entry and isinstance(entry["responseHeaders"], dict):
                    entry["responseHeaders"] = redact_headers(entry["responseHeaders"])
                if "postData" in entry:
                    entry["postData"] = "[REDACTED]"
                redacted.append(entry)
            (d / "network-summary.json").write_text(
                json.dumps(redacted, ensure_ascii=False, indent=2, default=str),
                encoding="utf-8",
            )
        except Exception:
            pass


def _scrub_html(html: str) -> str:
    """Redact obvious secrets embedded in captured page HTML.

    Scrubs cookie values (name=value pairs for known sensitive names), bearer
    tokens and Authorization/Cookie header-like snippets. This is a best-effort
    pass; HTML is for diagnosis only and should never become a leak vector.
    """
    # name=value cookie pairs for sensitive names.
    html = re.sub(
        r"(\b(?:SID|SSID|HSID|APISID|SAPISID|PSID|__Secure-[A-Za-z0-9_]+|"
        r"[A-Za-z0-9_]*[Tt]oken[A-Za-z0-9_]*|csrf[A-Za-z0-9_]*)\s*=\s*)[^\"'\s&;,]{6,}",
        r"\1[REDACTED]",
        html,
    )
    # Authorization / Bearer / Cookie header-like snippets.
    html = re.sub(
        r"(\b(?:Authorization|Bearer|Cookie)\s*[:=]\s*)[A-Za-z0-9._~+/=-]{8,}",
        r"\1[REDACTED]",
        html,
        flags=re.IGNORECASE,
    )
    return scrub_string_secrets(html)
