"""Media download helpers - atomic download with media verification."""

from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any
from urllib.parse import urljoin, urlparse

import requests
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeRemainingColumn,
)

from flow_cli._exceptions import DownloadError, MediaVerificationError

VIDEO_MAGIC_SIGNATURES = {
    b"\x00\x00\x00\x18ftypmp4": "mp4",
    b"\x00\x00\x00\x20ftyp": "mp4",
    b"\x00\x00\x00\x1cftyp": "mp4",
    b"RIFF": "webm/avi",
    b"\x1a\x45\xdf\xa3": "webm/mkv",
}
IMAGE_MAGIC_SIGNATURES = {
    b"\x89PNG\r\n\x1a\n": "png",
    b"\xff\xd8\xff": "jpeg",
    b"GIF87a": "gif",
    b"GIF89a": "gif",
    b"RIFF": "webp",
}


def detect_container(prefix: bytes) -> str | None:
    # WebP is RIFF....WEBP - disambiguate before treating RIFF as webm/avi.
    if prefix[:4] == b"RIFF" and prefix[8:12] == b"WEBP":
        return "webp"
    for sig, kind in VIDEO_MAGIC_SIGNATURES.items():
        if prefix.startswith(sig):
            return kind
    for sig, kind in IMAGE_MAGIC_SIGNATURES.items():
        if prefix.startswith(sig):
            return kind
    # JPEG/PNG at tail
    if prefix[:8].startswith(b"\x89PNG"):
        return "png"
    if prefix[:3] == b"\xff\xd8\xff":
        return "jpeg"
    return None


def looks_like_html(prefix: bytes, text_head: str = "") -> bool:
    head = prefix[:16].strip().lstrip(b"\xef\xbb\xbf").lower()
    if head.startswith(b"<!doctype") or head.startswith(b"<html"):
        return True
    if text_head and ("<!DOCTYPE" in text_head or "<html" in text_head.lower()):
        return True
    return False


def verify_downloaded(path: Path, kind: str = "video") -> None:
    """Verify a downloaded file is a real media file, not an HTML/error page.

    Never infers validity from file size alone.
    """
    if not path.exists() or path.stat().st_size == 0:
        raise MediaVerificationError(f"Downloaded file missing or empty: {path}")

    with open(path, "rb") as f:
        head = f.read(64)
    text_head = ""
    try:
        text_head = head.decode("utf-8", errors="ignore")[:64]
    except Exception:
        pass

    if looks_like_html(head, text_head):
        raise MediaVerificationError(f"Downloaded file is HTML (likely an error page): {path}")

    container = detect_container(head)
    if container is None:
        raise MediaVerificationError(
            f"Downloaded file does not match a known media container (got {path})"
        )

    if kind == "video" and container not in ("mp4", "webm", "webm/mkv"):
        raise MediaVerificationError(f"Expected video container but detected {container!r}: {path}")
    if kind == "image" and container not in ("png", "jpeg", "gif", "webp"):
        raise MediaVerificationError(f"Expected image container but detected {container!r}: {path}")


def file_sha1(path: Path) -> str:
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


_EXT_BY_CONTAINER = {
    "png": "png",
    "jpeg": "jpg",
    "gif": "gif",
    "webp": "webp",
    "mp4": "mp4",
    "webm": "webm",
    "webm/mkv": "mkv",
}


def _extension_hint(content_type: str) -> str | None:
    ct = content_type.lower().split(";")[0].strip()
    return {
        "image/png": "png",
        "image/jpeg": "jpg",
        "image/gif": "gif",
        "image/webp": "webp",
        "video/mp4": "mp4",
        "video/webm": "webm",
    }.get(ct)


def _container_of(path: Path) -> str | None:
    try:
        with open(path, "rb") as f:
            return detect_container(f.read(64))
    except Exception:
        return None


def _correct_extension(dest: Path, container: str | None, content_type: str) -> Path:
    """Return `dest`, relabeled to the real media extension when mismatched.

    A file named `.png` that is actually a JPEG keeps a misleading extension,
    so after download the extension is fixed from magic bytes (preferred) or the
    Content-Type header.
    """
    ext = _EXT_BY_CONTAINER.get(container or "") or _extension_hint(content_type)
    if not ext:
        return dest
    if dest.suffix.lower().lstrip(".") == ext:
        return dest
    return dest.with_name(dest.stem + f".{ext}")


def download_file(
    url: str,
    dest: str | Path,
    cookies: dict[str, str] | None = None,
    headers: dict[str, str] | None = None,
    chunk_size: int = 8192,
    kind: str = "video",
    verify: bool = True,
    allowed_hosts: set[str] | None = None,
) -> Path:
    """Download to a `.part` temporary file, verify, then atomically rename.

    If the destination already exists and verifies as valid media, it is reused
    instead of re-downloading (arbitrary signed URLs have no reliable remote
    checksum to compare, so the existing file's validity is checked instead).
    The `.part` file is removed on any failure.
    """

    def host_allowed(candidate: str) -> bool:
        parsed = urlparse(candidate)
        hostname = (parsed.hostname or "").lower().rstrip(".")
        return parsed.scheme == "https" and any(
            hostname == allowed or hostname.endswith(f".{allowed}")
            for allowed in (allowed_hosts or set())
        )

    if allowed_hosts is not None and not host_allowed(url):
        raise DownloadError("Download URL must use HTTPS and an allowed host")

    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)

    # Reuse an existing, verified destination instead of re-downloading.
    if dest.exists() and dest.stat().st_size > 0:
        if verify:
            try:
                verify_downloaded(dest, kind=kind)
                return dest
            except MediaVerificationError:
                pass  # existing file is invalid - re-download
        else:
            return dest

    part = dest.with_name(dest.name + ".part")
    part.parent.mkdir(parents=True, exist_ok=True)
    try:
        request_url = url
        r = requests.get(
            request_url,
            stream=True,
            cookies=cookies,
            headers=headers,
            timeout=60,
            allow_redirects=allowed_hosts is None,
        )
        if allowed_hosts is not None:
            for _redirect in range(5):
                if r.status_code not in {301, 302, 303, 307, 308}:
                    break
                location = r.headers.get("location")
                if not location:
                    break
                redirect_url = urljoin(getattr(r, "url", request_url), location)
                if not host_allowed(redirect_url):
                    r.close()
                    raise DownloadError("Download redirect left the allowed host list")
                r.close()
                request_url = redirect_url
                r = requests.get(
                    request_url,
                    stream=True,
                    cookies=cookies,
                    headers=headers,
                    timeout=60,
                    allow_redirects=False,
                )
            else:
                r.close()
                raise DownloadError("Download exceeded the redirect limit")
        with r:
            r.raise_for_status()
            if allowed_hosts is not None and not host_allowed(r.url):
                raise DownloadError("Download redirect left the allowed host list")
            content_type = r.headers.get("content-type", "")
            if "text/html" in content_type.lower():
                raise MediaVerificationError(f"Server returned HTML content-type for {url}")
            total = int(r.headers.get("content-length", 0))
            progress = Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                DownloadColumn(),
                TimeRemainingColumn(),
            )
            task_desc = f"Downloading {dest.name}"
            with progress:
                task = progress.add_task(task_desc, total=total if total else None)
                with open(part, "wb") as f:
                    for chunk in r.iter_content(chunk_size=chunk_size):
                        if chunk:
                            f.write(chunk)
                            progress.update(task, advance=len(chunk))

        final_dest = dest
        if verify:
            verify_downloaded(part, kind=kind)
            final_dest = _correct_extension(dest, _container_of(part), content_type)
        os.replace(part, final_dest)
        return final_dest
    finally:
        # Clean up the partial download on any failure (only the exact .part path).
        if part.exists():
            try:
                part.unlink()
            except Exception:
                pass


def infer_filename(url: str, fallback: str = "output.mp4") -> str:
    parsed = urlparse(url)
    name = os.path.basename(parsed.path)
    if name and "." in name:
        return name
    return fallback


def download_media_from_workflow(
    workflow: dict[str, Any],
    dest_dir: str | Path,
    cookies: dict[str, str] | None = None,
    bearer: str | None = None,
    kind: str = "video",
) -> list[Path]:
    """Extract media URLs from workflow and download with verification."""
    from flow_cli._auth import build_headers, fetch_session_token

    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    urls: list[str] = []
    media_name = (
        workflow.get("name") or workflow.get("media", {}).get("name") or workflow.get("workflowId")
    )
    mlower = str(workflow).lower()
    is_video = (
        "video" in mlower
        or "PINHOLE" in mlower
        or workflow.get("media", {}).get("video") is not None
    )
    if media_name and is_video:
        try:
            if cookies is not None:
                b = bearer or fetch_session_token(cookies)
                headers = build_headers(cookies, b)
                headers["Accept"] = "*/*"
                short_name = media_name.split("/")[-1] if "/" in str(media_name) else media_name
                dl_url = (
                    f"https://labs.google/fx/api/trpc/media.getMediaUrlRedirect?name={short_name}"
                )
                headers["Referer"] = "https://labs.google/fx/tools/flow"
                urls.append(dl_url)
        except Exception:
            pass
    media = workflow.get("media", {})
    for key in ["fifeUrl", "url", "downloadUrl", "mediaUrl", "videoUrl", "imageUrl"]:
        if media.get(key):
            urls.append(media[key])
        if isinstance(media.get("video"), dict):
            for k in ["fifeUrl", "url", "downloadUrl"]:
                if media["video"].get(k):
                    urls.append(media["video"][k])
    for key in ["fifeUrl", "url", "downloadUrl"]:
        if workflow.get(key):
            urls.append(workflow[key])
    assets = workflow.get("mediaAssets") or workflow.get("assets") or []
    if isinstance(assets, list):
        for a in assets:
            if isinstance(a, dict):
                for k in ["fifeUrl", "url", "downloadUrl"]:
                    if a.get(k):
                        urls.append(a[k])
    try:
        raw_str = json.dumps(workflow)
        for m in re.findall(r"https://flow-content\.google[^\"']+", raw_str):
            urls.append(m)
    except Exception:
        pass

    urls = list(dict.fromkeys(urls))
    paths: list[Path] = []
    for i, url in enumerate(urls):
        ext = ".mp4" if is_video else ".png"
        if url.endswith(".mp4") or "video" in url:
            ext = ".mp4"
        elif url.endswith((".png", ".jpg", ".jpeg", ".webp")):
            ext = Path(url.split("?")[0]).suffix or ".png"
        fname = (
            f"flow_{str(media_name or workflow.get('name', 'media')).split('/')[-1][:12]}_{i}{ext}"
        )
        # Use unique filename with media/job ID.
        fname = f"flow_{str(media_name or 'media').replace('/', '_')[:20]}_{i}{ext}"
        dest = dest_dir / fname
        try:
            dl_headers = None
            if "media.getMediaUrlRedirect" in url and cookies is not None:
                b = bearer or fetch_session_token(cookies)
                dl_headers = build_headers(cookies, b)
                dl_headers["Accept"] = "*/*"
                dl_headers["Referer"] = "https://labs.google/fx/tools/flow"
            p = download_file(
                url,
                dest,
                cookies=cookies,
                headers=dl_headers,
                kind="video" if is_video else "image",
            )
            paths.append(p)
            if is_video and dest.suffix == ".mp4":
                break
        except DownloadError as e:
            print(f"Download verification failed for {url[:80]}: {e}")
        except Exception as e:
            print(f"Failed to download {url[:80]}: {e}")
    return paths
