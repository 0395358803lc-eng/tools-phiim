"""Custom exceptions for flow_cli.

Exit code mapping (see docs/KE_HOACH_HOAN_THIEN_DU_AN.md section 4):
    0  success
    2  invalid arguments
    3  authentication failed
    4  permission/subscription missing
    5  rate limited
    6  generation failed or rejected
    7  timeout
    8  upstream/API/UI changed
    9  download/verify file failed
"""

from __future__ import annotations


class FlowError(Exception):
    """Base exception."""

    exit_code: int = 1


class ConfigError(FlowError):
    """Config file error."""

    exit_code = 2


class UsageError(FlowError):
    """Invalid arguments / invalid parameters passed by caller."""

    exit_code = 2


class AuthError(FlowError):
    """Authentication failed - cookies invalid or expired."""

    exit_code = 3


class SessionExpiredError(AuthError):
    """Session expired, need re-login with fresh cookies."""

    exit_code = 3


class PermissionError2(FlowError):
    """No permission / subscription missing (HTTP 403)."""

    exit_code = 4


class RateLimitError(FlowError):
    """Rate limited by Google (HTTP 429)."""

    exit_code = 5


class GenerationError(FlowError):
    """Generation failed or rejected by the backend/policy."""

    exit_code = 6


class GenerationRejectedError(GenerationError):
    """Prompt or policy rejected generation request."""

    exit_code = 6


class GenerationFailedError(GenerationError):
    """Backend failed to generate media."""

    exit_code = 6


class GenerationTimeout(FlowError):
    """Generation polling timed out (job still running)."""

    exit_code = 7


class UpstreamChangedError(FlowError):
    """Endpoint / payload / selector / schema no longer matches upstream."""

    exit_code = 8


class DownloadError(FlowError):
    """Failed to download or verify a file."""

    exit_code = 9


class MediaVerificationError(DownloadError):
    """Downloaded file failed verification (magic bytes/container)."""

    exit_code = 9
