"""Structured logging + secret redaction.

All logs (including debug artifacts) must never leak cookies, bearer tokens,
csrf tokens, emails or sensitive request bodies.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any

import structlog

# Header/field names whose values must be redacted.
_SECRET_HEADERS = {
    "cookie",
    "set-cookie",
    "authorization",
    "x-csrf-token",
    "x-next-auth-csrf-token",
    "proxy-authorization",
    "x-goog-authuser",
}

# Cookie names that are sensitive (subset).
_SENSITIVE_COOKIE_NAMES = (
    "sid",
    "psid",
    "ssid",
    "hsid",
    "apisid",
    "sapisid",
    "tsid",
    "sapsidid",
    "referer",
    "csrf",
)

_REDACT = "[REDACTED]"

# Key names that always identify a secret value regardless of content.
_HARD_SECRET_KEY_RE = re.compile(
    r"(cookie|cookies|token|csrf|password|secret|authorization|sapisidhash)",
    re.IGNORECASE,
)

# Personally-identifying email field names (exact-ish: "email"/"user_email"/
# "account_email"/"email_address"). Balanced so boolean-ish favorites such as
# "email_notifications" are NOT blanked.
_EMAIL_KEY_RE = re.compile(r"^(?:user[._-]?)?(?:account[._-]?)?email(?:_address)?$", re.IGNORECASE)
_EMAIL_ADDRESS_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")

# Doctor / status metadata that holds only counts, booleans or non-secret names.
# These keys must NOT be blanket-redacted by key name alone — their values are
# still run through the value-level secret scrubber.
_SAFE_METADATA_KEYS = {
    "cookie_count",
    "cookie_names",
    "cookie_name",
    "cookies_path",
    "cookie_path",
    "has_cookies",
    "cookie_valid",
    "cookies_valid",
    "cookie_hints_present",
    "playwright_installed",
    "chromium_installed",
    "python_version",
    "flow_version",
    "adapter",
    "project_id",
}

# Value-level patterns. These scrub secrets that appear inside otherwise-innocent
# strings (e.g. an "error" or "url" field), regardless of the field's name.
_QUERY_TOKEN_RE = re.compile(
    r"(?i)([?&](?:token|sid|psid|ssid|hsid|sapisid|apisid|authuser|access_token|api_key)=)[^&#\s]+"
)
_COOKIE_PAIR_RE = re.compile(
    r"(?i)(\b(?:sid|psid|ssid|hsid|sapisid|apisid|sapsidid|authuser|csrf|token)=)[^,;&\s#]+"
)
_BEARER_RE = re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+\-/=]{6,}")
_AUTH_HEADER_LINE_RE = re.compile(
    r"(?i)((?:cookie|cookies?|authorization|proxy-authorization|x-csrf-token):[^\r\n]{0,80})"
)


def scrub_string_secrets(value: str) -> str:
    """Scrub secrets embedded anywhere inside a string (URLs, prose, bodies)."""
    value = _QUERY_TOKEN_RE.sub(lambda m: m.group(1) + _REDACT, value)
    value = _COOKIE_PAIR_RE.sub(lambda m: m.group(1) + _REDACT, value)
    value = _BEARER_RE.sub(_REDACT, value)
    value = _AUTH_HEADER_LINE_RE.sub(_REDACT, value)
    value = _EMAIL_ADDRESS_RE.sub(_REDACT, value)
    return value


def redact_value(value: Any) -> Any:
    """Redact a single value, scrubbing secrets embedded in strings."""
    if isinstance(value, str):
        return scrub_string_secrets(value)
    if isinstance(value, dict):
        return redact_dict_mut(dict(value))
    if isinstance(value, list):
        return [redact_value(item) for item in value]
    return value


def redact_dict_mut(data: dict[str, Any]) -> dict[str, Any]:
    """In-place redact of dict keys/values for headers or payloads."""
    for k, v in list(data.items()):
        lk = k.lower()
        if lk in _SAFE_METADATA_KEYS:
            data[k] = redact_value(v)
        elif _EMAIL_KEY_RE.match(lk):
            data[k] = _REDACT
        elif _HARD_SECRET_KEY_RE.search(lk):
            data[k] = _REDACT
        elif isinstance(v, dict) or isinstance(v, list):
            data[k] = redact_body(v)
        elif isinstance(v, str):
            data[k] = scrub_string_secrets(v)
    return data


def redact_headers(headers: dict[str, Any]) -> dict[str, Any]:
    """Return a redacted copy of request/response headers."""
    out: dict[str, Any] = {}
    for k, v in headers.items():
        out[k] = _REDACT if k.lower() in _SECRET_HEADERS else v
    return out


def redact_body(body: Any) -> Any:
    """Return a fully-redacted deep copy of a request/response body.

    The original object tree is never mutated (deep copy first).
    """
    import copy

    body = copy.deepcopy(body)
    if isinstance(body, dict):
        return redact_dict_mut(body)
    if isinstance(body, list):
        return [redact_body(item) for item in body]
    if isinstance(body, str):
        return scrub_string_secrets(body)
    return body


def _redact_processor(
    _logger: Any, _method_name: str, event_dict: dict[str, Any]
) -> dict[str, Any]:
    """Enforce redaction on every log event (cookies, tokens, csrf, auth)."""
    import copy

    out = copy.deepcopy(event_dict)
    if "event" in out:
        out["event"] = redact_body(out["event"])
    return redact_body(out)


def configure_logging(verbose: bool = False, json_output: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    processors: list[Any] = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        _redact_processor,
    ]
    if json_output:
        processors.append(structlog.processors.JSONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer())

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(level),
        cache_logger_on_first_use=True,
    )


def get_logger(name: str = "flow_cli"):
    return structlog.get_logger(name)


def json_dumps_redacted(obj: Any) -> str:
    """Serialize obj to JSON with secrets redacted."""
    return json.dumps(redact_body(obj), ensure_ascii=False, default=str)
