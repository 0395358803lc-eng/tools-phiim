"""Direct HTTP API layer - read-only ops via requests (no browser needed)."""

from __future__ import annotations

import json
import time
from typing import Any

import requests
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential_jitter,
)

from flow_cli._auth import build_headers, fetch_session_token
from flow_cli._exceptions import (
    AuthError,
    PermissionError2,
    RateLimitError,
    UpstreamChangedError,
)
from flow_cli.adapters import current_adapter


class FlowAPI:
    """Direct HTTP API - works with cookie auth, no browser."""

    def __init__(self, cookies: dict[str, str], timeout: int = 30):
        self.cookies = cookies
        self.timeout = timeout
        self.session = requests.Session()
        self.bearer = fetch_session_token(cookies, timeout=10)
        headers = build_headers(cookies, bearer=self.bearer)
        self.session.headers.update(headers)
        # Keep cookies in session jar too
        for k, v in cookies.items():
            self.session.cookies.set(k, v, domain=".google.com")
            self.session.cookies.set(k, v, domain="labs.google")

    # ---------- Response handling / classification ----------

    def _check_status(self, resp: requests.Response) -> None:
        if resp.status_code == 429:
            raise RateLimitError(f"Rate limited (429): {resp.text[:500]}")
        if resp.status_code == 401:
            raise AuthError(
                f"Auth failed (401): cookies expired. Re-login with fresh cookies. "
                f"Body: {resp.text[:300]}"
            )
        if resp.status_code == 403:
            raise PermissionError2(
                f"Forbidden (403): check subscription or cookies. Body: {resp.text[:500]}"
            )
        if resp.status_code in (502, 503, 504):
            # Transient upstream - let caller decide whether to retry
            resp.raise_for_status()
        if resp.status_code >= 400:
            # 400 = schema changed or bad payload; 404 etc.
            resp.raise_for_status()

    def _handle_response(self, resp: requests.Response) -> Any:
        self._check_status(resp)
        try:
            return resp.json()
        except Exception:
            return {"raw_text": resp.text}

    # ---------- Read-only ops ----------

    @retry(
        retry=retry_if_exception_type(
            (requests.exceptions.ConnectionError, requests.exceptions.Timeout)
        ),
        stop=stop_after_attempt(3),
        wait=wait_exponential_jitter(initial=1, max=10),
        reraise=True,
    )
    def get_credits(self) -> dict[str, Any]:
        """Fetch remaining credits from the aisandbox credits endpoint."""
        adapter = current_adapter()
        try:
            resp = self.session.get(adapter.endpoints.credits, timeout=self.timeout)
            data = self._handle_response(resp)
        except requests.exceptions.HTTPError as e:
            resp = getattr(e, "response", None)
            status = resp.status_code if resp is not None else None
            if status == 404:
                raise UpstreamChangedError(
                    f"Credits endpoint no longer exists (404): {adapter.endpoints.credits}"
                ) from e
            raise
        if not isinstance(data, dict):
            raise UpstreamChangedError(
                f"Credits response was not a JSON object (got {type(data).__name__})"
            )
        if isinstance(data.get("credits"), (int, float)):
            return data
        # Normalize a few common aliases so callers always see a numbers field.
        for key in ("remaining", "balance", "subscriptionCredits"):
            if isinstance(data.get(key), (int, float)) and "credits" not in data:
                data["credits"] = data[key]
                return data
        raise UpstreamChangedError(
            f"Credits endpoint returned an unrecognized shape: {list(data.keys())[:10]}"
        )

    def create_project(self, title: str | None = None, tool: str | None = None) -> dict[str, Any]:
        adapter = current_adapter()
        if not title:
            title = f"flow-cli-{int(time.time())}"
        if not tool:
            tool = adapter.project_tools.video
        payload = {"json": {"projectTitle": title, "toolName": tool}}
        resp = self.session.post(
            adapter.endpoints.project_create, json=payload, timeout=self.timeout
        )
        data = self._handle_response(resp)
        try:
            result = data["result"]["data"]["json"]["result"]
            return result if isinstance(result, dict) else data
        except Exception:
            return data

    def fetch_history(
        self,
        media_type: str = "PINHOLE",
        page_size: int = 20,
        project_id: str | None = None,
        cursor: str | None = None,
    ) -> list[dict[str, Any]]:
        """Fetch user history via media.fetchUserHistoryDirectly.
        media_type: PINHOLE (video) or ASSET_MANAGER (image)
        """
        workflows, _next_cursor = self.fetch_history_page(
            media_type=media_type,
            page_size=page_size,
            project_id=project_id,
            cursor=cursor,
        )
        return workflows

    def fetch_history_page(
        self,
        media_type: str = "PINHOLE",
        page_size: int = 20,
        project_id: str | None = None,
        cursor: str | None = None,
    ) -> tuple[list[dict[str, Any]], str | None]:
        """Fetch one history page and preserve the upstream continuation cursor."""
        adapter = current_adapter()
        input_data: dict[str, Any] = {
            "json": {
                "type": media_type,
                "pageSize": page_size,
                "responseScope": "RESPONSE_SCOPE_UNSPECIFIED",
                "cursor": cursor,
            },
            "meta": {"values": {"cursor": ["undefined"] if cursor is None else [cursor]}},
        }
        if project_id:
            input_data["json"]["projectId"] = project_id
        params = {"input": json.dumps(input_data)}
        resp = self.session.get(adapter.endpoints.history, params=params, timeout=self.timeout)
        data = self._handle_response(resp)
        try:
            result = data["result"]["data"]["json"]["result"]
            workflows = result["userWorkflows"]
            items = workflows if isinstance(workflows, list) else []
            next_cursor = (
                result.get("nextCursor")
                or result.get("nextPageCursor")
                or result.get("nextPageToken")
            )
            if next_cursor is None and isinstance(result.get("pagination"), dict):
                next_cursor = result["pagination"].get("nextCursor")
            return items, str(next_cursor) if next_cursor else None
        except Exception:
            return [], None

    def fetch_workflows(
        self, project_id: str | None = None, media_type: str = "VIDEO", limit: int = 20
    ) -> list[dict[str, Any]]:
        adapter = current_adapter()
        type_param = adapter.history_type_params.get(media_type.lower(), media_type)
        workflows = self.fetch_history(
            media_type=type_param, page_size=limit, project_id=project_id
        )
        if project_id:
            filtered = []
            for wf in workflows:
                pid = wf.get("media", {}).get("mediaGenerationId", {}).get("projectId")
                if pid == project_id:
                    filtered.append(wf)
            return filtered
        return workflows

    def get_media(self, media_id: str) -> dict[str, Any]:
        """Poll single media by ID via aisandbox-pa."""
        adapter = current_adapter()
        clean = media_id.replace("media/", "").strip()
        url = adapter.endpoints.aisandbox_base + f"/v1/media/{clean}"
        resp = self.session.get(url, timeout=self.timeout)
        return self._handle_response(resp)

    def get_operation(self, operation_name: str) -> dict[str, Any]:
        """Read one exact long-running generation operation by name."""
        adapter = current_adapter()
        clean = operation_name.strip().lstrip("/")
        if not clean.startswith("operations/"):
            clean = f"operations/{clean}"
        url = f"{adapter.endpoints.aisandbox_base}/v1/{clean}"
        resp = self.session.get(url, timeout=self.timeout)
        data = self._handle_response(resp)
        if not isinstance(data, dict):
            raise UpstreamChangedError("Operation response was not a JSON object")
        return data

    def list_projects(self, media_type: str = "video", page_size: int = 20) -> list[dict[str, Any]]:
        """List user projects via project.searchUserProjects.

        Errors are NOT swallowed: a removed endpoint (404) or an unexpected
        shape raises UpstreamChangedError so the caller can report that the
        upstream integration is stale instead of showing an empty list.
        """
        adapter = current_adapter()
        tool_name = adapter.history_type_params.get(media_type.lower(), "PINHOLE")
        input_data: dict[str, Any] = {
            "json": {"pageSize": page_size, "toolName": tool_name, "cursor": None},
            "meta": {"values": {"cursor": ["undefined"]}},
        }
        params = {"input": json.dumps(input_data)}
        try:
            resp = self.session.get(
                adapter.endpoints.project_list, params=params, timeout=self.timeout
            )
            data = self._handle_response(resp)
        except requests.exceptions.HTTPError as e:
            resp = getattr(e, "response", None)
            status = resp.status_code if resp is not None else None
            if status == 404:
                raise UpstreamChangedError(
                    f"Projects endpoint no longer exists (404): {adapter.endpoints.project_list}"
                ) from e
            raise
        try:
            result = data["result"]["data"]["json"]["result"]
        except Exception as e:
            raise UpstreamChangedError(
                f"Unexpected projects response shape (projects endpoint may have "
                f"changed). Detail: {e}"
            ) from e
        if "projects" not in result:
            raise UpstreamChangedError(
                "Projects response is missing the 'projects' field - "
                "the projects endpoint may have changed."
            )
        projects = result.get("projects")
        if isinstance(projects, list):
            return projects
        raise UpstreamChangedError(
            "Projects response 'projects' field is not a list - schema may have changed."
        )
