"""Shared input validation for CLI, Python and REST entry points."""

from __future__ import annotations

from pathlib import Path

from flow_cli._downloader import detect_container

SUPPORTED_IMAGE_CONTAINERS = frozenset({"png", "jpeg", "gif", "webp"})
IMAGE_MIME_BY_CONTAINER = {
    "png": "image/png",
    "jpeg": "image/jpeg",
    "gif": "image/gif",
    "webp": "image/webp",
}
DEFAULT_MAX_IMAGE_BYTES = 20 * 1024 * 1024


def validate_image_bytes(data: bytes, content_type: str | None = None) -> tuple[str, str]:
    """Validate image magic bytes and an optional declared MIME type."""
    if not data:
        raise ValueError("input image is empty")
    kind = detect_container(data[:64])
    if kind not in SUPPORTED_IMAGE_CONTAINERS:
        raise ValueError("input is not a supported PNG, JPEG, GIF, or WebP image")
    expected_mime = IMAGE_MIME_BY_CONTAINER[kind]
    declared = (content_type or "").split(";", 1)[0].strip().lower()
    if declared and declared not in {"application/octet-stream", expected_mime}:
        raise ValueError(f"content type {declared!r} does not match detected {expected_mime!r}")
    return kind, expected_mime


def validate_image_path(
    image_path: str | Path, *, max_bytes: int = DEFAULT_MAX_IMAGE_BYTES
) -> Path:
    """Validate an I2V file without loading the whole file into memory."""
    path = Path(image_path)
    if not path.is_file():
        raise ValueError(f"I2V input image not found: {path}")
    size = path.stat().st_size
    if size == 0:
        raise ValueError(f"I2V input image is empty: {path}")
    if size > max_bytes:
        raise ValueError(f"I2V input image exceeds {max_bytes} bytes: {path}")
    with path.open("rb") as stream:
        validate_image_bytes(stream.read(64))
    return path
