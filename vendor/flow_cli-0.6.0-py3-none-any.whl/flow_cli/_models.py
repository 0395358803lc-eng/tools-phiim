"""Dataclasses for flow_cli."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class AspectRatio(StrEnum):
    SQUARE = "1:1"
    PORTRAIT = "9:16"
    LANDSCAPE = "16:9"
    WIDE = "21:9"
    TALL = "3:4"
    CLASSIC = "4:3"


class VideoModel(StrEnum):
    VEO_3_1_LITE_LOWER_PRIORITY = "veo-3.1-lite-lower-priority"
    VEO_3_1 = "veo-3.1"  # Veo 3.1 Quality - 100 credits
    VEO_3_1_FAST = "veo-3.1-fast"  # Veo 3.1 Fast - 0 credits Ultra / 20 Pro
    VEO_3 = "veo-3"  # Veo 3 Quality
    VEO_3_FAST = "veo-3-fast"  # Veo 3 Fast - distinct from Lite, 20 credits, 720p/1080p
    VEO_3_LITE = (
        "veo-3-lite"  # Veo 3 Lite - cheaper, faster, lower quality than Fast, 10-15 credits
    )
    VEO_3_1_LITE = "veo-3.1-lite"  # Veo 3.1 Lite - for Frames, coming soon
    VEO_2 = "veo-2"  # Veo 2 Quality
    VEO_2_FAST = "veo-2-fast"  # Veo 2 Fast Mode


class ImageModel(StrEnum):
    NANO_BANANA = "nano-banana"
    NANO_BANANA_PRO = "nano-banana-pro"
    IMAGEN_3 = "imagen-3"
    IMAGEN_4 = "imagen-4"


SUPPORTED_VIDEO_MODELS = {
    VideoModel.VEO_3_1_LITE_LOWER_PRIORITY.value,
    VideoModel.VEO_3_LITE.value,
    VideoModel.VEO_3_FAST.value,
    VideoModel.VEO_3_1_LITE.value,
    VideoModel.VEO_3_1_FAST.value,
    VideoModel.VEO_3_1.value,
    VideoModel.VEO_3.value,
    VideoModel.VEO_2_FAST.value,
    VideoModel.VEO_2.value,
}

DEFAULT_VIDEO_MODEL = VideoModel.VEO_3_1_LITE_LOWER_PRIORITY.value

SUPPORTED_IMAGE_MODELS = {m.value for m in ImageModel}
SUPPORTED_VIDEO_DURATIONS = frozenset({4, 6, 8})


def normalize_video_model(value: str) -> str:
    """Normalize a user-supplied video model string WITHOUT changing its meaning.

    Lite and Fast are distinct models and must NEVER be merged/silently renamed.
    Only whitespace and format are normalized; unknown models raise UsageError.
    """
    from flow_cli._exceptions import UsageError

    normalized = value.strip().lower().replace(" ", "-")
    if normalized not in SUPPORTED_VIDEO_MODELS:
        raise UsageError(f"Unsupported video model: {value!r}")
    return normalized


def normalize_image_model(value: str) -> str:
    from flow_cli._exceptions import UsageError

    normalized = value.strip().lower().replace(" ", "-")
    if normalized not in SUPPORTED_IMAGE_MODELS:
        raise UsageError(f"Unsupported image model: {value!r}")
    return normalized


def normalize_duration(value: object) -> int:
    from flow_cli._exceptions import UsageError

    if (
        isinstance(value, bool)
        or not isinstance(value, int)
        or value not in SUPPORTED_VIDEO_DURATIONS
    ):
        allowed = ", ".join(str(item) for item in sorted(SUPPORTED_VIDEO_DURATIONS))
        raise UsageError(f"Unsupported duration {value!r}; expected one of: {allowed}")
    return value


def normalize_output_count(value: object) -> int:
    """Validate output count is in 1..4."""
    from flow_cli._exceptions import UsageError

    if isinstance(value, bool) or not isinstance(value, int) or not (1 <= value <= 4):
        raise UsageError(f"Output count must be between 1 and 4: {value!r}")
    return value


class MediaType(StrEnum):
    VIDEO = "video"
    IMAGE = "image"


PROJECT_TOOL_BY_MEDIA = {
    MediaType.VIDEO: "VIDEO_FX",
    MediaType.IMAGE: "ASSET_MANAGER",
}


@dataclass
class ModelConfig:
    video_model: VideoModel = VideoModel.VEO_3_1_LITE_LOWER_PRIORITY
    image_model: ImageModel = ImageModel.NANO_BANANA_PRO
    aspect_ratio: AspectRatio = AspectRatio.LANDSCAPE
    duration_seconds: int = 8
    resolution: str = "1080p"  # 720p, 1080p, 4K (Ultra only)


@dataclass
class VideoJob:
    job_id: str
    prompt: str
    status: str  # QUEUED, RUNNING, SUCCEEDED, FAILED
    media_name: str | None = None
    project_id: str | None = None
    operation_name: str | None = None
    media_id: str | None = None
    workflow_id: str | None = None
    resource_name: str | None = None
    created_at: float = field(default_factory=time.time)
    error: str | None = None
    prompt_hash: str | None = None
    model: str | None = None
    aspect: str | None = None
    duration: int | None = None
    media_type: str = "video"
    raw: dict[str, Any] = field(default_factory=dict)

    @property
    def is_done(self) -> bool:
        return self.status in ("SUCCEEDED", "FAILED", "COMPLETED")

    @property
    def is_success(self) -> bool:
        return self.status in ("SUCCEEDED", "COMPLETED")


@dataclass
class GeneratedImage:
    image_id: str
    prompt: str
    fife_url: str | None = None  # https://lh3.googleusercontent.com/...
    local_path: str | None = None
    width: int = 1024
    height: int = 1024
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class ImageJob:
    job_id: str
    prompt: str
    images: list[GeneratedImage] = field(default_factory=list)
    status: str = "SUCCEEDED"
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class Credits:
    remaining: int | None = None
    total: int | None = None
    tier: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        if self.remaining is not None:
            return f"{self.remaining} credits (tier={self.tier or 'unknown'})"
        return "unknown"


@dataclass
class Project:
    project_id: str
    title: str
    tool: str = "VIDEO_FX"
    media_type: str = "video"
    raw: dict[str, Any] = field(default_factory=dict)
