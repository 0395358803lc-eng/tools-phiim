"""Validated request and response models for the local HTTP API."""

from __future__ import annotations

import time
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, HttpUrl, field_validator

from flow_cli._models import DEFAULT_VIDEO_MODEL, normalize_image_model, normalize_video_model


class VideoCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    prompt: str = Field(min_length=1, max_length=4_000)
    aspect: Literal["16:9", "9:16", "1:1", "4:3", "3:4", "21:9"] = "16:9"
    model: str = DEFAULT_VIDEO_MODEL
    duration: Literal[4, 6, 8] = 8
    project_id: str | None = Field(default=None, min_length=1, max_length=200)
    input_asset_id: str | None = Field(default=None, min_length=1, max_length=200)
    timeout: int = Field(default=600, ge=30, le=3_600)

    @field_validator("model")
    @classmethod
    def validate_model(cls, value: str) -> str:
        try:
            return normalize_video_model(value)
        except Exception as exc:
            raise ValueError(str(exc)) from exc


class ImageCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    prompt: str = Field(min_length=1, max_length=4_000)
    aspect: Literal["16:9", "9:16", "1:1", "4:3", "3:4", "21:9"] = "1:1"
    model: str = "nano-banana-pro"
    count: int = Field(default=4, ge=1, le=4)
    project_id: str | None = Field(default=None, min_length=1, max_length=200)
    timeout: int = Field(default=300, ge=30, le=3_600)

    @field_validator("model")
    @classmethod
    def validate_model(cls, value: str) -> str:
        try:
            return normalize_image_model(value)
        except Exception as exc:
            raise ValueError(str(exc)) from exc


class BatchVideoRequest(VideoCreateRequest):
    type: Literal["video"]


class BatchImageRequest(ImageCreateRequest):
    type: Literal["image"]


BatchItem = Annotated[BatchVideoRequest | BatchImageRequest, Field(discriminator="type")]


class BatchCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    jobs: list[BatchItem] = Field(min_length=1, max_length=50)


class URLDownloadRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    type: Literal["url"]
    url: HttpUrl
    media_type: Literal["video", "image"] = "video"


class MediaDownloadRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    type: Literal["media"]
    media_id: str = Field(min_length=1, max_length=500)
    media_type: Literal["video", "image"] = "video"


class HistoryDownloadRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    type: Literal["history"]
    media_type: Literal["video", "image"] = "video"
    project_id: str | None = Field(default=None, min_length=1, max_length=200)
    limit: int = Field(default=1, ge=1, le=20)


DownloadCreateRequest = Annotated[
    URLDownloadRequest | MediaDownloadRequest | HistoryDownloadRequest,
    Field(discriminator="type"),
]


class ProjectCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    title: str = Field(min_length=1, max_length=200)
    media_type: Literal["video", "image"] = "video"


class AuthLoginRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    cookies: str | dict[str, str] | list[dict[str, Any]]
    verify: bool = True


class AuthResult(BaseModel):
    cookie_count: int
    verified: bool
    message: str


class APIErrorDetail(BaseModel):
    code: str
    message: str
    request_id: str
    details: list[dict[str, Any]] | None = None


class APIError(BaseModel):
    error: APIErrorDetail


class APIArtifact(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str
    kind: Literal["video", "image"]
    mime_type: str
    width: int | None = None
    height: int | None = None
    size: int | None = None
    download_url: str
    local_file: str | None = Field(default=None, exclude=True, repr=False)


class APIAsset(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str
    mime_type: str
    size: int
    width: int | None = None
    height: int | None = None
    created_at: float = Field(default_factory=time.time)
    local_file: str | None = Field(default=None, exclude=True, repr=False)


class APIBatch(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str
    state: Literal["QUEUED", "RUNNING", "SUCCEEDED", "PARTIAL", "FAILED"] = "QUEUED"
    total: int
    completed: int = 0
    failed: int = 0
    job_ids: list[str]
    created_at: float = Field(default_factory=time.time)


class APIJob(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str
    media_type: Literal["video", "image"] = "video"
    state: Literal["QUEUED", "RUNNING", "SUCCEEDED", "FAILED"] = "QUEUED"
    prompt: str
    aspect: str
    model: str
    duration: int | None = None
    requested_count: int = 1
    completed_count: int = 0
    project_id: str | None = None
    upstream_job_id: str | None = None
    media_id: str | None = None
    workflow_id: str | None = None
    operation_name: str | None = None
    resource_name: str | None = None
    artifacts: list[APIArtifact] = Field(default_factory=list)
    output_file: str | None = Field(default=None, exclude=True, repr=False)
    download_url: str | None = None
    error: str | None = None
    created_at: float = Field(default_factory=time.time)
    started_at: float | None = None
    completed_at: float | None = None


class HealthResponse(BaseModel):
    status: Literal["ok"] = "ok"
    service: str = "flow-cli-api"
    version: str
    api_key_required: bool
    active_jobs: int
