"""FastAPI application factory for flow-cli."""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import importlib.util
import ipaddress
import json
import os
import platform
import sys
import time
import uuid
from collections import defaultdict, deque
from collections.abc import AsyncGenerator, Mapping
from contextlib import asynccontextmanager
from email import policy
from email.parser import BytesParser
from pathlib import Path
from typing import Annotated, Any

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request, Response, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from flow_cli import __version__
from flow_cli._auth import save_cookies_from_input, validate_cookies
from flow_cli._client import FlowClient
from flow_cli._exceptions import AuthError, FlowError
from flow_cli._logging import get_logger
from flow_cli._storage import clear_storage, load_config, load_cookies_file
from flow_cli.webapi.models import (
    APIArtifact,
    APIAsset,
    APIBatch,
    APIError,
    APIErrorDetail,
    APIJob,
    AuthLoginRequest,
    AuthResult,
    BatchCreateRequest,
    DownloadCreateRequest,
    HealthResponse,
    ImageCreateRequest,
    ProjectCreateRequest,
    VideoCreateRequest,
)
from flow_cli.webapi.service import IdempotencyConflict, JobService

ERROR_RESPONSES: dict[int | str, dict[str, Any]] = {
    code: {"model": APIError} for code in (400, 401, 403, 404, 409, 410, 413, 422, 429, 500, 502)
}
IdempotencyHeader = Annotated[
    str | None,
    Header(alias="Idempotency-Key", min_length=1, max_length=200, pattern=r"^[A-Za-z0-9._:-]+$"),
]
log = get_logger(__name__)


def create_app(job_service: JobService | None = None) -> FastAPI:
    service = job_service or JobService(
        concurrency=max(1, int(os.getenv("FLOW_API_CONCURRENCY", "1")))
    )

    @asynccontextmanager
    async def lifespan(_app: FastAPI) -> AsyncGenerator[None]:
        yield
        await service.shutdown()

    app = FastAPI(
        title="flow-cli API",
        version=__version__,
        description="Local REST API for headless Google Flow generation.",
        lifespan=lifespan,
        responses=ERROR_RESPONSES,
    )
    app.state.job_service = service

    rate_limit = max(0, int(os.getenv("FLOW_API_RATE_LIMIT", "120")))
    rate_window = max(1, int(os.getenv("FLOW_API_RATE_WINDOW", "60")))
    rate_buckets: dict[str, deque[float]] = defaultdict(deque)
    rate_lock = asyncio.Lock()

    def error_response(
        request: Request,
        status_code: int,
        code: str,
        message: str,
        *,
        details: list[dict[str, Any]] | None = None,
        headers: Mapping[str, str] | None = None,
    ) -> JSONResponse:
        request_id = getattr(request.state, "request_id", uuid.uuid4().hex)
        body = APIError(
            error=APIErrorDetail(
                code=code,
                message=message,
                request_id=request_id,
                details=details,
            )
        )
        response = JSONResponse(status_code=status_code, content=body.model_dump(), headers=headers)
        response.headers["X-Request-ID"] = request_id
        return response

    @app.middleware("http")
    async def request_controls(  # pyright: ignore[reportUnusedFunction]
        request: Request, call_next: Any
    ) -> Response:
        request.state.request_id = uuid.uuid4().hex
        if rate_limit and request.url.path.startswith("/v1/"):
            api_key = request.headers.get("x-api-key")
            expected_key = os.getenv("FLOW_API_KEY")
            if api_key and expected_key and hmac.compare_digest(api_key, expected_key):
                identity = "key:" + hashlib.sha256(api_key.encode()).hexdigest()[:16]
            else:
                identity = "ip:" + (request.client.host if request.client else "unknown")
            now = time.monotonic()
            async with rate_lock:
                bucket = rate_buckets[identity]
                while bucket and bucket[0] <= now - rate_window:
                    bucket.popleft()
                if len(bucket) >= rate_limit:
                    retry_after = max(1, int(rate_window - (now - bucket[0])))
                    return error_response(
                        request,
                        429,
                        "rate_limited",
                        "request rate limit exceeded",
                        headers={"Retry-After": str(retry_after)},
                    )
                bucket.append(now)
                remaining = max(0, rate_limit - len(bucket))
            response = await call_next(request)
            response.headers["X-RateLimit-Limit"] = str(rate_limit)
            response.headers["X-RateLimit-Remaining"] = str(remaining)
        else:
            response = await call_next(request)
        response.headers["X-Request-ID"] = request.state.request_id
        return response

    @app.exception_handler(RequestValidationError)
    async def validation_error(  # pyright: ignore[reportUnusedFunction]
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        details = [
            {"location": list(item["loc"]), "message": item["msg"], "type": item["type"]}
            for item in exc.errors()
        ]
        return error_response(
            request, 422, "validation_error", "request validation failed", details=details
        )

    @app.exception_handler(StarletteHTTPException)
    async def http_error(  # pyright: ignore[reportUnusedFunction]
        request: Request, exc: StarletteHTTPException
    ) -> JSONResponse:
        code_by_status = {
            400: "bad_request",
            401: "authentication_required",
            403: "forbidden",
            404: "not_found",
            405: "method_not_allowed",
            409: "conflict",
            410: "gone",
            413: "payload_too_large",
            422: "validation_error",
            429: "rate_limited",
            502: "upstream_error",
        }
        return error_response(
            request,
            exc.status_code,
            code_by_status.get(exc.status_code, "http_error"),
            exc.detail,
            headers=exc.headers,
        )

    @app.exception_handler(IdempotencyConflict)
    async def idempotency_error(  # pyright: ignore[reportUnusedFunction]
        request: Request, exc: IdempotencyConflict
    ) -> JSONResponse:
        return error_response(request, 409, "idempotency_conflict", str(exc))

    @app.exception_handler(Exception)
    async def internal_error(  # pyright: ignore[reportUnusedFunction]
        request: Request, _exc: Exception
    ) -> JSONResponse:
        log.error(
            "api_internal_error",
            request_id=request.state.request_id,
            path=request.url.path,
            error_type=type(_exc).__name__,
        )
        return error_response(request, 500, "internal_error", "internal server error")

    async def require_api_key(
        x_api_key: Annotated[str | None, Header()] = None,
    ) -> None:
        expected = os.getenv("FLOW_API_KEY")
        if expected and (x_api_key is None or not hmac.compare_digest(x_api_key, expected)):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid API key")

    protected = Depends(require_api_key)

    async def admin_or_loopback(
        request: Request,
        x_api_key: Annotated[str | None, Header()] = None,
    ) -> None:
        host = request.client.host if request.client else ""
        try:
            loopback = ipaddress.ip_address(host).is_loopback
        except ValueError:
            loopback = host == "localhost"
        expected = os.getenv("FLOW_API_KEY")
        admin = bool(expected and x_api_key and hmac.compare_digest(x_api_key, expected))
        if not loopback and not admin:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="cookie login is restricted to loopback or an admin API key",
            )

    auth_guard = Depends(admin_or_loopback)

    async def new_client(project_id: str | None = None) -> FlowClient:
        return await asyncio.to_thread(FlowClient, project_id=project_id)

    @app.get("/health", response_model=HealthResponse, tags=["system"])
    async def health() -> HealthResponse:  # pyright: ignore[reportUnusedFunction]
        return HealthResponse(
            version=__version__,
            api_key_required=bool(os.getenv("FLOW_API_KEY")),
            active_jobs=service.active_jobs,
        )

    @app.post(
        "/v1/auth/login",
        response_model=AuthResult,
        dependencies=[auth_guard],
        tags=["auth"],
    )
    async def auth_login(  # pyright: ignore[reportUnusedFunction]
        request: Request, payload: AuthLoginRequest
    ) -> AuthResult:
        max_bytes = max(1_024, int(os.getenv("FLOW_API_MAX_LOGIN_BYTES", "131072")))
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                if int(content_length) > max_bytes:
                    raise HTTPException(status_code=413, detail="login payload is too large")
            except ValueError as exc:
                raise HTTPException(status_code=400, detail="invalid content-length") from exc
        serialized = (
            payload.cookies if isinstance(payload.cookies, str) else json.dumps(payload.cookies)
        )
        try:
            cookies = await asyncio.to_thread(save_cookies_from_input, cookie_str=serialized)
            if payload.verify:
                verified, message, _raw = await asyncio.to_thread(validate_cookies, cookies)
            else:
                verified, message = False, "Cookies saved; verification was not requested"
            return AuthResult(cookie_count=len(cookies), verified=verified, message=message)
        except AuthError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @app.post(
        "/v1/auth/verify",
        response_model=AuthResult,
        dependencies=[protected],
        tags=["auth"],
    )
    async def auth_verify() -> AuthResult:  # pyright: ignore[reportUnusedFunction]
        cookies = await asyncio.to_thread(load_cookies_file)
        verified, message, _raw = await asyncio.to_thread(validate_cookies, cookies)
        return AuthResult(cookie_count=len(cookies), verified=verified, message=message)

    @app.get("/v1/auth/status", dependencies=[protected], tags=["auth"])
    async def auth_status() -> dict[str, Any]:  # pyright: ignore[reportUnusedFunction]
        cookies = await asyncio.to_thread(load_cookies_file)
        config = await asyncio.to_thread(load_config)
        return {
            "authenticated": bool(cookies),
            "cookie_count": len(cookies),
            "last_login": config.get("last_login"),
        }

    @app.delete(
        "/v1/auth/session",
        status_code=status.HTTP_204_NO_CONTENT,
        dependencies=[auth_guard],
        tags=["auth"],
    )
    async def auth_logout() -> None:  # pyright: ignore[reportUnusedFunction]
        await asyncio.to_thread(clear_storage)

    @app.get("/v1/config", dependencies=[protected], tags=["system"])
    async def config() -> dict[str, Any]:  # pyright: ignore[reportUnusedFunction]
        stored = await asyncio.to_thread(load_config)
        return {
            key: stored[key]
            for key in ("last_login", "cookie_count", "has_bearer")
            if key in stored
        }

    @app.get("/v1/doctor", dependencies=[protected], tags=["system"])
    async def doctor() -> dict[str, Any]:  # pyright: ignore[reportUnusedFunction]
        cookies = await asyncio.to_thread(load_cookies_file)
        dependencies = {
            name: importlib.util.find_spec(name) is not None
            for name in ("requests", "playwright", "fastapi", "uvicorn")
        }
        return {
            "python_version": platform.python_version(),
            "python_supported": sys.version_info >= (3, 11),
            "platform": platform.system(),
            "dependencies": dependencies,
            "has_cookies": bool(cookies),
            "cookie_count": len(cookies),
            "api_key_configured": bool(os.getenv("FLOW_API_KEY")),
        }

    @app.get("/v1/credits", dependencies=[protected], tags=["flow"])
    async def credits() -> dict[str, Any]:  # pyright: ignore[reportUnusedFunction]
        try:
            value = await (await new_client()).get_credits()
            return {
                "remaining": value.remaining,
                "total": value.total,
                "tier": value.tier,
                "raw": value.raw,
            }
        except AuthError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except FlowError as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc

    @app.get("/v1/projects", dependencies=[protected], tags=["flow"])
    async def projects(  # pyright: ignore[reportUnusedFunction]
        media_type: Annotated[str, Query(pattern="^(video|image)$")] = "video",
    ) -> list[dict[str, Any]]:
        try:
            return await (await new_client()).list_projects(media_type=media_type)
        except AuthError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except FlowError as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc

    @app.post("/v1/projects", dependencies=[protected], status_code=201, tags=["flow"])
    async def create_project(  # pyright: ignore[reportUnusedFunction]
        request: ProjectCreateRequest,
    ) -> dict[str, str]:
        try:
            project_id = await (await new_client()).create_project(
                request.title, media_type=request.media_type
            )
            return {"project_id": project_id}
        except AuthError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except FlowError as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc

    @app.get("/v1/history", dependencies=[protected], tags=["flow"])
    async def history(  # pyright: ignore[reportUnusedFunction]
        response: Response,
        media_type: Annotated[str, Query(pattern="^(video|image)$")] = "video",
        project_id: Annotated[str | None, Query(min_length=1, max_length=200)] = None,
        limit: Annotated[int, Query(ge=1, le=100)] = 20,
        cursor: Annotated[str | None, Query(min_length=1, max_length=2_000)] = None,
        all_projects: Annotated[bool, Query(alias="all")] = False,
    ) -> list[dict[str, Any]]:
        try:
            resolved_project = None if all_projects else project_id
            client = await new_client(resolved_project)
            if hasattr(client, "fetch_history_page"):
                items, next_cursor = await client.fetch_history_page(
                    media_type=media_type,
                    limit=limit,
                    project_id=resolved_project,
                    cursor=cursor,
                )
                if next_cursor:
                    response.headers["X-Next-Cursor"] = next_cursor
                return items
            return await client.fetch_history(
                media_type=media_type, limit=limit, project_id=resolved_project, cursor=cursor
            )
        except AuthError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except FlowError as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc

    @app.post(
        "/v1/videos",
        response_model=APIJob,
        status_code=status.HTTP_202_ACCEPTED,
        dependencies=[protected],
        tags=["generation"],
    )
    async def create_video(  # pyright: ignore[reportUnusedFunction]
        request: VideoCreateRequest,
        idempotency_key: IdempotencyHeader = None,
    ) -> APIJob:
        if request.input_asset_id and not await service.get_asset(request.input_asset_id):
            raise HTTPException(status_code=422, detail="input_asset_id does not exist")
        return await service.submit_video(request, idempotency_key=idempotency_key)

    @app.post(
        "/v1/images",
        response_model=APIJob,
        status_code=status.HTTP_202_ACCEPTED,
        dependencies=[protected],
        tags=["generation"],
    )
    async def create_image(  # pyright: ignore[reportUnusedFunction]
        request: ImageCreateRequest,
        idempotency_key: IdempotencyHeader = None,
    ) -> APIJob:
        return await service.submit_image(request, idempotency_key=idempotency_key)

    @app.post(
        "/v1/assets",
        response_model=APIAsset,
        status_code=status.HTTP_201_CREATED,
        dependencies=[protected],
        tags=["generation"],
    )
    async def upload_asset(request: Request) -> APIAsset:  # pyright: ignore[reportUnusedFunction]
        max_bytes = max(1_024, int(os.getenv("FLOW_API_MAX_ASSET_BYTES", "20971520")))
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                if int(content_length) > max_bytes:
                    raise HTTPException(status_code=413, detail="asset is too large")
            except ValueError as exc:
                raise HTTPException(status_code=400, detail="invalid content-length") from exc
        body = await request.body()
        if len(body) > max_bytes:
            raise HTTPException(status_code=413, detail="asset is too large")
        content_type = request.headers.get("content-type", "application/octet-stream")
        if content_type.lower().startswith("multipart/form-data"):
            envelope = f"Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n".encode() + body
            message = BytesParser(policy=policy.default).parsebytes(envelope)
            file_part = next(
                (
                    part
                    for part in message.iter_parts()
                    if part.get_content_disposition() == "form-data"
                    and part.get_filename() is not None
                ),
                None,
            )
            if file_part is None:
                raise HTTPException(status_code=422, detail="multipart body has no file")
            decoded = file_part.get_payload(decode=True)
            body = decoded if isinstance(decoded, bytes) else b""
            content_type = file_part.get_content_type()
        try:
            return await service.save_asset(body, content_type)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @app.post(
        "/v1/downloads",
        response_model=APIJob,
        status_code=status.HTTP_202_ACCEPTED,
        dependencies=[protected],
        tags=["generation"],
    )
    async def create_download(  # pyright: ignore[reportUnusedFunction]
        request: DownloadCreateRequest,
        idempotency_key: IdempotencyHeader = None,
    ) -> APIJob:
        if request.type == "url" and not service.download_url_allowed(str(request.url)):
            raise HTTPException(
                status_code=422, detail="download URL is not on the HTTPS allowlist"
            )
        return await service.submit_download(request, idempotency_key=idempotency_key)

    @app.post(
        "/v1/batches",
        response_model=APIBatch,
        status_code=status.HTTP_202_ACCEPTED,
        dependencies=[protected],
        tags=["generation"],
    )
    async def create_batch(  # pyright: ignore[reportUnusedFunction]
        request: BatchCreateRequest,
        idempotency_key: IdempotencyHeader = None,
    ) -> APIBatch:
        for item in request.jobs:
            asset_id = getattr(item, "input_asset_id", None)
            if asset_id and not await service.get_asset(asset_id):
                raise HTTPException(status_code=422, detail=f"unknown input_asset_id: {asset_id}")
        return await service.submit_batch(request, idempotency_key=idempotency_key)

    @app.get(
        "/v1/batches/{batch_id}",
        response_model=APIBatch,
        dependencies=[protected],
        tags=["jobs"],
    )
    async def get_batch(batch_id: str) -> APIBatch:  # pyright: ignore[reportUnusedFunction]
        batch = await service.get_batch(batch_id)
        if not batch:
            raise HTTPException(status_code=404, detail="batch not found")
        return batch

    @app.get(
        "/v1/batches/{batch_id}/jobs",
        response_model=list[APIJob],
        dependencies=[protected],
        tags=["jobs"],
    )
    async def get_batch_jobs(batch_id: str) -> list[APIJob]:  # pyright: ignore[reportUnusedFunction]
        jobs = await service.get_batch_jobs(batch_id)
        if jobs is None:
            raise HTTPException(status_code=404, detail="batch not found")
        return jobs

    @app.get("/v1/jobs", response_model=list[APIJob], dependencies=[protected], tags=["jobs"])
    async def list_jobs() -> list[APIJob]:  # pyright: ignore[reportUnusedFunction]
        return await service.list_jobs()

    @app.get("/v1/jobs/{job_id}", response_model=APIJob, dependencies=[protected], tags=["jobs"])
    async def get_job(job_id: str) -> APIJob:  # pyright: ignore[reportUnusedFunction]
        job = await service.get_job(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="job not found")
        return job

    @app.get(
        "/v1/jobs/{job_id}/artifacts",
        response_model=list[APIArtifact],
        dependencies=[protected],
        tags=["jobs"],
    )
    async def list_artifacts(job_id: str) -> list[APIArtifact]:  # pyright: ignore[reportUnusedFunction]
        job = await service.get_job(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="job not found")
        return job.artifacts

    @app.get(
        "/v1/jobs/{job_id}/artifacts/{artifact_id}/download",
        dependencies=[protected],
        tags=["jobs"],
    )
    async def download_artifact(  # pyright: ignore[reportUnusedFunction]
        job_id: str, artifact_id: str
    ) -> FileResponse:
        job = await service.get_job(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="job not found")
        artifact = next((item for item in job.artifacts if item.id == artifact_id), None)
        if not artifact:
            raise HTTPException(status_code=404, detail="artifact not found")
        if job.state != "SUCCEEDED" or not artifact.local_file:
            raise HTTPException(status_code=409, detail=f"job is {job.state.lower()}")
        path = Path(artifact.local_file)
        if not path.is_file():
            raise HTTPException(status_code=410, detail="artifact is no longer available")
        return FileResponse(path, media_type=artifact.mime_type, filename=path.name)

    @app.get("/v1/jobs/{job_id}/download", dependencies=[protected], tags=["jobs"])
    async def download_job(  # pyright: ignore[reportUnusedFunction]
        job_id: str,
    ) -> FileResponse:
        job = await service.get_job(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="job not found")
        if job.state != "SUCCEEDED" or not job.output_file:
            raise HTTPException(status_code=409, detail=f"job is {job.state.lower()}")
        path = Path(job.output_file)
        if not path.is_file():
            raise HTTPException(status_code=410, detail="downloaded file is no longer available")
        return FileResponse(path, media_type="video/mp4", filename=path.name)

    @app.get("/v1/media/{media_id}", dependencies=[protected], tags=["flow"])
    async def media(media_id: str) -> dict[str, Any]:  # pyright: ignore[reportUnusedFunction]
        try:
            return await (await new_client()).get_media(media_id)
        except AuthError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except FlowError as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc

    return app


app = create_app()
