"""Persistent job orchestration for video and image generation."""

from __future__ import annotations

import asyncio
import hashlib
import json
import mimetypes
import os
import re
import sqlite3
import tempfile
import time
import uuid
from collections.abc import Callable, Coroutine, Generator
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import urlparse

from flow_cli._client import FlowClient
from flow_cli._exceptions import FlowError
from flow_cli._models import GeneratedImage, VideoJob
from flow_cli._storage import get_data_dir
from flow_cli._validation import validate_image_bytes
from flow_cli.webapi.models import (
    APIArtifact,
    APIAsset,
    APIBatch,
    APIJob,
    BatchCreateRequest,
    BatchVideoRequest,
    DownloadCreateRequest,
    HistoryDownloadRequest,
    ImageCreateRequest,
    MediaDownloadRequest,
    URLDownloadRequest,
    VideoCreateRequest,
)


class FlowClientProtocol(Protocol):
    async def generate_video(
        self,
        prompt: str,
        aspect: str,
        model: str,
        duration: int,
        image_path: str | None = None,
        headless: bool = True,
        timeout: int = 300,
    ) -> VideoJob: ...

    async def generate_image(
        self,
        prompt: str,
        aspect: str,
        count: int,
        model: str,
        headless: bool = True,
        timeout: int = 300,
    ) -> list[GeneratedImage]: ...

    async def wait_for_video(
        self, job: VideoJob, timeout: int = 300, poll_interval: int = 5
    ) -> VideoJob: ...

    async def download(self, workflow: dict[str, Any], dest_dir: str | Path) -> list[Path]: ...

    async def get_media(self, media_id: str) -> dict[str, Any]: ...

    async def fetch_history(
        self,
        media_type: str,
        limit: int,
        project_id: str | None = None,
        cursor: str | None = None,
    ) -> list[dict[str, Any]]: ...

    async def download_url(
        self,
        url: str,
        dest_dir: str | Path,
        media_type: str,
        allowed_hosts: set[str],
    ) -> Path: ...


ClientFactory = Callable[..., FlowClientProtocol]


class IdempotencyConflict(ValueError):
    """An idempotency key was reused with a different request payload."""


class JobService:
    """Run a bounded number of headless Flow generations and track their state."""

    def __init__(
        self,
        *,
        client_factory: ClientFactory = FlowClient,
        output_dir: Path | None = None,
        db_path: Path | None = None,
        concurrency: int = 1,
    ) -> None:
        if concurrency < 1:
            raise ValueError("concurrency must be at least 1")
        self.client_factory = client_factory
        self.output_dir = output_dir or (get_data_dir() / "api-output")
        self.db_path = db_path or (self.output_dir.parent / "api-jobs.sqlite3")
        try:
            self._init_database()
        except (OSError, sqlite3.OperationalError):
            if output_dir is not None or db_path is not None:
                raise
            fallback = Path(tempfile.gettempdir()) / "flow-cli-api"
            self.output_dir = fallback / "output"
            self.db_path = fallback / "api-jobs.sqlite3"
            self._init_database()
        self._jobs = self._load_jobs()
        self._tasks: dict[str, asyncio.Task[None]] = {}
        self._lock = asyncio.Lock()
        self._idempotency_lock = asyncio.Lock()
        self._semaphore = asyncio.Semaphore(concurrency)

    @contextmanager
    def _connect(self) -> Generator[sqlite3.Connection, None, None]:
        """Open a transaction and always release its Windows file handle."""
        conn = sqlite3.connect(self.db_path)
        try:
            yield conn
            conn.commit()
        except BaseException:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_database(self) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as conn:
            conn.execute(
                "CREATE TABLE IF NOT EXISTS jobs "
                "(id TEXT PRIMARY KEY, payload TEXT NOT NULL, updated_at REAL NOT NULL)"
            )
            conn.execute(
                "CREATE TABLE IF NOT EXISTS assets "
                "(id TEXT PRIMARY KEY, payload TEXT NOT NULL, updated_at REAL NOT NULL)"
            )
            conn.execute(
                "CREATE TABLE IF NOT EXISTS batches "
                "(id TEXT PRIMARY KEY, payload TEXT NOT NULL, updated_at REAL NOT NULL)"
            )
            conn.execute(
                "CREATE TABLE IF NOT EXISTS idempotency_keys ("
                "scope TEXT NOT NULL, key TEXT NOT NULL, request_hash TEXT NOT NULL, "
                "resource_type TEXT NOT NULL, resource_id TEXT NOT NULL, created_at REAL NOT NULL, "
                "PRIMARY KEY (scope, key))"
            )
            ttl = max(0, int(os.getenv("FLOW_API_IDEMPOTENCY_TTL", "604800")))
            if ttl:
                conn.execute(
                    "DELETE FROM idempotency_keys WHERE created_at < ?", (time.time() - ttl,)
                )

    @staticmethod
    def _job_payload(job: APIJob) -> dict[str, Any]:
        payload = job.model_dump()
        payload["output_file"] = job.output_file
        payload["artifacts"] = []
        for artifact in job.artifacts:
            item = artifact.model_dump()
            item["local_file"] = artifact.local_file
            payload["artifacts"].append(item)
        return payload

    def _persist_sync(self, job: APIJob) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO jobs (id, payload, updated_at) VALUES (?, ?, ?)",
                (job.id, json.dumps(self._job_payload(job)), time.time()),
            )

    def _load_jobs(self) -> dict[str, APIJob]:
        loaded: dict[str, APIJob] = {}
        with self._connect() as conn:
            rows = conn.execute("SELECT payload FROM jobs").fetchall()
        for (raw,) in rows:
            try:
                job = APIJob.model_validate(json.loads(raw))
                if job.state in {"QUEUED", "RUNNING"}:
                    job = job.model_copy(
                        update={
                            "state": "FAILED",
                            "error": "Interrupted by API restart; submit a new job to retry",
                            "completed_at": time.time(),
                        }
                    )
                    self._persist_sync(job)
                loaded[job.id] = job
            except Exception:
                continue
        return loaded

    def _persist_asset_sync(self, asset: APIAsset) -> None:
        payload = asset.model_dump()
        payload["local_file"] = asset.local_file
        with self._connect() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO assets (id, payload, updated_at) VALUES (?, ?, ?)",
                (asset.id, json.dumps(payload), time.time()),
            )

    def _get_asset_sync(self, asset_id: str) -> APIAsset | None:
        with self._connect() as conn:
            row = conn.execute("SELECT payload FROM assets WHERE id = ?", (asset_id,)).fetchone()
        if not row:
            return None
        try:
            return APIAsset.model_validate(json.loads(row[0]))
        except Exception:
            return None

    @staticmethod
    def _image_dimensions(data: bytes, kind: str) -> tuple[int | None, int | None]:
        if kind == "png" and len(data) >= 24:
            return int.from_bytes(data[16:20], "big"), int.from_bytes(data[20:24], "big")
        if kind == "gif" and len(data) >= 10:
            return int.from_bytes(data[6:8], "little"), int.from_bytes(data[8:10], "little")
        if kind == "jpeg":
            index = 2
            while index + 9 < len(data):
                if data[index] != 0xFF:
                    index += 1
                    continue
                marker = data[index + 1]
                if marker in range(0xC0, 0xC4):
                    return int.from_bytes(data[index + 7 : index + 9], "big"), int.from_bytes(
                        data[index + 5 : index + 7], "big"
                    )
                if index + 4 > len(data):
                    break
                length = int.from_bytes(data[index + 2 : index + 4], "big")
                index += max(length + 2, 2)
        return None, None

    async def save_asset(self, data: bytes, content_type: str) -> APIAsset:
        kind, expected_mime = validate_image_bytes(data, content_type)
        asset_id = uuid.uuid4().hex
        suffix = "jpg" if kind == "jpeg" else kind
        target = self.output_dir.parent / "api-assets" / f"{asset_id}.{suffix}"
        target.parent.mkdir(parents=True, exist_ok=True)
        await asyncio.to_thread(target.write_bytes, data)
        width, height = self._image_dimensions(data, kind)
        asset = APIAsset(
            id=asset_id,
            mime_type=expected_mime,
            size=len(data),
            width=width,
            height=height,
            local_file=str(target.resolve()),
        )
        await asyncio.to_thread(self._persist_asset_sync, asset)
        return asset

    async def get_asset(self, asset_id: str) -> APIAsset | None:
        return await asyncio.to_thread(self._get_asset_sync, asset_id)

    @staticmethod
    def allowed_download_hosts() -> set[str]:
        configured = os.getenv(
            "FLOW_API_DOWNLOAD_HOSTS",
            "googleusercontent.com,googleapis.com,google.com,flow-content.google",
        )
        return {host.strip().lower().rstrip(".") for host in configured.split(",") if host.strip()}

    def download_url_allowed(self, url: str) -> bool:
        parsed = urlparse(url)
        hostname = (parsed.hostname or "").lower().rstrip(".")
        return (
            parsed.scheme == "https"
            and parsed.username is None
            and parsed.password is None
            and any(
                hostname == allowed or hostname.endswith(f".{allowed}")
                for allowed in self.allowed_download_hosts()
            )
        )

    @staticmethod
    def _request_hash(request: Any) -> str:
        if hasattr(request, "model_dump"):
            payload = request.model_dump(mode="json")
        else:
            payload = request
        canonical = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def _get_idempotency_sync(self, scope: str, key: str) -> tuple[str, str, str] | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT request_hash, resource_type, resource_id FROM idempotency_keys "
                "WHERE scope = ? AND key = ?",
                (scope, key),
            ).fetchone()
        if not row:
            return None
        return str(row[0]), str(row[1]), str(row[2])

    def _save_idempotency_sync(
        self,
        scope: str,
        key: str,
        request_hash: str,
        resource_type: str,
        resource_id: str,
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO idempotency_keys "
                "(scope, key, request_hash, resource_type, resource_id, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (scope, key, request_hash, resource_type, resource_id, time.time()),
            )

    async def _idempotent_resource(
        self, scope: str, key: str, request_hash: str, resource_type: str
    ) -> str | None:
        stored = await asyncio.to_thread(self._get_idempotency_sync, scope, key)
        if not stored:
            return None
        stored_hash, stored_type, resource_id = stored
        if stored_hash != request_hash or stored_type != resource_type:
            raise IdempotencyConflict("idempotency key was already used with a different request")
        return resource_id

    @property
    def active_jobs(self) -> int:
        return sum(1 for task in self._tasks.values() if not task.done())

    async def submit_video(
        self, request: VideoCreateRequest, idempotency_key: str | None = None
    ) -> APIJob:
        if idempotency_key:
            async with self._idempotency_lock:
                request_hash = self._request_hash(request)
                resource_id = await self._idempotent_resource(
                    "videos", idempotency_key, request_hash, "job"
                )
                if resource_id:
                    existing = await self.get_job(resource_id)
                    if existing:
                        return existing
                    raise RuntimeError("idempotency record points to a missing job")
                job = await self._submit_video(request)
                await asyncio.to_thread(
                    self._save_idempotency_sync,
                    "videos",
                    idempotency_key,
                    request_hash,
                    "job",
                    job.id,
                )
                return job
        return await self._submit_video(request)

    async def _submit_video(self, request: VideoCreateRequest) -> APIJob:
        job_id = uuid.uuid4().hex
        job = APIJob(
            id=job_id,
            media_type="video",
            prompt=request.prompt,
            aspect=request.aspect,
            model=request.model,
            duration=request.duration,
            project_id=request.project_id,
        )
        await self._enqueue(job, self._run_video(job_id, request))
        return job.model_copy(deep=True)

    async def submit_image(
        self, request: ImageCreateRequest, idempotency_key: str | None = None
    ) -> APIJob:
        if idempotency_key:
            async with self._idempotency_lock:
                request_hash = self._request_hash(request)
                resource_id = await self._idempotent_resource(
                    "images", idempotency_key, request_hash, "job"
                )
                if resource_id:
                    existing = await self.get_job(resource_id)
                    if existing:
                        return existing
                    raise RuntimeError("idempotency record points to a missing job")
                job = await self._submit_image(request)
                await asyncio.to_thread(
                    self._save_idempotency_sync,
                    "images",
                    idempotency_key,
                    request_hash,
                    "job",
                    job.id,
                )
                return job
        return await self._submit_image(request)

    async def _submit_image(self, request: ImageCreateRequest) -> APIJob:
        job_id = uuid.uuid4().hex
        job = APIJob(
            id=job_id,
            media_type="image",
            prompt=request.prompt,
            aspect=request.aspect,
            model=request.model,
            requested_count=request.count,
            project_id=request.project_id,
        )
        await self._enqueue(job, self._run_image(job_id, request))
        return job.model_copy(deep=True)

    async def submit_batch(
        self, request: BatchCreateRequest, idempotency_key: str | None = None
    ) -> APIBatch:
        if idempotency_key:
            async with self._idempotency_lock:
                request_hash = self._request_hash(request)
                resource_id = await self._idempotent_resource(
                    "batches", idempotency_key, request_hash, "batch"
                )
                if resource_id:
                    existing = await self.get_batch(resource_id)
                    if existing:
                        return existing
                    raise RuntimeError("idempotency record points to a missing batch")
                batch = await self._submit_batch(request)
                await asyncio.to_thread(
                    self._save_idempotency_sync,
                    "batches",
                    idempotency_key,
                    request_hash,
                    "batch",
                    batch.id,
                )
                return batch
        return await self._submit_batch(request)

    async def _submit_batch(self, request: BatchCreateRequest) -> APIBatch:
        batch_id = uuid.uuid4().hex
        jobs: list[APIJob] = []
        for item in request.jobs:
            if isinstance(item, BatchVideoRequest):
                jobs.append(
                    await self.submit_video(
                        VideoCreateRequest.model_validate(item.model_dump(exclude={"type"}))
                    )
                )
            else:
                jobs.append(
                    await self.submit_image(
                        ImageCreateRequest.model_validate(item.model_dump(exclude={"type"}))
                    )
                )
        batch = APIBatch(id=batch_id, total=len(jobs), job_ids=[job.id for job in jobs])

        def persist() -> None:
            with self._connect() as conn:
                conn.execute(
                    "INSERT INTO batches (id, payload, updated_at) VALUES (?, ?, ?)",
                    (batch.id, batch.model_dump_json(), time.time()),
                )

        await asyncio.to_thread(persist)
        return batch

    async def submit_download(
        self, request: DownloadCreateRequest, idempotency_key: str | None = None
    ) -> APIJob:
        if idempotency_key:
            async with self._idempotency_lock:
                request_hash = self._request_hash(request)
                resource_id = await self._idempotent_resource(
                    "downloads", idempotency_key, request_hash, "job"
                )
                if resource_id:
                    existing = await self.get_job(resource_id)
                    if existing:
                        return existing
                    raise RuntimeError("idempotency record points to a missing job")
                job = await self._submit_download(request)
                await asyncio.to_thread(
                    self._save_idempotency_sync,
                    "downloads",
                    idempotency_key,
                    request_hash,
                    "job",
                    job.id,
                )
                return job
        return await self._submit_download(request)

    async def _submit_download(self, request: DownloadCreateRequest) -> APIJob:
        job_id = uuid.uuid4().hex
        requested_count = request.limit if isinstance(request, HistoryDownloadRequest) else 1
        job = APIJob(
            id=job_id,
            media_type=request.media_type,
            prompt=f"{request.type} download",
            aspect="source",
            model="download",
            requested_count=requested_count,
            project_id=request.project_id if isinstance(request, HistoryDownloadRequest) else None,
        )
        await self._enqueue(job, self._run_download(job_id, request))
        return job.model_copy(deep=True)

    async def get_batch(self, batch_id: str) -> APIBatch | None:
        def load() -> APIBatch | None:
            with self._connect() as conn:
                row = conn.execute(
                    "SELECT payload FROM batches WHERE id = ?", (batch_id,)
                ).fetchone()
            return APIBatch.model_validate_json(row[0]) if row else None

        batch = await asyncio.to_thread(load)
        if not batch:
            return None
        jobs = [job for job_id in batch.job_ids if (job := await self.get_job(job_id))]
        completed = sum(job.state == "SUCCEEDED" for job in jobs)
        failed = sum(job.state == "FAILED" for job in jobs)
        running = any(job.state == "RUNNING" for job in jobs)
        if completed + failed == batch.total:
            state = "SUCCEEDED" if failed == 0 else "FAILED" if completed == 0 else "PARTIAL"
        elif running or completed or failed:
            state = "RUNNING"
        else:
            state = "QUEUED"
        return batch.model_copy(update={"state": state, "completed": completed, "failed": failed})

    async def get_batch_jobs(self, batch_id: str) -> list[APIJob] | None:
        batch = await self.get_batch(batch_id)
        if not batch:
            return None
        return [job for job_id in batch.job_ids if (job := await self.get_job(job_id))]

    async def _enqueue(self, job: APIJob, worker: Coroutine[Any, Any, None]) -> None:
        async with self._lock:
            self._jobs[job.id] = job
            await asyncio.to_thread(self._persist_sync, job)
            task = asyncio.create_task(worker)
            self._tasks[job.id] = task
            task.add_done_callback(lambda _task: self._tasks.pop(job.id, None))

    async def get_job(self, job_id: str) -> APIJob | None:
        async with self._lock:
            job = self._jobs.get(job_id)
            return job.model_copy(deep=True) if job else None

    async def list_jobs(self) -> list[APIJob]:
        async with self._lock:
            jobs = sorted(self._jobs.values(), key=lambda item: item.created_at, reverse=True)
            return [job.model_copy(deep=True) for job in jobs]

    async def _update(self, job_id: str, **changes: object) -> None:
        async with self._lock:
            job = self._jobs[job_id]
            updated = job.model_copy(update=changes)
            self._jobs[job_id] = updated
            await asyncio.to_thread(self._persist_sync, updated)

    def _public_error(self, exc: Exception) -> str:
        message = str(exc)
        message = re.sub(r"https?://\S+", "[remote URL]", message)
        message = re.sub(r"(?i)\b[a-z]:[\\/][^\s\"']+", "[local path]", message)
        for local_path in (self.output_dir, self.db_path.parent):
            message = message.replace(str(local_path), "[local path]")
        return f"{type(exc).__name__}: {message[:1_000]}"

    @staticmethod
    def _artifact(
        job_id: str,
        path: Path,
        kind: str,
        *,
        width: int | None = None,
        height: int | None = None,
    ) -> APIArtifact:
        artifact_id = uuid.uuid4().hex
        mime = mimetypes.guess_type(path.name)[0]
        if not mime:
            mime = "video/mp4" if kind == "video" else "application/octet-stream"
        return APIArtifact(
            id=artifact_id,
            kind=kind,  # type: ignore[arg-type]
            mime_type=mime,
            size=path.stat().st_size if path.is_file() else None,
            download_url=f"/v1/jobs/{job_id}/artifacts/{artifact_id}/download",
            local_file=str(path.resolve()),
            width=width,
            height=height,
        )

    async def _run_video(self, job_id: str, request: VideoCreateRequest) -> None:
        async with self._semaphore:
            await self._update(job_id, state="RUNNING", started_at=time.time())
            started = time.monotonic()
            try:
                image_path: str | None = None
                if request.input_asset_id:
                    asset = await self.get_asset(request.input_asset_id)
                    if not asset or not asset.local_file or not Path(asset.local_file).is_file():
                        raise ValueError("input asset not found or no longer available")
                    image_path = asset.local_file
                client = await asyncio.to_thread(self.client_factory, project_id=request.project_id)
                submitted = await client.generate_video(
                    prompt=request.prompt,
                    aspect=request.aspect,
                    model=request.model,
                    duration=request.duration,
                    image_path=image_path,
                    headless=True,
                    timeout=request.timeout,
                )
                await self._update(
                    job_id,
                    project_id=submitted.project_id,
                    upstream_job_id=submitted.job_id,
                    media_id=submitted.media_id,
                    workflow_id=submitted.workflow_id,
                    operation_name=submitted.operation_name,
                    resource_name=submitted.resource_name,
                )
                remaining = request.timeout - int(time.monotonic() - started)
                if remaining <= 0:
                    raise TimeoutError(f"overall generation timeout after {request.timeout}s")
                completed = await client.wait_for_video(
                    submitted, timeout=remaining, poll_interval=5
                )
                self.output_dir.mkdir(parents=True, exist_ok=True)
                files = await client.download(completed.raw, self.output_dir)
                if not files:
                    raise RuntimeError("generation completed but no file was downloaded")
                output = Path(files[0]).resolve()
                artifact = self._artifact(job_id, output, "video")
                await self._update(
                    job_id,
                    state="SUCCEEDED",
                    media_id=completed.media_id,
                    workflow_id=completed.workflow_id,
                    operation_name=completed.operation_name,
                    resource_name=completed.resource_name,
                    output_file=str(output),
                    download_url=f"/v1/jobs/{job_id}/download",
                    artifacts=[artifact],
                    completed_count=1,
                    completed_at=time.time(),
                )
            except (FlowError, OSError, RuntimeError, TimeoutError, ValueError) as exc:
                await self._update(
                    job_id,
                    state="FAILED",
                    error=self._public_error(exc),
                    completed_at=time.time(),
                )
            except Exception:  # pragma: no cover - final containment boundary
                await self._update(
                    job_id,
                    state="FAILED",
                    error="UnexpectedError: internal job failure",
                    completed_at=time.time(),
                )

    async def _run_image(self, job_id: str, request: ImageCreateRequest) -> None:
        async with self._semaphore:
            await self._update(job_id, state="RUNNING", started_at=time.time())
            try:
                client = await asyncio.to_thread(self.client_factory, project_id=request.project_id)
                images = await client.generate_image(
                    prompt=request.prompt,
                    aspect=request.aspect,
                    count=request.count,
                    model=request.model,
                    headless=True,
                    timeout=request.timeout,
                )
                if len(images) < request.count:
                    raise RuntimeError(
                        f"partial image result: requested {request.count}, received {len(images)}"
                    )
                target_dir = self.output_dir / job_id
                target_dir.mkdir(parents=True, exist_ok=True)
                artifacts: list[APIArtifact] = []
                for image in images[: request.count]:
                    raw = dict(image.raw)
                    raw.setdefault("name", image.image_id)
                    if image.fife_url and not any(
                        raw.get(key) for key in ("fifeUrl", "url", "downloadUrl")
                    ):
                        raw["fifeUrl"] = image.fife_url
                    files = await client.download(raw, target_dir)
                    if not files:
                        raise RuntimeError(f"image {image.image_id} has no downloadable artifact")
                    artifacts.append(
                        self._artifact(
                            job_id,
                            Path(files[0]),
                            "image",
                            width=image.width,
                            height=image.height,
                        )
                    )
                    await self._update(job_id, completed_count=len(artifacts))
                await self._update(
                    job_id,
                    state="SUCCEEDED",
                    artifacts=artifacts,
                    completed_count=len(artifacts),
                    completed_at=time.time(),
                )
            except (FlowError, OSError, RuntimeError, TimeoutError, ValueError) as exc:
                await self._update(
                    job_id,
                    state="FAILED",
                    error=self._public_error(exc),
                    completed_at=time.time(),
                )
            except Exception:  # pragma: no cover - final containment boundary
                await self._update(
                    job_id,
                    state="FAILED",
                    error="UnexpectedError: internal job failure",
                    completed_at=time.time(),
                )

    async def _run_download(self, job_id: str, request: DownloadCreateRequest) -> None:
        async with self._semaphore:
            await self._update(job_id, state="RUNNING", started_at=time.time())
            try:
                client = await asyncio.to_thread(
                    self.client_factory,
                    project_id=request.project_id
                    if isinstance(request, HistoryDownloadRequest)
                    else None,
                )
                target_dir = self.output_dir / job_id
                target_dir.mkdir(parents=True, exist_ok=True)
                files: list[Path] = []
                if isinstance(request, URLDownloadRequest):
                    if not self.download_url_allowed(str(request.url)):
                        raise ValueError("download URL is not on the HTTPS allowlist")
                    files = [
                        await client.download_url(
                            str(request.url),
                            target_dir,
                            request.media_type,
                            self.allowed_download_hosts(),
                        )
                    ]
                elif isinstance(request, MediaDownloadRequest):
                    media = await client.get_media(request.media_id)
                    files = await client.download(media, target_dir)
                else:
                    workflows = await client.fetch_history(
                        media_type=request.media_type,
                        limit=request.limit,
                        project_id=request.project_id,
                    )
                    for workflow in workflows[: request.limit]:
                        files.extend(await client.download(workflow, target_dir))
                if not files:
                    raise RuntimeError("download source contained no downloadable media")
                artifacts = [
                    self._artifact(job_id, Path(path), request.media_type) for path in files
                ]
                output = str(Path(files[0]).resolve()) if request.media_type == "video" else None
                await self._update(
                    job_id,
                    state="SUCCEEDED",
                    artifacts=artifacts,
                    completed_count=len(artifacts),
                    output_file=output,
                    download_url=f"/v1/jobs/{job_id}/download" if output else None,
                    completed_at=time.time(),
                )
            except (FlowError, OSError, RuntimeError, TimeoutError, ValueError) as exc:
                await self._update(
                    job_id,
                    state="FAILED",
                    error=self._public_error(exc),
                    completed_at=time.time(),
                )
            except Exception:  # pragma: no cover - final containment boundary
                await self._update(
                    job_id,
                    state="FAILED",
                    error="UnexpectedError: internal job failure",
                    completed_at=time.time(),
                )

    async def shutdown(self) -> None:
        tasks = [task for task in self._tasks.values() if not task.done()]
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
