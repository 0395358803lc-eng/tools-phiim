"""UI selector profile - isolates fragile selectors.

Selector priority (per plan 3.7):
    1. data-testid / stable attributes
    2. ARIA role + accessible name
    3. structural relationship within a known panel
    4. displayed text (locale) as last-resort fallback

Keep all text-based fallbacks here so that updating to a new UI profile is a
single-file change backed by a fixture/screenshot.
"""

from __future__ import annotations

import re

# Map normalized video model -> ordered list of UI display-label candidates.
VIDEO_MODEL_UI_LABELS: dict[str, list[str]] = {
    "veo-3.1-lite-lower-priority": ["Veo 3.1 - Lite [Lower Priority]"],
    "veo-3-fast": ["Veo 3 Fast", "Veo 3 - Fast"],
    "veo-3-lite": ["Veo 3 Lite", "Veo 3 - Lite"],
    "veo-3.1-lite": ["Veo 3.1 - Lite", "Veo 3.1 Lite", "Veo 3.1 lite"],
    "veo-3.1-fast": ["Veo 3.1 - Fast", "Veo 3.1 Fast"],
    "veo-3.1": ["Veo 3.1", "Veo 3.1 - Quality", "Quality"],
    "veo-3": ["Veo 3", "Veo 3 - Quality"],
    "veo-2-fast": ["Veo 2 - Fast", "Veo 2 Fast"],
    "veo-2": ["Veo 2"],
}

# Map normalized image model -> ordered list of UI display-label candidates.
IMAGE_MODEL_UI_LABELS: dict[str, list[str]] = {
    "nano-banana": ["Nano Banana"],
    "nano-banana-pro": ["Nano Banana Pro"],
    "imagen-3": ["Imagen 3"],
    "imagen-4": ["Imagen 4"],
}

# Ordered duration candidates (video).
DURATION_CANDIDATES = ["4", "6", "8"]

# Aspect ratio display candidates.
ASPECT_LABELS: dict[str, list[str]] = {
    "16:9": ["16:9"],
    "9:16": ["9:16"],
    "1:1": ["1:1"],
    "4:3": ["4:3"],
    "3:4": ["3:4"],
    "21:9": ["21:9"],
}

# State-bearing selectors used for post-condition checks. Text-only option
# selectors may click the intended control, but only one of these selected-state
# attributes (or a scoped trigger label) is accepted as proof.
SELECTED_OPTION_TEMPLATES = (
    '[role="option"][aria-selected="true"]:has-text("{label}")',
    '[role="radio"][aria-checked="true"]:has-text("{label}")',
    'button[aria-pressed="true"]:has-text("{label}")',
    'button[data-state="on"]:has-text("{label}")',
    '[data-state="checked"]:has-text("{label}")',
)

ASPECT_TRIGGER_SELECTORS = (
    '[aria-label*="aspect" i]',
    '[data-testid*="aspect" i]',
    'button:has-text("Aspect")',
)
DURATION_TRIGGER_SELECTORS = (
    '[aria-label*="duration" i]',
    '[data-testid*="duration" i]',
    'button:has-text("Duration")',
)
COUNT_TRIGGER_SELECTORS = (
    '[aria-label*="output count" i]',
    '[aria-label*="outputs" i]',
    '[data-testid*="count" i]',
)
MEDIA_SELECTED_SELECTORS: dict[str, tuple[str, ...]] = {
    "video": (
        '[role="tab"][aria-selected="true"]:has-text("Video")',
        'button[aria-pressed="true"]:has-text("Video")',
        'button[data-state="active"]:has-text("Video")',
    ),
    "image": (
        '[role="tab"][aria-selected="true"]:has-text("Image")',
        'button[aria-pressed="true"]:has-text("Image")',
        'button[data-state="active"]:has-text("Image")',
    ),
}

# Remaining selectors for the current Flow Web profile. Keeping them out of
# ``_flow_ui.py`` makes an upstream UI revision a profile-only change.
DISMISS_SELECTORS = (
    'button:has-text("Accept")',
    'button:has-text("I agree")',
    'button:has-text("Continue")',
    '[aria-label="Close"]',
)
PROMPT_EDITOR_SELECTOR = '[contenteditable="true"]'
PROMPT_FALLBACK_SELECTORS = (
    'textarea[placeholder*="prompt" i]',
    'textarea[placeholder*="Describe" i]',
    "textarea",
    'input[placeholder*="prompt" i]',
)
ASPECT_OPTION_TEMPLATE = 'button:has-text("{label}")'
DURATION_OPEN_SELECTORS = (
    'button:has-text("Duration")',
    '[aria-label*="duration" i]',
    'button:has-text("sec")',
)
DURATION_OPTION_TEMPLATES = (
    '[role="option"]:has-text("{label}")',
    'button:has-text("{label}")',
    'dialog button:has-text("{label}")',
)
COUNT_OPTION_TEMPLATES = (
    'button:has-text("x{label}")',
    '[role="option"]:has-text("{label}")',
    'button:has-text("{label}")',
    '[aria-label*="{label}" i]',
)
FILE_INPUT_SELECTOR = 'input[type="file"]'
UPLOAD_COMPLETE_SELECTOR = "img[src*='googleusercontent']"
MODEL_READ_SELECTORS = (
    'button:has-text("Veo")',
    'button:has-text("Nano")',
    'button:has-text("Imagen")',
    '[aria-label*="model" i]',
    'button:has-text("Model")',
)
EXACT_TEXT_TEMPLATE = 'text="{label}"'
MEDIA_TAB_TEMPLATE = 'button:has-text("{label}")'
LEGACY_IMAGE_MODEL_BUTTON = 'button:has-text("Nano Banana")'
LEGACY_VIDEO_MODEL_BUTTON = 'button:has-text("Video")'
RADIX_ITEM_SELECTOR = "[data-radix-collection-item]"
IMAGE_TAB_SELECTOR = 'button:has-text("Image")'
VIDEO_TAB_SELECTOR = 'button:has-text("Video")'
OMNI_MODEL_SELECTOR = 'button:has-text("Omni")'
VIDEO_SETTINGS_SELECTOR = 'button:has-text("Video ·")'
MODEL_DROPDOWN_SELECTORS = (
    OMNI_MODEL_SELECTOR,
    'button:has-text("Veo")',
    'button:has-text("Model")',
    '[aria-label*="model" i]',
    'button:has-text("Nano")',
    'button:has-text("Imagen")',
)
MODEL_BUTTON_TEMPLATE = 'button:has-text("{label}")'
MODEL_OPTION_TEMPLATES = (
    MODEL_BUTTON_TEMPLATE,
    '[role="option"]:has-text("{label}")',
)
IMAGE_MODEL_OPTION_TEMPLATES = (
    '[role="menuitem"]:has-text("{label}")',
    '[data-radix-collection-item]:has-text("{label}")',
    '[role="option"]:has-text("{label}")',
    MODEL_BUTTON_TEMPLATE,
)
GENERATE_ARROW_SELECTOR = 'button:has-text("arrow_forward")'
CREATE_BUTTON_SELECTOR = 'button:has-text("Create")'
GENERATE_FALLBACK_SELECTORS = (
    'button:has-text("Generate")',
    CREATE_BUTTON_SELECTOR,
    '[aria-label*="Generate" i]',
    'button:has-text("→")',
    'button[type="submit"]',
    '[data-testid*="generate" i]',
)
GENERATION_COMPLETE_SELECTORS = (
    "video",
    UPLOAD_COMPLETE_SELECTOR,
    "[data-testid*='media']",
    "canvas",
)


def model_matches(requested: str, selected: str) -> bool:
    """Check whether the currently-selected UI model corresponds to `requested`.

    Matching is deliberately allowlist-based. Version, tier and priority are
    all part of the model identity; a generic ``Lite``/``Fast`` substring is
    never sufficient evidence.
    """
    if not requested or not selected:
        return False
    req = requested.strip().lower().replace(" ", "-")
    candidates = VIDEO_MODEL_UI_LABELS.get(req) or IMAGE_MODEL_UI_LABELS.get(req)
    if not candidates:
        return False

    def identity_tokens(value: str) -> tuple[str, ...]:
        normalized = value.casefold().replace("–", "-").replace("—", "-")
        return tuple(re.findall(r"[a-z0-9]+(?:\.[0-9]+)?", normalized))

    selected_identity = identity_tokens(selected)
    return any(selected_identity == identity_tokens(candidate) for candidate in candidates)
