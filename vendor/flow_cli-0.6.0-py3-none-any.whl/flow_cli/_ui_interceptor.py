"""UIInterceptor - captures aisandbox-pa requests triggered by real UI clicks (for reCAPTCHA)."""

from __future__ import annotations

import asyncio
import json
from collections.abc import Callable
from typing import Any


class UIInterceptor:
    """Listens to all aisandbox-pa.googleapis.com traffic, captures request/response
    when user (or automation) clicks the real Generate button.

    Flow's generation endpoints are protected by reCAPTCHA Enterprise.
    Token is only valid when generated via grecaptcha.enterprise.execute() inside
    the page's MAIN world after a user gesture. This interceptor waits for that
    network call and extracts results.
    """

    def __init__(self, page: Any):
        self.page = page
        self.captured: list[dict[str, Any]] = []
        self._handlers: list[Callable[[dict[str, Any]], None]] = []
        self._active = False

    async def start(self):
        if self._active:
            return
        self._active = True

        def handle_request(request: Any):
            url = request.url
            # Debug: log all aisandbox
            if "aisandbox-pa.googleapis.com" in url:
                # print(f"[INTERCEPTOR REQ] {request.method} {url[:120]}")
                pass
            if "aisandbox-pa.googleapis.com" in url and (
                "generate" in url.lower()
                or "video" in url.lower()
                or "media" in url.lower()
                or "whisk" in url.lower()
                or "flow" in url.lower()
            ):
                try:
                    # Don't await all_headers here to avoid async issues - capture sync
                    try:
                        headers = {}  # will fill async if needed
                    except Exception:
                        headers = {}
                    post_data = request.post_data
                    # Try to get headers sync if available, else empty
                    entry: dict[str, Any] = {
                        "url": url,
                        "method": request.method,
                        "headers": headers,
                        "postData": post_data,
                        "resourceType": request.resource_type,
                    }
                    self.captured.append(entry)
                    # print(f"[INTERCEPTOR CAPTURED] {url[:100]} total={len(self.captured)}")
                    for h in self._handlers:
                        try:
                            h(entry)
                        except Exception:
                            pass
                except Exception:
                    # print(f"[INTERCEPTOR ERR] {e}")
                    pass

        async def handle_response(response: Any):
            url = response.url
            if "aisandbox-pa.googleapis.com" in url:
                try:
                    status = response.status
                    body = None
                    try:
                        body = await response.json()
                    except Exception:
                        try:
                            body = await response.text()
                            if body:
                                body = json.loads(body) if body.strip().startswith("{") else body
                        except Exception:
                            body = None
                    # Attach to last captured request if url matches
                    for entry in reversed(self.captured):
                        if entry["url"] == url and "response" not in entry:
                            entry["response"] = {"status": status, "body": body}
                            entry["responseHeaders"] = await response.all_headers()
                            break
                except Exception:
                    pass

        self.page.on("request", handle_request)
        self.page.on("response", handle_response)
        # Also listen to requestfinished for timing
        self._handle_request = handle_request
        self._handle_response = handle_response

    async def stop(self):
        if not self._active:
            return
        try:
            self.page.remove_listener("request", self._handle_request)
            self.page.remove_listener("response", self._handle_response)
        except Exception:
            pass
        self._active = False

    def on_capture(self, handler: Callable[[dict[str, Any]], None]):
        self._handlers.append(handler)

    async def wait_for_capture(
        self, predicate: Callable[[dict[str, Any]], bool] | None = None, timeout: float = 60.0
    ) -> dict[str, Any]:
        """Wait until a captured request matches predicate."""
        start = asyncio.get_event_loop().time()
        while (asyncio.get_event_loop().time() - start) < timeout:
            for entry in self.captured:
                if predicate is None or predicate(entry):
                    if "response" in entry:
                        return entry
                    # Has request but no response yet - wait a bit more
                    await asyncio.sleep(0.5)
                    if "response" in entry:
                        return entry
            await asyncio.sleep(0.5)
        raise TimeoutError(
            f"No matching capture within {timeout}s. Captured {len(self.captured)} requests"
        )

    def get_last(self) -> dict[str, Any] | None:
        return self.captured[-1] if self.captured else None

    def clear(self):
        self.captured.clear()
