"""Job identity and state machine.

States:
    CREATED -> SUBMITTED -> QUEUED -> RUNNING -> SUCCEEDED
                                      |          |
                                      +-> FAILED +-> DOWNLOADED

Each transition is recorded so that a job never falls back to an unverified
"most recent workflow" from another generation.
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class JobState(StrEnum):
    CREATED = "CREATED"
    SUBMITTED = "SUBMITTED"
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    DOWNLOADED = "DOWNLOADED"

    @property
    def is_terminal(self) -> bool:
        return self in (JobState.SUCCEEDED, JobState.FAILED)

    @property
    def is_success(self) -> bool:
        return self in (JobState.SUCCEEDED, JobState.DOWNLOADED)


def prompt_hash(prompt: str) -> str:
    return hashlib.sha256(prompt.encode("utf-8")).hexdigest()[:16]


@dataclass
class JobIdentity:
    """Identity record used to match a polled workflow to the current job.

    Never falls back to "most recent" unless every discriminator matches.
    """

    project_id: str | None = None
    workflow_id: str | None = None
    operation_name: str | None = None
    media_id: str | None = None
    resource_name: str | None = None
    prompt: str | None = None
    prompt_hash: str | None = None
    media_type: str | None = None
    model: str | None = None
    submitted_at: float | None = None

    @property
    def ph(self) -> str | None:
        return self.prompt_hash or (prompt_hash(self.prompt) if self.prompt else None)

    def matches(self, media: dict[str, Any]) -> tuple[bool, list[str]]:
        """Return (found_evidence, missing_required).

        A candidate media matches the job if we have positive evidence it belongs
        to this job. If no identifier is known, we return False with the list of
        missing discriminators so the caller can raise instead of guessing.
        """
        evidence: list[str] = []
        missing: list[str] = []

        name = media.get("name") or media.get("media", {}).get("name")
        workflow_id = media.get("workflowId") or media.get("media", {}).get("workflowId")
        media_id_inner = media.get("mediaGenerationId", {}).get("mediaId") or media.get(
            "mediaGenerationId", {}
        ).get("id")
        resource_name = media.get("resourceName") or name

        def id_matches(full: Any, expected: str) -> bool:
            """Match identifiers even when the wire name carries a type prefix."""
            if full is None:
                return False
            s = str(full)
            return s == expected or s.endswith(f"/{expected}")

        # A positive match requires at least one strong identifier (workflow,
        # operation or media id) agreeing. project_id is only supplementary
        # context and is never strong enough on its own — otherwise we could
        # claim a match for a *different* job that happens to share the project.
        if self.workflow_id and (
            id_matches(name, self.workflow_id) or id_matches(workflow_id, self.workflow_id)
        ):
            evidence.append("workflow_id")
        if self.operation_name and (
            id_matches(name, self.operation_name) or id_matches(workflow_id, self.operation_name)
        ):
            evidence.append("operation_name")
        if self.media_id and (
            id_matches(name, self.media_id) or id_matches(media_id_inner, self.media_id)
        ):
            evidence.append("media_id")
        if self.resource_name and id_matches(resource_name, self.resource_name):
            evidence.append("resource_name")

        if self.project_id:
            proj = media.get("mediaGenerationId", {}).get("projectId")
            if proj == self.project_id:
                # Supplementary only; does not produce a match by itself.
                evidence.append("project_id")

        has_strong_id = bool(
            self.workflow_id or self.operation_name or self.media_id or self.resource_name
        )
        strong_match = bool(
            "workflow_id" in evidence
            or "operation_name" in evidence
            or "media_id" in evidence
            or "resource_name" in evidence
        )

        if not has_strong_id:
            missing.append("identity")
            return False, missing

        # With a strong id supplied we still require it to actually match.
        if not strong_match:
            missing.append("identity")
            return False, missing

        return True, missing


@dataclass
class JobRecord:
    job_id: str
    state: JobState = JobState.CREATED
    project_id: str | None = None
    workflow_id: str | None = None
    operation_name: str | None = None
    media_id: str | None = None
    resource_name: str | None = None
    submitted_at: float = field(default_factory=time.time)
    last_polled_at: float | None = None
    prompt: str | None = None
    prompt_hash: str | None = None
    aspect: str | None = None
    duration: int | None = None
    media_type: str | None = None
    model: str | None = None
    error: str | None = None
    media: dict[str, Any] = field(default_factory=dict)

    def identity(self) -> JobIdentity:
        return JobIdentity(
            project_id=self.project_id,
            workflow_id=self.workflow_id,
            operation_name=self.operation_name,
            media_id=self.media_id,
            resource_name=self.resource_name,
            prompt=self.prompt,
            prompt_hash=self.prompt_hash,
            media_type=self.media_type,
            model=self.model,
            submitted_at=self.submitted_at,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "job_id": self.job_id,
            "state": self.state.value,
            "project_id": self.project_id,
            "workflow_id": self.workflow_id,
            "operation_name": self.operation_name,
            "media_id": self.media_id,
            "resource_name": self.resource_name,
            "submitted_at": self.submitted_at,
            "last_polled_at": self.last_polled_at,
            "prompt_hash": self.prompt_hash or prompt_hash(self.prompt or ""),
            "aspect": self.aspect,
            "duration": self.duration,
            "media_type": self.media_type,
            "model": self.model,
            "error": self.error,
        }

    def mark_polled(self) -> None:
        self.last_polled_at = time.time()
