"""CLI entrypoint - flow / flow-cli"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, NoReturn

import click
from rich import box
from rich.console import Console
from rich.table import Table

from flow_cli import __version__
from flow_cli._api import FlowAPI
from flow_cli._auth import (
    load_saved_cookies,
    save_cookies_from_input,
    validate_cookies,
)
from flow_cli._exceptions import (
    AuthError,
    FlowError,
    GenerationTimeout,
    SessionExpiredError,
    UpstreamChangedError,
)
from flow_cli._logging import json_dumps_redacted
from flow_cli._models import DEFAULT_VIDEO_MODEL
from flow_cli._storage import (
    clear_storage,
    get_config_dir,
    get_config_path,
    get_cookies_path,
    load_config,
)

console = Console(legacy_windows=False)
err_console = Console(stderr=True, legacy_windows=False)

# ---------- Helpers ----------


def _load_cookies_or_exit() -> dict[str, Any]:
    try:
        return load_saved_cookies()
    except AuthError as e:
        err_console.print(f"[red]Auth error:[/red] {e}")
        sys.exit(1)


def _print_json(data: Any, pretty: bool = True):
    redacted = json_dumps_redacted(data)
    if pretty:
        console.print_json(redacted)
    else:
        console.print(redacted)


def _exit_error(exc: Exception) -> NoReturn:
    """Print an error and exit with the mapped FlowError exit code."""
    code = exc.exit_code if isinstance(exc, FlowError) else 1
    err_console.print(f"[red]{type(exc).__name__}:[/red] {exc}")
    sys.exit(code)


def _find_playwright_chromium() -> bool | None:
    """Return True/False if a Playwright chromium executable is installed on disk.

    Returns None when the location cannot be determined (unknown, not a false
    'available'). Never launches a browser. Returns a boolean (not a path) so
    doctor does not print a filesystem path that could leak.
    """
    import glob
    import os

    exe_name = "chrome.exe" if os.name == "nt" else "chrome"
    bases: list[str] = []
    if os.name == "nt":
        local = os.environ.get("LOCALAPPDATA", "")
        if local:
            bases.append(os.path.join(local, "ms-playwright"))
    else:
        bases.append(os.path.join(os.path.expanduser("~"), ".cache", "ms-playwright"))
    for base in bases:
        if not base or not os.path.isdir(base):
            continue
        for d in glob.glob(os.path.join(base, "chromium*")):
            for _root, _dirs, files in os.walk(d):
                if exe_name in files:
                    return True
    return False


def _fmt_bool(value: bool | None) -> str:
    if value is True:
        return "yes"
    if value is False:
        return "no"
    return "unknown"


# ---------- Root ----------


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(__version__, prog_name="flow")
def cli():
    """flow-cli - Unofficial Google Flow CLI via cookie auth (Veo 3.1 / Nano Banana)

    Login via browser cookies (no password needed):

      flow login --cookie "1PSID=...; HSID=..."

      flow login --cookie-file cookies.json    # Export from Cookie-Editor extension

    Then use:

      flow credits

      flow history --type video

      flow generate video "cinematic temple at dusk"

      flow generate image "mountain lake, photorealistic" --count 4
    """
    pass


# ---------- Auth ----------


@cli.command()
@click.option(
    "--cookie",
    "cookie_str",
    default=None,
    help="Cookie header string: 'a=1; b=2; ...' (paste from DevTools > Application > Cookies)",
)
@click.option(
    "--cookie-file",
    type=click.Path(exists=False, dir_okay=False),
    default=None,
    help="Path to cookies.json (EditThisCookie / Cookie-Editor export)",
)
@click.option(
    "--verify/--no-verify", default=True, help="Verify cookies against Flow API after saving"
)
def login(cookie_str: str | None, cookie_file: str | None, verify: bool):
    """Login with cookies from browser (cookie auth).

    \b
    How to get cookies:
      1. Login https://labs.google/fx/tools/flow in Chrome
      2. F12 > Application > Cookies > https://labs.google > select all > Copy
         OR install 'Cookie-Editor' extension > Export > Export as JSON
      3. Run: flow login --cookie "PASTE_HERE"
              flow login --cookie-file cookies.json
    """
    if not cookie_str and not cookie_file:
        # Try interactive prompt
        console.print("[yellow]No --cookie or --cookie-file provided.[/yellow]")
        console.print("Paste cookie string (or path to JSON file):")
        try:
            inp = click.prompt("cookie", type=str, hide_input=False)
            if inp and Path(inp).exists():
                cookie_file = inp
            else:
                cookie_str = inp
        except Exception:
            pass
        if not cookie_str and not cookie_file:
            err_console.print("[red]Missing cookies. Provide --cookie or --cookie-file[/red]")
            sys.exit(1)

    try:
        cookies = save_cookies_from_input(cookie_str=cookie_str, cookie_file=cookie_file)
        console.print(
            f"[green][OK] Saved {len(cookies)} cookies[/green] to [dim]{get_cookies_path()}[/dim]"
        )
        console.print(f"[dim]Config: {get_config_path()}[/dim]")

        if verify:
            console.print("[dim]Verifying cookies against Flow API...[/dim]")
            ok, msg, _ = validate_cookies(cookies)
            if ok:
                console.print(f"[green][OK] {msg}[/green]")
            else:
                err_console.print(f"[yellow][WARN] {msg}[/yellow]")
                err_console.print(
                    "[dim]Cookies saved but verification failed. They may still work for "
                    "some endpoints, but try re-exporting ALL cookies from "
                    "https://labs.google[/dim]"
                )
                sys.exit(2)
        console.print(
            "\n[bold green]Login successful![/bold green] "
            "Try: [cyan]flow credits[/cyan] or [cyan]flow history[/cyan]"
        )
    except AuthError as e:
        err_console.print(f"[red]Login failed:[/red] {e}")
        sys.exit(1)


@cli.command()
def logout():
    """Clear saved cookies and config."""
    clear_storage()
    console.print(f"[green][OK] Cleared[/green] {get_cookies_path()} and {get_config_path()}")


@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def config(as_json: bool):
    """Show current config & cookie status."""
    cfg = load_config()
    cookies_path = get_cookies_path()
    config_path = get_config_path()
    has_cookies = cookies_path.exists()
    cookie_count = 0
    if has_cookies:
        try:
            from flow_cli._storage import load_cookies_file

            cookie_count = len(load_cookies_file())
        except Exception:
            pass

    if as_json:
        _print_json(
            {
                "config_path": str(config_path),
                "cookies_path": str(cookies_path),
                "has_cookies": has_cookies,
                "cookie_count": cookie_count,
                "config": cfg,
            }
        )
        return

    table = Table(title="flow-cli config", box=box.ROUNDED)
    table.add_column("Key", style="cyan")
    table.add_column("Value", style="white")
    table.add_row("Config dir", str(get_config_dir()))
    table.add_row("Config file", str(config_path))
    table.add_row("Cookies file", str(cookies_path))
    table.add_row("Has cookies", "yes" if has_cookies else "no")
    table.add_row("Cookie count", str(cookie_count))
    table.add_row("Version", __version__)
    if cfg:
        table.add_row("Last login", str(cfg.get("last_login", "-")))
        table.add_row("Has bearer", str(cfg.get("has_bearer", "-")))
    console.print(table)
    if not has_cookies:
        console.print(
            '\n[yellow]No cookies found. Run:[/yellow] [cyan]flow login --cookie "..."[/cyan]'
        )


@cli.command()
@click.option("--timeout", type=int, default=15, help="Timeout seconds")
def verify(timeout: int):
    """Verify saved cookies against Flow API."""
    cookies = _load_cookies_or_exit()
    console.print(f"[dim]Verifying {len(cookies)} cookies...[/dim]")
    ok, msg, data = validate_cookies(cookies, timeout=timeout)
    if ok:
        console.print(f"[green][OK] {msg}[/green]")
        if data:
            console.print("[dim]Sample response keys:[/dim]", list(data.keys())[:5])
    else:
        err_console.print(f"[red][FAIL] {msg}[/red]")
        sys.exit(1)


@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def doctor(as_json: bool):
    """Diagnose the environment, dependencies, config & cookies (never prints secrets)."""
    import importlib
    import platform
    import sys as _sys

    from flow_cli.adapters import current_adapter

    results: dict[str, Any] = {
        "python": f"{_sys.version_info.major}.{_sys.version_info.minor}.{_sys.version_info.micro}",
        "platform": platform.platform(),
        "version": __version__,
        "adapter": current_adapter().name,
        "playwright_installed": False,
        "chromium_installed": False,
        "config_path": str(get_config_path()),
        "cookies_path": str(get_cookies_path()),
        "has_cookies": get_cookies_path().exists(),
        "cookie_count": 0,
        "cookie_hints_present": False,
        "dependencies": {},
    }
    for dep in ["requests", "playwright", "structlog", "tenacity", "rich", "click"]:
        try:
            importlib.import_module(dep)
            results["dependencies"][dep] = True
        except Exception:
            results["dependencies"][dep] = False
    try:
        importlib.import_module("playwright")
        results["playwright_installed"] = True
    except Exception:
        results["playwright_installed"] = False

    # Real disk check for an installed Playwright chromium executable (do not
    # launch a browser here). Path unknown => None (not a false "available").
    results["chromium_installed"] = _find_playwright_chromium()

    from flow_cli._auth import REQUIRED_COOKIE_HINTS

    if get_cookies_path().exists():
        try:
            from flow_cli._storage import load_cookies_file

            cookies = load_cookies_file()
            results["cookie_count"] = len(cookies)
            results["cookie_hints_present"] = any(h in cookies for h in REQUIRED_COOKIE_HINTS)
            results["cookie_names"] = sorted(cookies.keys())  # names only, never values
        except Exception:
            pass

    if as_json:
        _print_json(results)
        return

    table = Table(title="flow-cli doctor", box=box.ROUNDED)
    table.add_column("Check", style="cyan")
    table.add_column("Status", style="white")
    table.add_row("Python", results["python"])
    table.add_row("Platform", results["platform"])
    table.add_row("CLI version", results["version"])
    table.add_row("Adapter profile", results["adapter"])
    table.add_row("Playwright installed", "yes" if results["playwright_installed"] else "no")
    table.add_row("Chromium available", _fmt_bool(results["chromium_installed"]))
    table.add_row("Cookies file", "yes" if results["has_cookies"] else "no")
    table.add_row("Cookie count", str(results["cookie_count"]))
    table.add_row("Cookie hints present", "yes" if results["cookie_hints_present"] else "no")
    table.add_row("Config", str(get_config_path()))
    for dep, ok in results["dependencies"].items():
        table.add_row(f"dep: {dep}", "ok" if ok else "MISSING")
    console.print(table)
    console.print("[dim]Tip: cookie VALUES and tokens are never printed by flow doctor.[/dim]")
    if not results["has_cookies"]:
        console.print(
            '\n[yellow]No cookies found. Run:[/yellow] [cyan]flow login --cookie "..."[/cyan]'
        )


# ---------- Credits / History ----------


@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON")
def credits(as_json: bool):
    """Show remaining Flow credits (read-only, works with cookie auth)."""
    cookies = _load_cookies_or_exit()
    try:
        api = FlowAPI(cookies)
        data = api.get_credits()
        if as_json:
            _print_json(data)
            return
        # Pretty table
        table = Table(title="Flow Credits", box=box.ROUNDED)
        table.add_column("Field", style="cyan")
        table.add_column("Value", style="white")
        for k, v in data.items():
            if k == "raw_text":
                continue
            if isinstance(v, (dict, list)):
                table.add_row(k, json.dumps(v, ensure_ascii=False)[:200])
            else:
                table.add_row(k, str(v))
        console.print(table)
    except UpstreamChangedError as e:
        err_console.print(f"[red]Credits feature unavailable upstream:[/red] {e}")
        err_console.print(
            "[dim]Open https://labs.google/fx/tools/flow and check the top-right "
            "credits indicator[/dim]"
        )
        sys.exit(3)
    except (AuthError, SessionExpiredError) as e:
        err_console.print(
            f'[red]Auth failed:[/red] {e}\n[dim]Re-login: flow login --cookie "..."[/dim]'
        )
        sys.exit(1)


@cli.command()
@click.option(
    "--type",
    "media_type",
    type=click.Choice(["video", "image", "all"], case_sensitive=False),
    default="video",
    help="Media type",
)
@click.option("--limit", type=int, default=10, help="Number of items")
@click.option("--project", "project_id", type=str, default=None, help="Filter by project_id")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON")
def history(media_type: str, limit: int, project_id: str | None, as_json: bool):
    """List generation history (read-only)."""
    cookies = _load_cookies_or_exit()
    api = FlowAPI(cookies)
    try:
        if media_type == "all":
            videos = api.fetch_workflows(media_type="VIDEO", limit=limit, project_id=project_id)
            images = api.fetch_workflows(media_type="IMAGE", limit=limit, project_id=project_id)
            workflows = videos + images
        else:
            workflows = api.fetch_workflows(
                media_type=media_type, limit=limit, project_id=project_id
            )

        if as_json:
            _print_json(workflows)
            return

        if not workflows:
            # Fallback: if video returned 0, try image and vice versa.
            if media_type.lower() == "video":
                fb = api.fetch_workflows(media_type="IMAGE", limit=limit, project_id=project_id)
                if fb:
                    console.print(
                        f"[dim]No VIDEO workflows, showing {len(fb)} IMAGE workflows "
                        f"(PINHOLE fallback)[/dim]"
                    )
                    workflows = fb
            elif media_type.lower() == "image":
                fb = api.fetch_workflows(media_type="VIDEO", limit=limit, project_id=project_id)
                if fb:
                    console.print(
                        f"[dim]No IMAGE workflows, showing {len(fb)} VIDEO workflows[/dim]"
                    )
                    workflows = fb
            if not workflows:
                console.print(
                    "[yellow]No history found.[/yellow] Generate something first or "
                    "check project_id."
                )
                console.print(
                    f"[dim]Project filter: {project_id or 'none'} | Type: {media_type}[/dim]"
                )
                return

        table = Table(title=f"History - {media_type} (limit={limit})", box=box.ROUNDED)
        table.add_column("#", style="dim", width=3)
        table.add_column("Created", style="dim", width=16)
        table.add_column("Type/Model", style="magenta", overflow="fold")
        table.add_column("Prompt", style="white", overflow="fold")
        table.add_column("ID", style="cyan", overflow="fold")
        for i, wf in enumerate(workflows, 1):
            create = (wf.get("createTime") or "")[:16].replace("T", " ")
            media = wf.get("media", {})
            # Detect type
            mtype = media.get("mediaGenerationId", {}).get("mediaType") or (
                "IMAGE" if media.get("image") else "VIDEO" if media.get("video") else "-"
            )
            model = (media.get("image", {}) or media.get("video", {})).get("modelNameType") or "-"
            # Prompt snippet
            prompt = ""
            try:
                req = media.get("requestData", {})
                if req.get("promptInputs") and isinstance(req["promptInputs"], list):
                    prompt = req["promptInputs"][0].get("textInput", "")[:80]
                    if not prompt and req["promptInputs"][0].get("structuredPrompt"):
                        parts = req["promptInputs"][0]["structuredPrompt"].get("parts", [])
                        if parts:
                            prompt = parts[0].get("text", "")[:80]
                if not prompt:
                    prompt = (
                        media.get("image", {}).get("prompt")
                        or media.get("video", {}).get("prompt")
                        or ""
                    )[:80]
            except Exception:
                pass
            if len(prompt) > 77:
                prompt = prompt[:77] + "..."
            short_id = (
                wf.get("name", "")[:28] + "..."
                if len(wf.get("name", "")) > 28
                else wf.get("name", "")
            )
            table.add_row(str(i), create, f"{mtype}/{model}", prompt or "-", short_id)
        console.print(table)
        console.print(
            f"[dim]Found {len(workflows)} workflows. Use --json for full data, or "
            f"flow download --help[/dim]"
        )
        console.print(
            "[dim]Tip: history --json contains full requestData + mediaGenerationId "
            "for polling /v1/media/ID[/dim]"
        )
    except (AuthError, SessionExpiredError) as e:
        err_console.print(f"[red]Auth failed:[/red] {e}")
        sys.exit(1)


@cli.command()
@click.option("--title", type=str, default=None, help="Project title")
@click.option(
    "--type",
    "media_type",
    type=click.Choice(["video", "image"]),
    default="video",
    help="Media type (video -> VIDEO_FX, image -> ASSET_MANAGER)",
)
@click.option(
    "--tool",
    type=str,
    default=None,
    help="Override tool name (e.g. PINHOLE, ASSET_MANAGER). Defaults to adapter mapping by --type.",
)
@click.option("--json", "as_json", is_flag=True)
def create_project(title: str | None, media_type: str, tool: str | None, as_json: bool):
    """Create a new Flow project (needed before generation)."""
    from flow_cli.adapters import current_adapter

    cookies = _load_cookies_or_exit()
    api = FlowAPI(cookies)
    resolved_tool = tool or current_adapter().project_tools.tool_for_media_type(media_type)
    try:
        result = api.create_project(title=title, tool=resolved_tool)
        if as_json:
            _print_json(result)
            return
        console.print(f"[green][OK] Created project:[/green] {result.get('projectId') or result}")
        if result.get("projectId"):
            pid = result["projectId"]
            console.print(f'[dim]Use: flow generate {media_type} "prompt" --project {pid}[/dim]')
    except Exception as e:
        err_console.print(f"[red]Failed:[/red] {e}")
        sys.exit(1)


@cli.command("projects")
@click.option("--json", "as_json", is_flag=True)
@click.option("--type", "media_type", default="video", type=click.Choice(["video", "image"]))
def list_projects(as_json: bool, media_type: str):
    """List projects for the given media tool (video/image)."""
    cookies = _load_cookies_or_exit()
    try:
        api = FlowAPI(cookies)
        projects = api.list_projects(media_type=media_type)
    except UpstreamChangedError as e:
        err_console.print(f"[red]Projects feature unavailable upstream:[/red] {e}")
        sys.exit(3)
    if as_json:
        _print_json(projects)
        return
    if not projects:
        console.print("[yellow]No projects found.[/yellow]")
        return
    table = Table(title="Projects", box=box.ROUNDED)
    table.add_column("ID", style="cyan", overflow="fold")
    table.add_column("Title", style="white")
    for p in projects:
        info = p.get("projectInfo") or {}
        table.add_row(
            str(p.get("projectId") or p.get("id") or "-")[:50],
            str(info.get("projectTitle") or p.get("title") or "-"),
        )
    console.print(table)


# ---------- Generate ----------


@cli.group()
def generate():
    """Generate media - requires browser for reCAPTCHA (Playwright with cookie jar)."""
    pass


@generate.command("video")
@click.argument("prompt", type=str)
@click.option(
    "--project", "project_id", type=str, default=None, help="Project ID (auto-creates if omitted)"
)
@click.option(
    "--aspect", type=click.Choice(["16:9", "9:16", "1:1", "4:3", "3:4", "21:9"]), default="16:9"
)
@click.option(
    "--model",
    type=click.Choice(
        [
            "veo-3.1-lite-lower-priority",
            "veo-3-lite",
            "veo-3-fast",
            "veo-3.1-lite",
            "veo-3.1-fast",
            "veo-3.1",
            "veo-3",
            "veo-2",
            "veo-2-fast",
        ],
        case_sensitive=False,
    ),
    default=DEFAULT_VIDEO_MODEL,
    help="Video model",
)
@click.option(
    "--duration",
    type=click.Choice([4, 6, 8], case_sensitive=False),
    default=8,
    help="Duration seconds supported by Flow",
)
@click.option(
    "--image",
    "image_path",
    type=click.Path(exists=True, dir_okay=False),
    default=None,
    help="Input image for I2V (image-to-video)",
)
@click.option(
    "--headless/--no-headless",
    default=True,
    help="Run browser headless (show window with --no-headless to debug)",
)
@click.option("--timeout", type=int, default=300, help="Wait timeout seconds")
@click.option(
    "--out", "out_dir", type=click.Path(file_okay=False), default="./output", help="Download dir"
)
@click.option("--no-wait", is_flag=True, help="Don't wait for completion, just submit")
def generate_video(
    prompt: str,
    project_id: str | None,
    aspect: str,
    model: str,
    duration: int,
    image_path: str | None,
    headless: bool,
    timeout: int,
    out_dir: str,
    no_wait: bool,
):
    """Generate video from text (or image-to-video if --image provided).

    \b
    Models (Veo 3 Lite != Veo 3 Fast):
      veo-3.1-lite-lower-priority - default, 0-credit lower-priority queue
      veo-3-lite (Veo 3 Lite) - cheapest, fastest, 10-15 credits, 720p, lower quality than Fast
      veo-3-fast (Veo 3 Fast) - 20 credits, 720p/1080p, balanced
      veo-3.1-lite (Veo 3.1 Lite) - for Frames, coming soon
      veo-3.1-fast (Veo 3.1 Fast) - 0 credits Ultra / 20 Pro, 1080p
      veo-3.1 / veo-3 - Quality, 100 credits, 4K
    """
    cookies = _load_cookies_or_exit()
    # Validate options before launching browser (normalize models / duration / I2V).
    try:
        from flow_cli._models import normalize_duration, normalize_video_model

        model = normalize_video_model(model)
        duration = normalize_duration(duration)
    except FlowError as e:
        _exit_error(e)
    if image_path:
        from flow_cli._validation import validate_image_path

        try:
            validate_image_path(image_path)
        except (OSError, ValueError) as exc:
            err_console.print(f"[red]Invalid I2V input image:[/red] {exc}")
            sys.exit(2)
    # Validate cookies quickly before launching browser
    ok, msg, _ = validate_cookies(cookies)
    if not ok:
        err_console.print(
            f"[yellow]Cookie validation warning:[/yellow] {msg}\n"
            "[dim]Continuing anyway - browser transport may still succeed...[/dim]"
        )

    async def _run():
        from flow_cli._client import FlowClient

        client = FlowClient(cookies=cookies, project_id=project_id)
        console.print(f"[cyan]Generating video:[/cyan] {prompt[:80]}")
        console.print(
            f"[dim]Model={model} Aspect={aspect} Duration={duration}s "
            f"Project={project_id or 'auto'} Headless={headless}[/dim]"
        )
        # A single deadline spans generation/capture AND polling below.
        job_start = time.monotonic()
        try:
            job = await client.generate_video(
                prompt=prompt,
                aspect=aspect,
                model=model,
                duration=duration,
                image_path=image_path,
                headless=headless,
                timeout=timeout,
            )
        except FlowError as e:
            _exit_error(e)
        except Exception as e:
            err_console.print(f"[red]Generation failed to start:[/red] {e}")
            err_console.print(
                "[dim]Tips: try --no-headless to see browser, check cookies are "
                "fresh (flow verify), and ensure Flow subscription is active[/dim]"
            )
            sys.exit(1)

        console.print(f"[green][OK] Submitted job:[/green] {job.job_id}")
        if job.media_name:
            console.print(f"[dim]Media: {job.media_name}[/dim]")
        if job.operation_name:
            console.print(f"[dim]Operation: {job.operation_name}[/dim]")
        console.print(f"[dim]Raw: {json_dumps_redacted(job.raw)[:400]}...[/dim]")

        if no_wait:
            console.print(
                "[yellow]--no-wait set, not polling. Check history later: "
                "flow history --type video[/yellow]"
            )
            return

        console.print(f"[cyan]Waiting for completion (timeout={timeout}s, poll=5s)...[/cyan]")
        try:
            remaining = timeout - (time.monotonic() - job_start)
            if remaining <= 0:
                raise GenerationTimeout(
                    f"Generation deadline exceeded after {timeout}s (job={job.job_id})"
                )
            result = await client.wait_for_video(job, timeout=int(remaining), poll_interval=5)
            console.print(f"[bold green][OK] Video ready! Media:[/bold green] {result.media_name}")
            console.print(f"[dim]Raw keys: {list(result.raw.keys())[:10]}[/dim]")
            # Try download
            try:
                paths = await client.download(result.raw, dest_dir=out_dir)
                if paths:
                    console.print(
                        f"[green][OK] Downloaded {len(paths)} files to {out_dir}:[/green]"
                    )
                    for p in paths:
                        console.print(f"  - {p}")
                else:
                    console.print(
                        "[yellow]No download URLs found in workflow. Check Flow UI "
                        "or run: flow history --json[/yellow]"
                    )
                    console.print(
                        f"[dim]Workflow dump: {json_dumps_redacted(result.raw)[:800]}[/dim]"
                    )
            except FlowError as e:
                _exit_error(e)
            except Exception as e:
                err_console.print(f"[yellow]Download failed:[/yellow] {e}")
        except FlowError as e:
            _exit_error(e)
        except Exception as e:
            err_console.print(f"[red]Wait failed:[/red] {e}")
            sys.exit(1)

    asyncio.run(_run())


@generate.command("image")
@click.argument("prompt", type=str)
@click.option("--project", "project_id", type=str, default=None)
@click.option("--aspect", type=click.Choice(["16:9", "9:16", "1:1", "4:3", "3:4"]), default="1:1")
@click.option("--count", type=int, default=4, help="Number of images (1-4)")
@click.option("--model", type=str, default="nano-banana-pro")
@click.option("--headless/--no-headless", default=True)
@click.option("--timeout", type=int, default=120)
@click.option("--out", "out_dir", type=click.Path(file_okay=False), default="./output")
def generate_image(
    prompt: str,
    project_id: str | None,
    aspect: str,
    count: int,
    model: str,
    headless: bool,
    timeout: int,
    out_dir: str,
):
    """Generate image(s) from text (Nano Banana / Imagen)."""
    cookies = _load_cookies_or_exit()
    # Validate model & count before launching browser.
    try:
        from flow_cli._models import normalize_image_model, normalize_output_count

        model = normalize_image_model(model)
        count = normalize_output_count(count)
    except FlowError as e:
        _exit_error(e)

    async def _run():
        from flow_cli._client import FlowClient

        client = FlowClient(cookies=cookies, project_id=project_id)
        console.print(
            f"[cyan]Generating {count} image(s):[/cyan] {prompt[:80]} "
            f"[dim]({aspect}, {model})[/dim]"
        )
        try:
            images = await client.generate_image(
                prompt=prompt,
                aspect=aspect,
                count=count,
                model=model,
                headless=headless,
                timeout=timeout,
            )
            if not images:
                err_console.print(
                    "[yellow]No images returned. The UI or API shape may have changed. "
                    "Try --no-headless to debug.[/yellow]"
                )
                # Fallback: poll history
                console.print("[dim]Polling history for recent images...[/dim]")
                await asyncio.sleep(10)
                workflows = client.api.fetch_workflows(media_type="IMAGE", limit=5)
                console.print(f"[dim]Found {len(workflows)} recent image workflows[/dim]")
                if workflows:
                    _print_json(workflows[0])
                return
            console.print(f"[green][OK] Got {len(images)} image(s)[/green]")
            for img in images:
                console.print(f"  - {img.fife_url or img.image_id}")
                # Download
                if img.fife_url:
                    from flow_cli._downloader import download_file

                    dest = Path(out_dir) / f"{img.image_id[:12] or 'image'}.png"
                    try:
                        p = download_file(img.fife_url, dest, cookies=cookies, kind="image")
                        console.print(f"    [dim]Saved to {p}[/dim]")
                    except Exception as e:
                        err_console.print(f"    [yellow]Download failed: {e}[/yellow]")
        except Exception as e:
            err_console.print(f"[red]Generation failed:[/red] {e}")
            import traceback

            err_console.print(f"[dim]{traceback.format_exc()[:800]}[/dim]")
            sys.exit(1)

    asyncio.run(_run())


# ---------- Download ----------


@cli.command()
@click.argument("media_id_or_url", type=str, required=False)
@click.option(
    "--workflow-json",
    type=click.Path(exists=True, dir_okay=False),
    default=None,
    help="Path to workflow JSON file (from history --json)",
)
@click.option("--limit", type=int, default=1, help="If no ID given, download latest N from history")
@click.option("--type", "media_type", type=click.Choice(["video", "image"]), default="video")
@click.option("--out", "out_dir", type=click.Path(file_okay=False), default="./output")
def download(
    media_id_or_url: str | None,
    workflow_json: str | None,
    limit: int,
    media_type: str,
    out_dir: str,
):
    """Download media by workflow JSON or latest history.

    \b
    Examples:
      flow download --limit 1 --type video --out ./output
      flow download "https://lh3.googleusercontent.com/..." --out ./output
      flow download --workflow-json workflow.json --out ./output
    """
    cookies = _load_cookies_or_exit()
    from flow_cli._downloader import download_file, download_media_from_workflow

    if workflow_json:
        wf: Any = json.loads(Path(workflow_json).read_text(encoding="utf-8"))
        # Handle array
        if isinstance(wf, list) and wf:
            wf = wf[0]
        if not isinstance(wf, dict):
            err_console.print("[red]Workflow JSON must be an object (or array of objects).[/red]")
            sys.exit(2)
        paths = download_media_from_workflow(wf, out_dir, cookies=cookies)
        console.print(f"[green][OK] Downloaded {len(paths)} files[/green]")
        for p in paths:
            console.print(f"  - {p}")
        return

    if media_id_or_url and media_id_or_url.startswith("http"):
        # Direct URL
        dest = Path(out_dir) / Path(media_id_or_url.split("?")[0]).name
        if not dest.suffix:
            dest = dest.with_suffix(".mp4" if media_type == "video" else ".png")
        p = download_file(media_id_or_url, dest, cookies=cookies, kind=media_type)
        console.print(f"[green][OK] Saved to {p}[/green]")
        return

    # Download latest from history
    api = FlowAPI(cookies)
    workflows = api.fetch_workflows(media_type=media_type, limit=limit)
    if not workflows:
        err_console.print("[yellow]No workflows found to download.[/yellow]")
        sys.exit(1)
    for wf in workflows[:limit]:
        paths = download_media_from_workflow(wf, out_dir, cookies=cookies)
        console.print(
            f"[green][OK] Workflow {wf.get('name', '')[:40]} -> {len(paths)} files[/green]"
        )
        for p in paths:
            console.print(f"  - {p}")


# ---------- Run batch ----------


@cli.command("run")
@click.argument("batch_file", type=click.Path(exists=True, dir_okay=False))
@click.option("--headless/--no-headless", default=True)
@click.option("--out", "out_dir", type=click.Path(file_okay=False), default="./output")
@click.option("--timeout", type=int, default=300)
@click.option("--json", "as_json", is_flag=True, help="Output batch report as JSON")
def run_batch(batch_file: str, headless: bool, out_dir: str, timeout: int, as_json: bool):
    """Run a batch from a JSON file, reusing one browser context.

    Batch JSON format: [{"prompt": "...", "aspect": "16:9", "type": "video",
    "model": "...", "duration": 8, "count": 1}, ...]

    A failed job does not abort the batch; a summary report is produced and
    the exit code reflects how many jobs failed.
    """
    cookies = _load_cookies_or_exit()
    raw = json.loads(Path(batch_file).read_text(encoding="utf-8"))
    if isinstance(raw, list):
        batch = raw
    elif isinstance(raw, dict) and isinstance(raw.get("jobs"), list):
        batch = raw["jobs"]
    else:
        batch = [raw]
    console.print(f"[cyan]Running batch of {len(batch)} jobs (browser reuse)[/cyan]")

    async def _run():
        from flow_cli._client import FlowClient

        client = FlowClient(cookies=cookies)
        report = await client.run_batch(
            batch,
            headless=headless,
            timeout=timeout,
            out_dir=out_dir,
        )
        if as_json:
            console.print_json(json.dumps(report, ensure_ascii=False))
        else:
            ok = sum(1 for r in report if r.get("ok"))
            console.print(f"\n[bold]Batch summary: {ok}/{len(report)} succeeded[/bold]")
            for r in report:
                mark = "[green]OK[/green]" if r.get("ok") else "[red]FAIL[/red]"
                console.print(
                    f"{mark} #{r.get('index')} {str(r.get('prompt') or '')[:50]} "
                    f"[{r.get('media_type')}] -> {r.get('media_name') or r.get('error')}"
                )
                for f in r.get("files", []):
                    console.print(f"     [dim]{f}[/dim]")
            failed = sum(1 for r in report if not r.get("ok"))
            if failed:
                err_console.print(f"[red]{failed} job(s) failed.[/red]")
                sys.exit(1)

    asyncio.run(_run())


# ---------- HTTP API ----------


@cli.group("api")
def api_group():
    """Run the optional local REST API."""
    pass


@api_group.command("serve")
@click.option("--host", default="127.0.0.1", show_default=True)
@click.option("--port", type=click.IntRange(1, 65535), default=8000, show_default=True)
@click.option("--reload", is_flag=True, help="Reload on source changes (development only)")
def serve_api(host: str, port: int, reload: bool):
    """Serve REST endpoints and Swagger UI at /docs."""
    try:
        import uvicorn
    except ImportError as exc:
        raise click.ClickException(
            'API dependencies are missing. Install with: pip install -e ".[api]"'
        ) from exc

    if host not in {"127.0.0.1", "localhost", "::1"} and not os.getenv("FLOW_API_KEY"):
        raise click.ClickException(
            "FLOW_API_KEY is required when binding the API to a non-loopback host"
        )
    uvicorn.run(
        "flow_cli.webapi.app:app",
        host=host,
        port=port,
        reload=reload,
        workers=1,
    )


if __name__ == "__main__":
    cli()
