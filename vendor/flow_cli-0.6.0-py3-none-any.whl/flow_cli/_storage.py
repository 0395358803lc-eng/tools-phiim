"""Config persistence via platformdirs - stores cookies, tokens, project_id."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from platformdirs import user_config_dir, user_data_dir

APP_NAME = "flow-cli"
APP_AUTHOR = "flow-cli"


def get_config_dir() -> Path:
    return Path(user_config_dir(APP_NAME, APP_AUTHOR))


def get_data_dir() -> Path:
    return Path(user_data_dir(APP_NAME, APP_AUTHOR))


def get_config_path() -> Path:
    return get_config_dir() / "config.json"


def get_cookies_path() -> Path:
    return get_config_dir() / "cookies.json"


def ensure_dirs() -> None:
    get_config_dir().mkdir(parents=True, exist_ok=True)
    get_data_dir().mkdir(parents=True, exist_ok=True)


def load_config() -> dict[str, Any]:
    path = get_config_path()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_config(data: dict[str, Any]) -> None:
    ensure_dirs()
    path = get_config_path()
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def parse_netscape_file(text: str) -> dict[str, str]:
    """Parse Netscape HTTP Cookie File format."""
    cookies: dict[str, str] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("# ") or (line.startswith("#") and "HttpOnly" not in line):
            continue
        # Handle #HttpOnly_ prefix
        if line.startswith("#HttpOnly_"):
            line = line[len("#HttpOnly_") :]
        elif line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) >= 7:
            name = parts[5]
            value = parts[6]
            cookies[name] = value
        elif "\t" not in line and "=" in line:
            # fallback single
            pass
    return cookies


def load_cookies_file(path: Path | None = None) -> dict[str, str]:
    """Load cookies from JSON or Netscape file. Supports:
    - {"name": "value"} dict
    - [{"name":"...","value":"..."}, ...] array (EditThisCookie / Cookie-Editor export)
    - {"cookies": [...]} wrapper
    - Netscape HTTP Cookie File (cookies.txt)
    """
    target = Path(path) if path else get_cookies_path()
    if not target.exists():
        return {}
    try:
        text = target.read_text(encoding="utf-8")
        # Detect Netscape
        if (
            "Netscape HTTP Cookie File" in text
            or text.strip().startswith("# HTTP Cookie File")
            or "\t" in text
            and "labs.google" in text
        ):
            # Try Netscape parse first
            netscape = parse_netscape_file(text)
            if netscape and len(netscape) >= 2:
                return netscape
        raw = json.loads(text)
        return normalize_cookies(raw)
    except Exception:
        # Try netscape as fallback
        try:
            return parse_netscape_file(target.read_text(encoding="utf-8", errors="ignore"))
        except Exception:
            return {}


def save_cookies(
    cookies: dict[str, str], path: Path | None = None, raw_list: list[dict[str, Any]] | None = None
) -> None:
    ensure_dirs()
    target = Path(path) if path else get_cookies_path()
    # Save as dict for simplicity, also keep array format compatible
    # If raw_list provided, save that to preserve domain/secure attrs for Playwright
    if raw_list is not None:
        target.write_text(json.dumps(raw_list, indent=2, ensure_ascii=False), encoding="utf-8")
    else:
        target.write_text(json.dumps(cookies, indent=2, ensure_ascii=False), encoding="utf-8")
    # Also save raw list to separate file for browser
    if raw_list is not None:
        raw_path = target.with_name(target.stem + "_raw.json")
        raw_path.write_text(json.dumps(raw_list, indent=2, ensure_ascii=False), encoding="utf-8")
        try:
            os.chmod(raw_path, 0o600)
        except Exception:
            pass
    # Restrict permissions on POSIX
    try:
        os.chmod(target, 0o600)
    except Exception:
        pass


def load_raw_cookies(path: Path | None = None) -> list[dict[str, Any]] | None:
    """Load raw cookie list with domain attrs if available."""
    target = Path(path) if path else get_cookies_path()
    raw_path = target.with_name(target.stem + "_raw.json")
    if raw_path.exists():
        try:
            data = json.loads(raw_path.read_text(encoding="utf-8"))
            if isinstance(data, list) and data and isinstance(data[0], dict) and "name" in data[0]:
                return data
        except Exception:
            pass
    # Fallback: try main file as list
    if target.exists():
        try:
            data = json.loads(target.read_text(encoding="utf-8"))
            if isinstance(data, list) and data and isinstance(data[0], dict) and "name" in data[0]:
                return data
        except Exception:
            pass
    return None


def normalize_cookies(raw: Any) -> dict[str, str]:
    """Normalize various cookie formats to Dict[str,str]."""
    if isinstance(raw, str):
        # Try Netscape string
        if "Netscape" in raw or "\t" in raw and "labs.google" in raw:
            parsed = parse_netscape_file(raw)
            if parsed:
                return parsed
        # Try JSON string
        try:
            return normalize_cookies(json.loads(raw))
        except Exception:
            return parse_cookie_string(raw)
    if isinstance(raw, dict):
        # Wrapper {"cookies": [...]}
        if "cookies" in raw and isinstance(raw["cookies"], list):
            return normalize_cookies(raw["cookies"])
        # Already dict of name->value (but filter out non-string values)
        result: dict[str, str] = {}
        for k, v in raw.items():
            if isinstance(v, str):
                result[k] = v
            elif isinstance(v, dict) and "value" in v:
                result[k] = str(v["value"])
        # If dict looks like {"name":"...","value":"..."} single cookie
        if "name" in raw and "value" in raw and len(raw) <= 5:
            return {str(raw["name"]): str(raw["value"])}
        return result
    if isinstance(raw, list):
        result: dict[str, str] = {}
        for item in raw:
            if isinstance(item, dict) and "name" in item and "value" in item:
                result[str(item["name"])] = str(item["value"])
        return result
    return {}


def parse_cookie_string(cookie_str: str) -> dict[str, str]:
    """Parse 'a=1; b=2; c=3' header string."""
    cookies: dict[str, str] = {}
    if not cookie_str or not cookie_str.strip():
        return cookies
    # Handle JSON array passed as string mistakenly
    s = cookie_str.strip()
    if s.startswith("[") or s.startswith("{"):
        try:
            return normalize_cookies(json.loads(s))
        except Exception:
            pass
    for part in s.split(";"):
        part = part.strip()
        if not part or "=" not in part:
            continue
        k, v = part.split("=", 1)
        k, v = k.strip(), v.strip()
        if k and v:
            cookies[k] = v
    return cookies


def clear_storage() -> None:
    cookies_path = get_cookies_path()
    raw_cookies_path = cookies_path.with_name(cookies_path.stem + "_raw.json")
    for p in [get_config_path(), cookies_path, raw_cookies_path]:
        try:
            if p.exists():
                p.unlink()
        except Exception:
            pass
