"""Flow UI automation - drives labs.google/fx/tools/flow via Playwright clicks."""

from __future__ import annotations

import asyncio
from typing import Any

from flow_cli._exceptions import UpstreamChangedError
from flow_cli._logging import get_logger
from flow_cli._selector_profile import (
    ASPECT_LABELS,
    ASPECT_OPTION_TEMPLATE,
    ASPECT_TRIGGER_SELECTORS,
    COUNT_OPTION_TEMPLATES,
    COUNT_TRIGGER_SELECTORS,
    CREATE_BUTTON_SELECTOR,
    DISMISS_SELECTORS,
    DURATION_CANDIDATES,
    DURATION_OPEN_SELECTORS,
    DURATION_OPTION_TEMPLATES,
    DURATION_TRIGGER_SELECTORS,
    EXACT_TEXT_TEMPLATE,
    FILE_INPUT_SELECTOR,
    GENERATE_ARROW_SELECTOR,
    GENERATE_FALLBACK_SELECTORS,
    GENERATION_COMPLETE_SELECTORS,
    IMAGE_MODEL_OPTION_TEMPLATES,
    IMAGE_MODEL_UI_LABELS,
    IMAGE_TAB_SELECTOR,
    LEGACY_IMAGE_MODEL_BUTTON,
    LEGACY_VIDEO_MODEL_BUTTON,
    MEDIA_SELECTED_SELECTORS,
    MEDIA_TAB_TEMPLATE,
    MODEL_BUTTON_TEMPLATE,
    MODEL_DROPDOWN_SELECTORS,
    MODEL_OPTION_TEMPLATES,
    MODEL_READ_SELECTORS,
    OMNI_MODEL_SELECTOR,
    PROMPT_EDITOR_SELECTOR,
    PROMPT_FALLBACK_SELECTORS,
    RADIX_ITEM_SELECTOR,
    SELECTED_OPTION_TEMPLATES,
    UPLOAD_COMPLETE_SELECTOR,
    VIDEO_MODEL_UI_LABELS,
    VIDEO_SETTINGS_SELECTOR,
    VIDEO_TAB_SELECTOR,
    model_matches,
)

log = get_logger(__name__)


class FlowUI:
    """Automates Google Flow UI for generation ops that require reCAPTCHA."""

    def __init__(self, page: Any):
        self.page = page

    async def _selected_label(
        self, labels: list[str], trigger_selectors: tuple[str, ...] = ()
    ) -> str | None:
        for label in labels:
            for template in SELECTED_OPTION_TEMPLATES:
                try:
                    selected = self.page.locator(template.format(label=label)).first
                    if await selected.is_visible(timeout=500):
                        return label
                except Exception:
                    continue
        for selector in trigger_selectors:
            try:
                trigger = self.page.locator(selector).first
                if not await trigger.is_visible(timeout=500):
                    continue
                text = (await trigger.inner_text()).strip().casefold()
                for label in labels:
                    candidate = label.casefold()
                    if candidate in text:
                        return label
            except Exception:
                continue
        return None

    async def get_selected_aspect(self) -> str | None:
        labels = list(ASPECT_LABELS)
        return await self._selected_label(labels, ASPECT_TRIGGER_SELECTORS)

    async def get_selected_duration(self) -> int | None:
        selected = await self._selected_label(DURATION_CANDIDATES, DURATION_TRIGGER_SELECTORS)
        return int(selected) if selected is not None else None

    async def get_selected_output_count(self) -> int | None:
        labels = [str(value) for value in range(1, 5)]
        selected = await self._selected_label(labels, COUNT_TRIGGER_SELECTORS)
        return int(selected) if selected is not None else None

    async def get_selected_media_type(self) -> str | None:
        for media_type, selectors in MEDIA_SELECTED_SELECTORS.items():
            for selector in selectors:
                try:
                    selected = self.page.locator(selector).first
                    if await selected.is_visible(timeout=500):
                        return media_type
                except Exception:
                    continue
        return None

    async def goto_flow(self, timeout: int = 30000):
        url = "https://labs.google/fx/tools/flow"
        await self.page.goto(url, wait_until="domcontentloaded", timeout=timeout)
        await self.page.wait_for_timeout(2000)
        for selector in DISMISS_SELECTORS:
            try:
                btn = self.page.locator(selector).first
                if await btn.is_visible(timeout=2000):
                    await btn.click(timeout=2000)
                    await self.page.wait_for_timeout(500)
            except Exception:
                pass

    async def ensure_project(self, project_id: str | None = None) -> str:
        if project_id:
            url = f"https://labs.google/fx/tools/flow/project/{project_id}"
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await self.page.wait_for_timeout(2000)
            # Post-condition: URL reflects the requested project
            if "/project/" not in self.page.url:
                raise UpstreamChangedError(
                    f"Navigation did not land on expected project URL: {self.page.url}"
                )
            return project_id
        url = self.page.url
        if "/project/" in url:
            try:
                return url.split("/project/")[1].split("/")[0].split("?")[0].split("#")[0]
            except Exception:
                pass
        return ""

    async def set_prompt(self, prompt: str):
        try:
            slate = self.page.locator(PROMPT_EDITOR_SELECTOR).first
            if await slate.is_visible(timeout=3000):
                await slate.click(timeout=3000)
                await self.page.wait_for_timeout(500)
                await self.page.keyboard.press("Control+A")
                await self.page.wait_for_timeout(200)
                await self.page.keyboard.press("Backspace")
                await self.page.wait_for_timeout(200)
                await self.page.keyboard.type(prompt, delay=20)
                await self.page.wait_for_timeout(800)
                try:
                    text = await slate.inner_text()
                    if prompt[:20] in text or len(text.strip()) > 10:
                        return
                except Exception:
                    pass
                return
        except Exception:
            pass
        for sel in PROMPT_FALLBACK_SELECTORS:
            try:
                loc = self.page.locator(sel).first
                if await loc.is_visible(timeout=3000):
                    await loc.click(timeout=3000)
                    await loc.fill(prompt, timeout=5000)
                    await self.page.wait_for_timeout(300)
                    return
            except Exception:
                continue
        await self.page.keyboard.press("Control+A")
        await self.page.keyboard.type(prompt, delay=20)

    async def select_aspect(self, aspect: str):
        # Current Flow keeps aspect controls inside the combined media-settings
        # popover.  Opening it is harmless on older layouts, where this helper
        # simply returns False and the legacy direct selectors still run.
        await self._open_model_dropdown()
        candidates = ASPECT_LABELS.get(aspect, [aspect])
        for cand in candidates:
            try:
                pill = self.page.locator(ASPECT_OPTION_TEMPLATE.format(label=cand)).first
                if await pill.is_visible(timeout=1500):
                    await pill.click(timeout=2000)
                    await self.page.wait_for_timeout(300)
                    selected = await self.get_selected_aspect()
                    if selected != aspect:
                        raise UpstreamChangedError(
                            f"Requested aspect {aspect!r}, but Flow reports {selected!r}"
                        )
                    return
            except Exception:
                continue
        raise UpstreamChangedError(f"Could not select and verify aspect {aspect!r} in the UI")

    async def select_duration(self, duration: int):
        """Select a generation duration from the UI.

        Read the actual available durations instead of assuming every model
        supports 8s. Raises if the requested duration cannot be found.
        """
        dur_str = str(duration)
        # Try to find & open the duration control (popover).
        for sel in DURATION_OPEN_SELECTORS:
            try:
                btn = self.page.locator(sel).first
                if await btn.is_visible(timeout=1500):
                    await btn.click(timeout=1500)
                    await self.page.wait_for_timeout(500)
                    break
            except Exception:
                continue

        # Look for a visible duration option labeled with the requested value.
        for cand in [dur_str, f"{dur_str} seconds", f"{dur_str}s"]:
            for template in DURATION_OPTION_TEMPLATES:
                loc_sel = template.format(label=cand)
                try:
                    opt = self.page.locator(loc_sel).first
                    if await opt.is_visible(timeout=1200):
                        await opt.click(timeout=1500)
                        await self.page.wait_for_timeout(400)
                        selected = await self.get_selected_duration()
                        if selected != duration:
                            raise UpstreamChangedError(
                                f"Requested duration {duration!r}, but Flow reports {selected!r}"
                            )
                        return
                except Exception:
                    continue
        raise UpstreamChangedError(f"Could not select and verify duration {duration!r} in the UI")

    async def select_output_count(self, count: int):
        """Select how many outputs to generate (1-4)."""
        await self._open_model_dropdown()
        c = str(count)
        for template in COUNT_OPTION_TEMPLATES:
            loc_sel = template.format(label=c)
            try:
                opt = self.page.locator(loc_sel).first
                if await opt.is_visible(timeout=1200):
                    await opt.click(timeout=1500)
                    await self.page.wait_for_timeout(400)
                    selected = await self.get_selected_output_count()
                    if selected != count:
                        raise UpstreamChangedError(
                            f"Requested output count {count!r}, but Flow reports {selected!r}"
                        )
                    return
            except Exception:
                continue
        raise UpstreamChangedError(f"Could not select and verify output count {count!r} in the UI")

    async def set_input_files(self, image_path: str):
        """Upload a source image for I2V.

        Post-condition: wait for the uploaded thumbnail / asset marker before
        returning. Raises if the file cannot be attached in time.
        """
        file_input = self.page.locator(FILE_INPUT_SELECTOR).first
        await file_input.set_input_files(image_path)
        # Wait for thumbnail/asset confirmation.
        for _ in range(20):
            await self.page.wait_for_timeout(500)
            try:
                if await self.page.locator(UPLOAD_COMPLETE_SELECTOR).first.is_visible(timeout=500):
                    return
            except Exception:
                pass
        raise RuntimeError("Uploaded image thumbnail did not appear after set_input_files")

    async def get_selected_model(self) -> str:
        """Read the model currently displayed in the UI (label text)."""
        for sel in MODEL_READ_SELECTORS:
            try:
                btn = self.page.locator(sel).first
                if await btn.is_visible(timeout=1200):
                    txt = (await btn.inner_text()).strip()
                    if txt and any(
                        m in txt for m in ["Veo", "Nano", "Imagen", "veo", "nano", "imagen"]
                    ):
                        return txt
            except Exception:
                continue
        # Fallback: read any visible text mentioning a model.
        for cand in list(VIDEO_MODEL_UI_LABELS) + list(IMAGE_MODEL_UI_LABELS):
            for label in VIDEO_MODEL_UI_LABELS.get(cand, []) + IMAGE_MODEL_UI_LABELS.get(cand, []):
                try:
                    loc = self.page.locator(EXACT_TEXT_TEMPLATE.format(label=label)).first
                    if await loc.is_visible(timeout=500):
                        return label
                except Exception:
                    continue
        return ""

    def verify_model_selection(self, requested: str, selected: str) -> bool:
        return model_matches(requested, selected)

    async def _click_tool_toggle(self, media_type: str):
        """Ensure the Image/Video tool toggle is on the desired media type."""
        if media_type not in MEDIA_SELECTED_SELECTORS:
            raise ValueError(f"Unknown media type: {media_type!r}")
        if await self.get_selected_media_type() == media_type:
            return
        # The current UI exposes explicit Image/Video tabs inside the combined
        # settings popover. Prefer those stable labels before the legacy Radix
        # collection fallback below.
        if await self._open_model_dropdown():
            label = "Video" if media_type == "video" else "Image"
            try:
                tab = self.page.locator(MEDIA_TAB_TEMPLATE.format(label=label)).first
                if await tab.is_visible(timeout=800):
                    await tab.click(timeout=1500)
                    await self.page.wait_for_timeout(500)
                    selected = await self.get_selected_media_type()
                    if selected != media_type:
                        raise UpstreamChangedError(
                            f"Requested media type {media_type!r}, but Flow reports {selected!r}"
                        )
                    return
            except Exception:
                pass
        if media_type == "video":
            try:
                nano_btn = self.page.locator(LEGACY_IMAGE_MODEL_BUTTON).first
                if await nano_btn.is_visible(timeout=800):
                    await nano_btn.click(timeout=1500)
                    await self.page.wait_for_timeout(800)
                    video_opt = self.page.locator(RADIX_ITEM_SELECTOR).nth(1)
                    if await video_opt.is_visible(timeout=1000):
                        txt = await video_opt.inner_text()
                        if "video" in txt.lower():
                            await video_opt.click(timeout=1500)
                            await self.page.wait_for_timeout(800)
                            await self.page.keyboard.press("Escape")
                            await self.page.wait_for_timeout(300)
            except Exception:
                pass
        else:
            try:
                vid_btn = self.page.locator(LEGACY_VIDEO_MODEL_BUTTON).first
                if await vid_btn.is_visible(timeout=800):
                    await vid_btn.click(timeout=1500)
                    await self.page.wait_for_timeout(800)
                    nano_opt = self.page.locator(RADIX_ITEM_SELECTOR).first
                    if await nano_opt.is_visible(timeout=1000):
                        txt = await nano_opt.inner_text()
                        if "nano" in txt.lower() or "imagen" in txt.lower():
                            await nano_opt.click(timeout=1500)
                            await self.page.wait_for_timeout(800)
            except Exception:
                pass
        selected = await self.get_selected_media_type()
        if selected != media_type:
            raise UpstreamChangedError(
                f"Could not select and verify media type {media_type!r}; Flow reports {selected!r}"
            )

    async def _open_model_dropdown(self):
        # If both media tabs are visible, the combined settings popover is
        # already open. Do not click its trigger again because that would close
        # it before the caller can choose aspect/model/count.
        try:
            image_tab = self.page.locator(IMAGE_TAB_SELECTOR).first
            video_tab = self.page.locator(VIDEO_TAB_SELECTOR).first
            if await image_tab.is_visible(timeout=300) and await video_tab.is_visible(timeout=300):
                return True
        except Exception:
            pass

        # Current Flow nests the model selector inside the media settings popover.
        omni = self.page.locator(OMNI_MODEL_SELECTOR).first
        try:
            if not await omni.is_visible(timeout=500):
                settings = self.page.locator(VIDEO_SETTINGS_SELECTOR).first
                if await settings.is_visible(timeout=800):
                    await settings.click(timeout=1500)
                    await self.page.wait_for_timeout(400)
        except Exception:
            pass
        for sel in MODEL_DROPDOWN_SELECTORS:
            try:
                btn = self.page.locator(sel).first
                if await btn.is_visible(timeout=1000):
                    txt = await btn.inner_text()
                    if any(m in txt.lower() for m in ["omni", "veo", "nano", "imagen", "model"]):
                        await btn.click(timeout=1500)
                        await self.page.wait_for_timeout(500)
                        return True
            except Exception:
                continue
        return False

    async def select_model(self, model: str):
        """Select a model, using per-media label map (never generic "Lite")."""
        await self._click_tool_toggle("video")
        normalized = model.strip().lower().replace(" ", "-")
        candidates = list(VIDEO_MODEL_UI_LABELS.get(normalized, [model]))
        if not await self._open_model_dropdown():
            # Try direct pill click.
            for cand in candidates:
                try:
                    pill = self.page.locator(MODEL_BUTTON_TEMPLATE.format(label=cand)).first
                    if await pill.is_visible(timeout=800):
                        await pill.click(timeout=1500)
                        await self.page.wait_for_timeout(400)
                        return
                except Exception:
                    continue
            raise RuntimeError(f"Could not open model dropdown for {model!r}")
        for cand in candidates:
            for template in MODEL_OPTION_TEMPLATES:
                loc_sel = template.format(label=cand)
                try:
                    opt = self.page.locator(loc_sel).first
                    if await opt.is_visible(timeout=1000):
                        await opt.click(timeout=1500)
                        await self.page.wait_for_timeout(400)
                        return
                except Exception:
                    continue
        await self.page.keyboard.press("Escape")
        raise RuntimeError(f"Could not find model {model!r} in the UI dropdown")

    async def select_image_model(self, model: str):
        """Select an image model (Nano Banana / Imagen) using the image label map."""
        # A newly opened or previously reused Flow project can still be in
        # Video mode.  In that state the model popover only contains Veo
        # entries, so looking for an image label will always fail even though
        # the requested model is available.  Switch media mode first, mirroring
        # select_model()'s explicit switch to Video mode.
        await self._click_tool_toggle("image")
        normalized = model.strip().lower().replace(" ", "-")
        candidates = list(IMAGE_MODEL_UI_LABELS.get(normalized, [model]))
        if not await self._open_model_dropdown():
            for cand in candidates:
                try:
                    pill = self.page.locator(MODEL_BUTTON_TEMPLATE.format(label=cand)).first
                    if await pill.is_visible(timeout=800):
                        await pill.click(timeout=1500)
                        await self.page.wait_for_timeout(400)
                        return
                except Exception:
                    continue
            raise RuntimeError(f"Could not open image model dropdown for {model!r}")

        # The current UI has two levels: the combined media-settings popover,
        # followed by a model-specific dropdown. Choose the innermost visible
        # model button (the outer trigger also contains the model name).
        opened_model_menu = False
        for family in ("Nano", "Imagen"):
            try:
                buttons = self.page.locator(MODEL_BUTTON_TEMPLATE.format(label=family))
                for index in range((await buttons.count()) - 1, -1, -1):
                    button = buttons.nth(index)
                    if await button.is_visible(timeout=500):
                        await button.click(timeout=1500)
                        await self.page.wait_for_timeout(400)
                        opened_model_menu = True
                        break
                if opened_model_menu:
                    break
            except Exception:
                continue

        for cand in candidates:
            for template in IMAGE_MODEL_OPTION_TEMPLATES:
                loc_sel = template.format(label=cand)
                try:
                    opt = self.page.locator(loc_sel).first
                    if await opt.is_visible(timeout=1000):
                        await opt.click(timeout=1500)
                        await self.page.wait_for_timeout(400)
                        return
                except Exception:
                    continue
        await self.page.keyboard.press("Escape")
        raise RuntimeError(f"Could not find image model {model!r} in the UI dropdown")

    async def select_video_model_and_verify(self, model: str) -> str:
        """Select video model then read back the displayed label and verify."""
        await self.select_model(model)
        await self.page.wait_for_timeout(500)
        selected = await self.get_selected_model()
        if not self.verify_model_selection(model, selected):
            raise RuntimeError(f"Requested model {model!r}, but Flow selected {selected!r}")
        return selected

    async def select_image_model_and_verify(self, model: str) -> str:
        """Select image model then read back the displayed label and verify."""
        await self.select_image_model(model)
        await self.page.wait_for_timeout(500)
        selected = await self.get_selected_model()
        if not self.verify_model_selection(model, selected):
            raise RuntimeError(f"Requested image model {model!r}, but Flow selected {selected!r}")
        return selected

    async def click_generate(self):
        """Click the main Generate / Create button - handles Slate editor flow."""
        for _ in range(10):
            try:
                arrow_btn = self.page.locator(GENERATE_ARROW_SELECTOR).first
                if await arrow_btn.count() > 0:
                    if await arrow_btn.is_visible(timeout=1000):
                        is_disabled = await arrow_btn.is_disabled()
                        if not is_disabled:
                            await arrow_btn.click(timeout=5000)
                            return
                create_btns = self.page.locator(CREATE_BUTTON_SELECTOR)
                cnt = await create_btns.count()
                for i in range(cnt):
                    btn = create_btns.nth(i)
                    if await btn.is_visible(timeout=1000):
                        if not await btn.is_disabled():
                            txt = await btn.inner_text()
                            if "arrow_forward" in txt or i == cnt - 1:
                                await btn.click(timeout=5000)
                                return
            except Exception:
                pass
            await self.page.wait_for_timeout(500)

        last_error = None
        for sel in GENERATE_FALLBACK_SELECTORS:
            try:
                loc = self.page.locator(sel).first
                count = await loc.count()
                if await loc.is_visible(timeout=2000):
                    is_disabled = await loc.is_disabled()
                    if not is_disabled:
                        await loc.click(timeout=5000)
                        return
                    if count > 1:
                        for i in range(1, min(count, 3)):
                            loc2 = self.page.locator(sel).nth(i)
                            if await loc2.is_visible(timeout=1000) and not await loc2.is_disabled():
                                await loc2.click(timeout=5000)
                                return
            except Exception as e:
                last_error = e
                continue
        try:
            await self.page.keyboard.press("Enter")
            await self.page.wait_for_timeout(500)
            arrow_btn = self.page.locator(GENERATE_ARROW_SELECTOR).first
            if await arrow_btn.is_visible(timeout=2000) and not await arrow_btn.is_disabled():
                await arrow_btn.click(timeout=5000)
                return
        except Exception:
            pass
        raise RuntimeError(f"Could not find enabled Generate button. Last error: {last_error}")

    async def wait_for_generation_complete(self, timeout: float = 300) -> bool:
        try:
            await self.page.wait_for_load_state("networkidle", timeout=10000)
        except Exception:
            pass
        start = asyncio.get_event_loop().time()
        while (asyncio.get_event_loop().time() - start) < timeout:
            for sel in GENERATION_COMPLETE_SELECTORS:
                try:
                    loc = self.page.locator(sel).first
                    if await loc.is_visible(timeout=1000):
                        return True
                except Exception:
                    pass
            await asyncio.sleep(2)
        return False
