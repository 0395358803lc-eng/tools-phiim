"""BrowserManager - Playwright persistent context for cookie-based transport."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from platformdirs import user_data_dir

APP_NAME = "flow-cli"
APP_AUTHOR = "flow-cli"


def get_browser_data_dir() -> Path:
    return Path(user_data_dir(APP_NAME, APP_AUTHOR)) / "browser"


class BrowserManager:
    """Manages Playwright browser for:
    1. One-time login (if needed) - not used in cookie-only mode but kept for fallback
    2. Headless transport that auto-attaches cookies via page.request
       (bypasses manual header handling)
    3. UI automation for generation (reCAPTCHA requires real click)
    """

    def __init__(
        self,
        headless: bool = True,
        cookies: dict[str, str] | None = None,
        raw_cookies: list[dict[str, Any]] | None = None,
    ):
        self.headless = headless
        self.cookies = cookies or {}
        self.raw_cookies = raw_cookies  # {name, value, domain, path, secure, httpOnly, sameSite}
        self._playwright = None
        self._browser = None
        self._context = None
        self._page = None

    async def start(self):
        from playwright.async_api import async_playwright

        self._playwright = await async_playwright().start()
        # Use persistent context if data dir exists, else regular
        data_dir = get_browser_data_dir()
        data_dir.mkdir(parents=True, exist_ok=True)

        # Launch with cookie injection
        self._browser = await self._playwright.chromium.launch(headless=self.headless)
        self._context = await self._browser.new_context(
            viewport={"width": 1280, "height": 800},
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
            ),
        )
        # Inject cookies if provided - prefer raw_cookies with correct domain/secure attrs
        playwright_cookies = []
        if self.raw_cookies:
            for c in self.raw_cookies:
                try:
                    # Map Cookie-Editor export to Playwright format
                    domain = c.get("domain", "")
                    # Playwright expects domain without leading dot? It handles both, but normalize
                    # Keep as is, but ensure it starts with . or is hostOnly
                    name = c.get("name")
                    value = c.get("value")
                    if not name or value is None:
                        continue
                    # HostOnly cookies should not have leading dot
                    if c.get("hostOnly") and domain.startswith("."):
                        domain = domain[1:]
                    # Handle expirationDate
                    expires = c.get("expirationDate")
                    expires_ts = -1
                    if expires is not None:
                        try:
                            expires_ts = int(float(expires))
                        except Exception:
                            expires_ts = -1
                    # sameSite mapping
                    same_site = c.get("sameSite")
                    if same_site == "no_restriction":
                        same_site = "None"
                    elif same_site == "lax":
                        same_site = "Lax"
                    elif same_site == "strict":
                        same_site = "Strict"
                    else:
                        same_site = None
                    pw: dict[str, Any] = {
                        "name": str(name),
                        "value": str(value),
                        "domain": str(domain),
                        "path": str(c.get("path", "/")),
                        "secure": bool(c.get("secure", False)),
                        "httpOnly": bool(c.get("httpOnly", False)),
                    }
                    if same_site:
                        pw["sameSite"] = same_site
                    if expires_ts != -1:
                        pw["expires"] = expires_ts
                    playwright_cookies.append(pw)
                except Exception:
                    continue
        elif self.cookies:
            for k, v in self.cookies.items():
                # Fallback: guess domain - try both, with secure handling for __Secure- prefix
                is_secure = k.startswith("__Secure-") or k.startswith("__Host-")
                for domain in [".google.com", ".labs.google", "labs.google", "google.com"]:
                    # Skip insecure for Secure cookies
                    if is_secure and domain in ["labs.google", "google.com"]:
                        # __Host- must be hostOnly and secure, skip non-secure dot domains
                        if k.startswith("__Host-") and domain.startswith("."):
                            continue
                    playwright_cookies.append(
                        {
                            "name": k,
                            "value": v,
                            "domain": domain,
                            "path": "/",
                            "secure": is_secure or domain.startswith(".google"),
                            "httpOnly": False,
                        }
                    )
        if playwright_cookies:
            # Add in chunks to isolate failures
            added = 0
            for chunk in [
                playwright_cookies[i : i + 50] for i in range(0, len(playwright_cookies), 50)
            ]:
                try:
                    await self._context.add_cookies(chunk)
                    added += len(chunk)
                except Exception:
                    # Try one by one
                    for c in chunk:
                        try:
                            await self._context.add_cookies([c])
                            added += 1
                        except Exception:
                            pass
            # print(f"Added {added}/{len(playwright_cookies)} cookies")

        self._page = await self._context.new_page()
        # Pre-navigate to labs.google to establish context
        try:
            await self._page.goto(
                "https://labs.google/fx/tools/flow", wait_until="domcontentloaded", timeout=15000
            )
        except Exception:
            pass
        return self

    async def stop(self):
        try:
            if self._context:
                await self._context.close()
        except Exception:
            pass
        try:
            if self._browser:
                await self._browser.close()
        except Exception:
            pass
        try:
            if self._playwright:
                await self._playwright.stop()
        except Exception:
            pass

    @property
    def page(self):
        return self._page

    @property
    def context(self):
        return self._context

    @property
    def request(self):
        """Playwright APIRequestContext that auto-attaches cookies."""
        if self._page:
            return self._page.request
        if self._context:
            return self._context.request
        raise RuntimeError("Browser not started. Call await start() first")

    async def api_get(
        self, url: str, params: dict[str, Any] | None = None, headers: dict[str, str] | None = None
    ) -> dict[str, Any]:
        # Use page.request which auto-attaches cookies
        resp = await self.request.get(url, params=params, headers=headers)
        status = resp.status
        text = await resp.text()
        if status >= 400:
            raise RuntimeError(f"GET {url} failed {status}: {text[:500]}")
        try:
            return json.loads(text)
        except Exception:
            return {"raw_text": text, "status": status}

    async def api_post(
        self,
        url: str,
        json_data: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        resp = await self.request.post(
            url,
            data=json.dumps(json_data) if json_data else None,
            headers=headers or {"Content-Type": "application/json"},
        )
        status = resp.status
        text = await resp.text()
        if status >= 400:
            raise RuntimeError(f"POST {url} failed {status}: {text[:500]}")
        try:
            return json.loads(text)
        except Exception:
            return {"raw_text": text, "status": status}

    async def __aenter__(self):
        await self.start()
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any):
        await self.stop()
