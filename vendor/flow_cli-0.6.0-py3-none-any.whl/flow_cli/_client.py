"""FlowClient - high-level facade combining HTTP API + Browser automation."""

from __future__ import annotations

import asyncio
import os
import time
import uuid
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

import requests

from flow_cli._api import FlowAPI
from flow_cli._auth import load_saved_cookies
from flow_cli._debug_artifacts import ArtifactCollector
from flow_cli._exceptions import (
    AuthError,
    GenerationError,
    GenerationTimeout,
    UpstreamChangedError,
)
from flow_cli._job_state import JobRecord, JobState
from flow_cli._logging import get_logger
from flow_cli._models import (
    DEFAULT_VIDEO_MODEL,
    Credits,
    GeneratedImage,
    VideoJob,
    normalize_duration,
    normalize_image_model,
    normalize_output_count,
    normalize_video_model,
)
from flow_cli._storage import get_data_dir
from flow_cli.adapters import current_adapter

log = get_logger(__name__)


class FlowClient:
    """Main client. Cookie-based auth."""

    def __init__(
        self,
        cookies: dict[str, str] | None = None,
        project_id: str | None = None,
        timeout: int = 30,
    ):
        self.cookies = cookies or load_saved_cookies()
        if not self.cookies:
            raise AuthError('No cookies. Run flow login --cookie "..." first')
        self.project_id = project_id
        self.timeout = timeout
        self.api = FlowAPI(self.cookies, timeout=timeout)
        self._browser = None  # lazy
        try:
            from flow_cli._storage import load_raw_cookies

            self.raw_cookies = load_raw_cookies()
        except Exception:
            self.raw_cookies = None

    # ---------- Read-only ops (direct HTTP, no browser) ----------

    async def get_credits(self) -> Credits:
        data = await asyncio.to_thread(self.api.get_credits)
        remaining = None
        total = None
        tier = None
        for k in ["remaining", "credits", "balance", "availableCredits"]:
            if k in data and isinstance(data[k], (int, float)):
                remaining = int(data[k])
                break
        try:
            adapter = current_adapter()
            inner = adapter.unwrap_trpc(data)
            if isinstance(inner, dict):
                for k in ["remaining", "credits", "balance"]:
                    if k in inner and isinstance(inner[k], (int, float)):
                        remaining = int(inner[k])
                        break
                if "tier" in inner:
                    tier = str(inner["tier"])
        except Exception:
            pass
        return Credits(remaining=remaining, total=total, tier=tier, raw=data)

    async def create_project(self, title: str | None = None, media_type: str = "video") -> str:
        adapter = current_adapter()
        tool = adapter.project_tools.tool_for_media_type(media_type)
        result = await asyncio.to_thread(self.api.create_project, title=title, tool=tool)
        pid = result.get("projectId") or result.get("project_id") or result.get("id")
        if pid:
            self.project_id = str(pid)
            return str(pid)
        raise GenerationError(f"Failed to create project: {result}")

    async def fetch_history(
        self,
        media_type: str = "VIDEO",
        limit: int = 20,
        project_id: str | None = None,
        cursor: str | None = None,
    ) -> list[dict[str, Any]]:
        type_map = "VIDEO" if media_type.upper() == "VIDEO" else "IMAGE"
        resolved_project = project_id if project_id is not None else self.project_id
        if cursor is None:
            return await asyncio.to_thread(
                self.api.fetch_workflows,
                media_type=type_map,
                limit=limit,
                project_id=resolved_project,
            )
        adapter = current_adapter()
        type_param = adapter.history_type_params.get(type_map.lower(), type_map)
        return await asyncio.to_thread(
            self.api.fetch_history,
            media_type=type_param,
            page_size=limit,
            project_id=resolved_project,
            cursor=cursor,
        )

    async def fetch_history_page(
        self,
        media_type: str = "VIDEO",
        limit: int = 20,
        project_id: str | None = None,
        cursor: str | None = None,
    ) -> tuple[list[dict[str, Any]], str | None]:
        type_map = "VIDEO" if media_type.upper() == "VIDEO" else "IMAGE"
        adapter = current_adapter()
        type_param = adapter.history_type_params.get(type_map.lower(), type_map)
        return await asyncio.to_thread(
            self.api.fetch_history_page,
            media_type=type_param,
            page_size=limit,
            project_id=project_id if project_id is not None else self.project_id,
            cursor=cursor,
        )

    async def list_projects(self, media_type: str = "video") -> list[dict[str, Any]]:
        if media_type == "video":
            return await asyncio.to_thread(self.api.list_projects)
        return await asyncio.to_thread(self.api.list_projects, media_type=media_type)

    async def get_media(self, media_id: str) -> dict[str, Any]:
        return await asyncio.to_thread(self.api.get_media, media_id)

    # ---------- Generation ops (browser required for reCAPTCHA) ----------

    async def generate_video(
        self,
        prompt: str,
        aspect: str = "16:9",
        model: str = DEFAULT_VIDEO_MODEL,
        duration: int = 8,
        image_path: str | None = None,
        headless: bool = True,
        timeout: int = 300,
    ) -> VideoJob:
        norm_model = normalize_video_model(model)
        norm_duration = normalize_duration(duration)
        return await self._generate_via_browser(
            prompt=prompt,
            aspect=aspect,
            model=norm_model,
            duration=norm_duration,
            image_path=image_path,
            headless=headless,
            timeout=timeout,
            media_type="video",
        )

    async def generate_image(
        self,
        prompt: str,
        aspect: str = "1:1",
        count: int = 4,
        model: str = "nano-banana-pro",
        headless: bool = True,
        timeout: int = 120,
    ) -> list[GeneratedImage]:
        norm_model = normalize_image_model(model)
        norm_count = normalize_output_count(count)
        started = time.monotonic()
        job = await self._generate_via_browser(
            prompt=prompt,
            aspect=aspect,
            model=norm_model,
            headless=headless,
            timeout=timeout,
            media_type="image",
            count=norm_count,
        )
        if isinstance(job, list):
            if len(job) < norm_count:
                raise GenerationError(
                    f"Image generation completed partially: requested {norm_count}, "
                    f"received {len(job)}"
                )
            return job[:norm_count]

        legacy_images = self._images_from_payload(job.raw, prompt)
        if job.is_success and legacy_images:
            # Compatibility with older synchronous captures. New asynchronous
            # image jobs are emitted as RUNNING and follow the strict count path.
            return legacy_images[:norm_count]

        remaining = timeout - int(time.monotonic() - started)
        if remaining <= 0:
            raise GenerationTimeout(
                f"Image generation deadline exceeded after {timeout}s (job={job.job_id})"
            )
        return await self.wait_for_images(job, count=norm_count, timeout=remaining)

    async def _generate_via_browser(
        self,
        prompt: str,
        aspect: str = "16:9",
        model: str = DEFAULT_VIDEO_MODEL,
        duration: int = 8,
        image_path: str | None = None,
        headless: bool = True,
        timeout: int = 300,
        media_type: str = "video",
        count: int = 4,
        manager: Any = None,
    ) -> Any:
        """Drive the Flow UI to submit a generation.

        When `manager` (a shared BrowserManager) is supplied for batch reuse,
        a fresh page is opened from its context per job; otherwise a dedicated
        browser is launched and torn down for the single job.
        """
        from flow_cli._browser import BrowserManager
        from flow_cli._flow_ui import FlowUI
        from flow_cli._ui_interceptor import UIInterceptor

        if image_path:
            from flow_cli._validation import validate_image_path

            try:
                validate_image_path(image_path)
            except (OSError, ValueError) as exc:
                raise GenerationError(str(exc)) from exc

        adapter = current_adapter()
        job_id = f"job_{uuid.uuid4().hex[:8]}_{int(time.time())}"
        job_record = JobRecord(
            job_id=job_id,
            prompt=prompt,
            prompt_hash=None,
            media_type=media_type,
            model=model,
            aspect=aspect,
            duration=duration,
            project_id=self.project_id,
        )
        job_record.state = JobState.CREATED

        task_start = time.time()

        async def run_on(page: Any) -> Any:
            interceptor = UIInterceptor(page)
            await interceptor.start()
            ui = FlowUI(page)

            try:
                await ui.goto_flow()
                if self.project_id:
                    await ui.ensure_project(self.project_id)
                    job_record.project_id = self.project_id
                else:
                    try:
                        pid = await self.create_project(
                            title=f"flow-cli-{job_id}", media_type=media_type
                        )
                        await ui.ensure_project(pid)
                        job_record.project_id = pid
                    except Exception as e:
                        # Do NOT silently continue into generation in a wrong project.
                        # Only fall back if the UI has already landed on a real project.
                        log.warning("project_create_failed", job_id=job_id, error=str(e))
                        ui_project = await ui.ensure_project()
                        if ui_project:
                            job_record.project_id = ui_project
                            self.project_id = ui_project
                            log.info("project_fallback_ui", job_id=job_id, project_id=ui_project)
                        else:
                            raise GenerationError(
                                f"Could not create/select a project before generation: {e}"
                            ) from e

                await ui.set_prompt(prompt)

                # I2V: upload input image and require thumbnail before proceeding.
                if image_path:
                    await ui.set_input_files(image_path)

                if media_type == "video":
                    await ui.select_aspect(aspect)
                    # Verify the model selection before Generate (3.1).
                    selected = await ui.select_video_model_and_verify(model)
                    log.info("model_selected", job_id=job_id, requested=model, selected=selected)
                    # Always enforce the requested duration (not only when != default),
                    # because the UI may carry a stale selection from a previous run.
                    await ui.select_duration(duration)
                    # Video mode can retain x2/x3 from a previous session. The
                    # public video command creates one video, so force x1.
                    await ui.select_output_count(1)
                    job_record.duration = duration
                else:
                    await ui.select_aspect(aspect)
                    selected = await ui.select_image_model_and_verify(model)
                    log.info("model_selected", job_id=job_id, requested=model, selected=selected)
                    # Always enforce the requested output count for the same reason.
                    await ui.select_output_count(count)

                job_record.state = JobState.SUBMITTED
                await ui.click_generate()
                job_record.state = JobState.QUEUED

                # Use a single overall deadline for the whole task: the configured
                # `timeout` covers navigation, submit, capture AND later polling.
                capture_remaining = timeout - (time.time() - task_start)
                if capture_remaining <= 0:
                    raise GenerationTimeout(
                        f"Generation deadline exceeded after {timeout}s (job={job_id})"
                    )
                capture_timeout = int(capture_remaining)
                try:

                    def is_generate(entry: dict[str, Any]) -> bool:
                        url = entry.get("url", "")
                        return "aisandbox-pa.googleapis.com" in url and (
                            "batchGenerate" in url or "generate" in url.lower()
                        )

                    captured = await interceptor.wait_for_capture(
                        predicate=is_generate,
                        timeout=capture_timeout,
                    )
                    body = (
                        captured.get("response", {}).get("body")
                        if isinstance(captured.get("response"), dict)
                        else None
                    )
                    response_status = captured.get("response", {}).get("status")
                    endpoint = urlsplit(str(captured.get("url", ""))).path.rsplit("/", 1)[-1]
                    if isinstance(response_status, int) and response_status >= 400:
                        raise GenerationError(
                            f"Generation request failed with upstream HTTP {response_status} "
                            f"at {endpoint or 'generation endpoint'}"
                        )
                    if not isinstance(body, dict):
                        raise UpstreamChangedError(
                            "Generation capture returned a non-dict body - "
                            "response schema may have changed."
                        )

                    parsed = adapter.parse_generation_response(body)
                    op_name = parsed.get("operation_name")
                    workflow_id = parsed.get("workflow_id")
                    media_id = parsed.get("media_id")
                    resource_name = parsed.get("resource_name")
                    media_name = parsed.get("media_name")
                    images = parsed.get("images") or []

                    # Image synchronous response.
                    if media_type == "image":
                        result_images = self._images_from_payload(body, prompt)
                        if not result_images and images:
                            for img in images:
                                fife = (
                                    img.get("fifeUrl")
                                    or img.get("url")
                                    or img.get("downloadUrl")
                                    or img.get("mediaGenerationId", {}).get("fifeUrl")
                                )
                                result_images.append(
                                    GeneratedImage(
                                        image_id=img.get("mediaId")
                                        or img.get("name")
                                        or f"img_{len(result_images)}",
                                        prompt=prompt,
                                        fife_url=fife,
                                        width=img.get("dimensions", {}).get("width", 1024)
                                        if isinstance(img.get("dimensions"), dict)
                                        else 1024,
                                        height=img.get("dimensions", {}).get("height", 1024)
                                        if isinstance(img.get("dimensions"), dict)
                                        else 1024,
                                        raw=img,
                                    )
                                )
                        if result_images and (
                            len(result_images) >= count
                            or not (op_name or workflow_id or media_id or resource_name)
                        ):
                            await interceptor.stop()
                            return result_images[:count]

                    # If no direct op/name, do NOT fall back to "most recent" blindly.
                    if not (op_name or workflow_id or media_id or resource_name):
                        await interceptor.stop()
                        response_keys = ",".join(sorted(str(key) for key in body)[:12]) or "none"
                        raise UpstreamChangedError(
                            "Generation response had no operation name or media name; "
                            "refusing to guess the most recent workflow. "
                            f"endpoint={endpoint or 'unknown'}, status={response_status}, "
                            f"keys={response_keys}. Schema may have changed."
                        )

                    job_record.workflow_id = workflow_id
                    job_record.media_id = media_id
                    job_record.resource_name = resource_name
                    job_record.operation_name = op_name
                    job_record.state = JobState.RUNNING

                    job = VideoJob(
                        job_id=job_id,
                        prompt=prompt,
                        status="RUNNING",
                        media_name=media_name,
                        project_id=self.project_id,
                        operation_name=op_name,
                        media_id=media_id,
                        workflow_id=workflow_id,
                        resource_name=resource_name,
                        prompt_hash=job_record.prompt_hash,
                        model=model,
                        aspect=aspect,
                        duration=duration if media_type == "video" else None,
                        media_type=media_type,
                        raw=body,
                    )
                    return job
                except TimeoutError as e:
                    raise GenerationTimeout(
                        f"Generation capture timed out - reCAPTCHA or UI may have changed. "
                        f"Try running with --no-headless to see browser. Detail: {e}"
                    ) from e
            except (GenerationTimeout, UpstreamChangedError):
                if os.getenv("FLOW_DEBUG_ARTIFACTS", "0").strip().lower() in {
                    "1",
                    "true",
                    "yes",
                    "on",
                }:
                    collector = ArtifactCollector(get_data_dir() / "artifacts", job_id)
                    await collector.capture_page(page)
                    await collector.capture_html(page)
                    collector.write_network_summary(interceptor.captured)
                    log.info("upstream_debug_artifacts", job_id=job_id, path=str(collector.root))
                raise
            finally:
                await interceptor.stop()

        if manager is not None:
            # Batch reuse: one browser/context, a fresh page per job.
            page = await manager.context.new_page()
            try:
                return await run_on(page)
            finally:
                try:
                    await page.close()
                except Exception:
                    pass

        async with BrowserManager(
            headless=headless,
            cookies=self.cookies,
            raw_cookies=getattr(self, "raw_cookies", None),
        ) as browser:
            return await run_on(browser.page)

    @staticmethod
    def _images_from_payload(payload: dict[str, Any], prompt: str) -> list[GeneratedImage]:
        """Extract distinct downloadable images from a matched workflow payload."""
        candidates: list[dict[str, Any]] = []

        def collect(value: Any, *, depth: int = 0) -> None:
            if depth > 5:
                return
            if isinstance(value, list):
                for item in value:
                    collect(item, depth=depth + 1)
                return
            if not isinstance(value, dict):
                return
            url = value.get("fifeUrl") or value.get("url") or value.get("downloadUrl")
            if url and isinstance(url, str):
                candidates.append(value)
            for key in (
                "response",
                "result",
                "images",
                "generatedImages",
                "predictions",
                "outputs",
                "mediaAssets",
                "assets",
                "media",
                "image",
            ):
                child = value.get(key)
                if isinstance(child, (dict, list)):
                    collect(child, depth=depth + 1)

        collect(payload)
        result: list[GeneratedImage] = []
        seen: set[str] = set()
        for item in candidates:
            fife = item.get("fifeUrl") or item.get("url") or item.get("downloadUrl")
            image_id = str(
                item.get("mediaId")
                or item.get("name")
                or item.get("id")
                or fife
                or f"img_{len(result)}"
            )
            identity = str(fife or image_id)
            if identity in seen:
                continue
            seen.add(identity)
            raw_dims = item.get("dimensions")
            dims: dict[str, Any] = raw_dims if isinstance(raw_dims, dict) else {}
            result.append(
                GeneratedImage(
                    image_id=image_id,
                    prompt=prompt,
                    fife_url=str(fife) if fife else None,
                    width=int(dims.get("width") or item.get("width") or 1024),
                    height=int(dims.get("height") or item.get("height") or 1024),
                    raw=item,
                )
            )
        return result

    async def wait_for_images(
        self,
        job: VideoJob,
        count: int,
        timeout: int = 300,
        poll_interval: int = 5,
    ) -> list[GeneratedImage]:
        """Wait for all requested images belonging to one strongly identified job."""
        import json as _json

        from flow_cli._job_state import JobIdentity

        identity = JobIdentity(
            project_id=job.project_id,
            workflow_id=job.workflow_id,
            operation_name=job.operation_name,
            media_id=job.media_id,
            resource_name=job.resource_name,
            prompt=job.prompt,
            prompt_hash=job.prompt_hash,
            media_type="image",
            model=job.model,
        )
        if not (
            identity.operation_name
            or identity.workflow_id
            or identity.media_id
            or identity.resource_name
        ):
            raise UpstreamChangedError(
                f"No strong identifier for image job {job.job_id}; refusing to match history "
                "by recency"
            )

        initial = self._images_from_payload(job.raw, job.prompt)
        if len(initial) >= count:
            return initial[:count]

        deadline = time.monotonic() + timeout
        completed: list[GeneratedImage] = initial
        while time.monotonic() < deadline:
            candidates: list[dict[str, Any]] = []
            if job.operation_name:
                try:
                    operation = await asyncio.to_thread(self.api.get_operation, job.operation_name)
                    operation_images = self._images_from_payload(operation, job.prompt)
                    if len(operation_images) > len(completed):
                        completed = operation_images
                    if len(completed) >= count:
                        return completed[:count]
                    error = operation.get("error")
                    if error:
                        raise GenerationError(f"Image operation failed: {error}")
                except (requests.ConnectionError, requests.Timeout) as exc:
                    log.warning("image_poll_transient_error", error=str(exc), job_id=job.job_id)
                except requests.HTTPError as exc:
                    # Some deployments do not expose the LRO GET endpoint to
                    # this session. Continue with the identity-scoped project
                    # and history fallbacks below.
                    log.warning("image_operation_poll_error", error=str(exc), job_id=job.job_id)
            if job.project_id:
                adapter = current_adapter()
                url = f"{adapter.endpoints.trpc_base}/flow.projectInitialData"
                params = {"input": _json.dumps({"json": {"projectId": job.project_id}})}
                try:
                    resp = await asyncio.to_thread(
                        self.api.session.get, url, params=params, timeout=10
                    )
                    resp.raise_for_status()
                    data = resp.json()
                    media = (
                        data.get("result", {})
                        .get("data", {})
                        .get("json", {})
                        .get("projectContents", {})
                        .get("media", [])
                    )
                    if isinstance(media, list):
                        candidates.extend(item for item in media if isinstance(item, dict))
                except (requests.ConnectionError, requests.Timeout) as exc:
                    log.warning("image_poll_transient_error", error=str(exc), job_id=job.job_id)

            try:
                history = await asyncio.to_thread(
                    self.api.fetch_workflows,
                    media_type="IMAGE",
                    limit=20,
                    project_id=job.project_id,
                )
                candidates.extend(history)
            except (requests.ConnectionError, requests.Timeout) as exc:
                log.warning("image_poll_transient_error", error=str(exc), job_id=job.job_id)

            for candidate in candidates:
                matches, _missing = identity.matches(candidate)
                if not matches:
                    continue
                state = str(
                    candidate.get("state")
                    or candidate.get("status")
                    or candidate.get("media", {}).get("state")
                    or ""
                ).upper()
                if state in {"FAILED", "ERROR", "MEDIA_GENERATION_STATUS_FAILED"}:
                    raise GenerationError(
                        str(candidate.get("error") or candidate.get("failureReason") or state)
                    )
                found = self._images_from_payload(candidate, job.prompt)
                if len(found) > len(completed):
                    completed = found
                if len(completed) >= count:
                    return completed[:count]

            await asyncio.sleep(poll_interval)

        raise GenerationTimeout(
            f"Image generation timed out after {timeout}s (job={job.job_id}); "
            f"requested={count}, completed={len(completed)}"
        )

    # ---------- Batch (browser reuse, continue-after-error, report) ----------

    async def run_batch(
        self,
        jobs: list[Any],
        headless: bool = True,
        timeout: int = 300,
        out_dir: str | Path = "./output",
        poll_interval: int = 5,
    ) -> list[dict[str, Any]]:
        """Run a batch sequentially, reusing one browser context.

        Each job uses its own page reset to a known state. A failed job does not
        abort the batch; per-job results are collected into a summary report.

        For videos, the job is submitted, then polled to COMPLETION and the
        media downloaded; ok=True is only reported once the media exists and,
        when possible, has been downloaded successfully. Images are downloaded
        to out_dir too. Returns a list of dicts: {index, id, prompt, media_type,
        ok, job_id, media_name, files, error}.
        """
        from flow_cli._browser import BrowserManager
        from flow_cli._exceptions import FlowError

        out_dir_path = Path(out_dir)
        out_dir_path.mkdir(parents=True, exist_ok=True)
        report: list[dict[str, Any]] = []
        async with BrowserManager(
            headless=headless,
            cookies=self.cookies,
            raw_cookies=getattr(self, "raw_cookies", None),
        ) as manager:
            for index, item in enumerate(jobs):
                if not isinstance(item, dict):
                    report.append(
                        {
                            "index": index,
                            "id": None,
                            "prompt": None,
                            "media_type": "video",
                            "ok": False,
                            "job_id": None,
                            "media_name": None,
                            "files": [],
                            "error": "batch item is not an object",
                        }
                    )
                    continue
                prompt = item.get("prompt", "")
                media_type = item.get("media_type", item.get("type", "video"))
                entry: dict[str, Any] = {
                    "index": index,
                    "id": item.get("id"),
                    "prompt": prompt,
                    "media_type": media_type,
                    "ok": False,
                    "job_id": None,
                    "media_name": None,
                    "files": [],
                    "error": None,
                }
                job_id: str | None = None
                try:
                    # One deadline per job: generation/capture AND follow-up
                    # polling must share the same `timeout`, so the media is
                    # done inside the configured overall time, never ~2x it.
                    job_start = time.monotonic()
                    result = await self._generate_via_browser(
                        prompt=prompt,
                        aspect=item.get("aspect", "16:9" if media_type == "video" else "1:1"),
                        model=item.get(
                            "model",
                            DEFAULT_VIDEO_MODEL if media_type == "video" else "nano-banana-pro",
                        ),
                        duration=int(item.get("duration", 8)),
                        image_path=item.get("image_path") or item.get("image"),
                        headless=headless,
                        timeout=timeout,
                        media_type=media_type,
                        count=int(item.get("count", 1)),
                        manager=manager,
                    )
                    if media_type == "video" and isinstance(result, VideoJob):
                        job_id = result.job_id
                        entry["job_id"] = job_id
                        entry["media_name"] = result.media_name
                        # VIDEO: success only counts once the media is COMPLETED
                        # (and downloaded). Wait_with identity -> download.
                        remaining = timeout - (time.monotonic() - job_start)
                        if remaining <= 0:
                            raise GenerationTimeout(
                                f"Batch job deadline exceeded after {timeout}s (job={job_id})"
                            )
                        done = await self.wait_for_video(
                            result,
                            timeout=int(remaining),
                            poll_interval=poll_interval,
                        )
                        # Download with verification; only mark OK on success.
                        try:
                            dl_files = await self.download(done.raw, dest_dir=out_dir_path)
                        except Exception as e:
                            entry["error"] = (
                                f"generated but download failed: {type(e).__name__}: {e}"
                            )
                            report.append(entry)
                            continue
                        if not dl_files:
                            entry["error"] = "generated but no downloadable media URL found"
                            report.append(entry)
                            continue
                        entry["files"] = [str(p) for p in dl_files]
                        entry["media_name"] = done.media_name
                        entry["ok"] = True
                    elif media_type == "image" and isinstance(result, list):
                        job_id = f"img_{index}"
                        entry["job_id"] = job_id
                        entry["media_name"] = f"{len(result)} image(s)"
                        files: list[str] = []
                        for img in result:
                            if img.fife_url:
                                from flow_cli._downloader import download_file

                                dest = out_dir_path / f"img_{index}_{img.image_id}.png".replace(
                                    "/", "_"
                                )
                                try:
                                    p = download_file(
                                        img.fife_url, dest, cookies=self.cookies, kind="image"
                                    )
                                    files.append(str(p))
                                except Exception as e:
                                    entry["error"] = f"image download failed: {e}"
                        entry["files"] = files
                        # Images with fife URLs are only "ok" if every one downloaded.
                        total_images = sum(1 for img in result if img.fife_url)
                        downloaded_all = len(files) == total_images
                        entry["ok"] = (
                            bool(result)
                            and not entry["error"]
                            and (total_images == 0 or downloaded_all)
                        )
                    else:
                        raise GenerationError(
                            f"Unexpected generation result type for {media_type}: {type(result)}"
                        )
                except FlowError as e:
                    entry["error"] = f"{type(e).__name__}: {e}"
                except Exception as e:
                    entry["error"] = f"{type(e).__name__}: {e}"
                report.append(entry)
        return report

    # ---------- Polling (with job identity + no swallowed errors) ----------

    async def wait_for_video(
        self,
        job: VideoJob,
        timeout: int = 300,
        poll_interval: int = 5,
    ) -> VideoJob:
        """Poll project until video media is ready.

        Errors are classified: transient network errors are retried; terminal
        failures raise GenerationError; auth/lifecycle errors propagate.
        """
        import json as _json

        from flow_cli._job_state import JobIdentity

        start = time.time()
        deadline = start + timeout

        # Identity is resolved once; polling only ever accepts media that matches
        # this job via a STRONG identifier (workflow_id / operation_name /
        # media_id). A shared project_id is NOT sufficient evidence.
        identity = JobIdentity(
            project_id=job.project_id,
            workflow_id=job.workflow_id,
            operation_name=job.operation_name,
            media_id=job.media_id,
            resource_name=job.resource_name,
            prompt=job.prompt,
            prompt_hash=job.prompt_hash,
            media_type=job.media_type,
            model=job.model,
        )
        if (
            identity.operation_name is None
            and identity.workflow_id is None
            and identity.media_id is None
            and identity.resource_name is None
        ):
            raise UpstreamChangedError(
                f"No strong identifier (workflow/operation/media_id) for job "
                f"{job.job_id}; refusing to guess which media is ours."
            )

        def matched_media(contents: list[Any]) -> dict[str, Any] | None:
            for media in contents:
                if not isinstance(media, dict):
                    continue
                ok, _missing = identity.matches(media)
                if ok:
                    return media
            return None

        while time.time() < deadline:
            # --- projectInitialData polling (identity-scoped) ---
            try:
                if job.project_id:
                    adapter = current_adapter()
                    url = f"{adapter.endpoints.trpc_base}/flow.projectInitialData"
                    params = {"input": _json.dumps({"json": {"projectId": job.project_id}})}
                    resp = await asyncio.to_thread(
                        self.api.session.get, url, params=params, timeout=10
                    )
                    if resp.status_code == 200:
                        data = resp.json()
                        proj_data = data.get("result", {}).get("data", {}).get("json", {})
                        contents = proj_data.get("projectContents", {}).get("media", []) or []
                        media = matched_media(contents if isinstance(contents, list) else [])
                        if media is not None:
                            status = (
                                media.get("mediaMetadata", {})
                                .get("mediaStatus", {})
                                .get("mediaGenerationStatus")
                            )
                            if status == "MEDIA_GENERATION_STATUS_SUCCESSFUL":
                                job.status = "SUCCEEDED"
                                job.media_name = media.get("name", job.media_name)
                                job.resource_name = media.get("name") or job.resource_name
                                job.workflow_id = media.get("workflowId") or job.workflow_id
                                generation_id = media.get("mediaGenerationId")
                                if isinstance(generation_id, dict):
                                    job.media_id = (
                                        generation_id.get("mediaId")
                                        or generation_id.get("id")
                                        or job.media_id
                                    )
                                job.raw = media
                                return job
                            elif status in ("MEDIA_GENERATION_STATUS_FAILED", "FAILED"):
                                job.status = "FAILED"
                                job.error = "Video generation failed"
                                raise GenerationError(job.error)
            except (requests.ConnectionError, requests.Timeout) as exc:
                log.warning("poll_transient_error", error=str(exc), job_id=job.job_id)
                await asyncio.sleep(poll_interval)
                continue
            except requests.HTTPError as exc:
                if exc.response is not None and exc.response.status_code == 429:
                    raise
                raise
            except AuthError:
                raise
            except GenerationError:
                raise
            except Exception as exc:
                # Schema/unexpected: never swallow silently - surface as upstream change.
                log.error("poll_project_error", job_id=job.job_id, error=str(exc))
                raise UpstreamChangedError(
                    f"Unexpected error while polling project initial data: {exc}"
                ) from exc

            # --- history polling (identity-scoped) ---
            try:
                workflows = await asyncio.to_thread(
                    self.api.fetch_workflows,
                    media_type="VIDEO",
                    limit=20,
                    project_id=job.project_id,
                )
                target = matched_media(workflows)
                if target:
                    media = target.get("media", {})
                    fife = (
                        media.get("fifeUrl") or target.get("fifeUrl") or target.get("downloadUrl")
                    )
                    state = (
                        target.get("state")
                        or target.get("status")
                        or media.get("state")
                        or ("SUCCEEDED" if fife else "RUNNING")
                    )
                    if state in ("SUCCEEDED", "COMPLETED", "DONE") and fife:
                        job.status = "SUCCEEDED"
                        job.media_name = target.get("name", job.media_name)
                        job.resource_name = target.get("name") or job.resource_name
                        job.workflow_id = target.get("workflowId") or job.workflow_id
                        generation_id = target.get("mediaGenerationId")
                        if isinstance(generation_id, dict):
                            job.media_id = (
                                generation_id.get("mediaId")
                                or generation_id.get("id")
                                or job.media_id
                            )
                        job.raw = target
                        return job
                    if state in ("FAILED", "ERROR"):
                        job.status = "FAILED"
                        job.error = str(
                            target.get("error")
                            or target.get("failureReason")
                            or "Generation failed"
                        )
                        raise GenerationError(job.error)
            except AuthError:
                raise
            except GenerationError:
                raise
            except (requests.ConnectionError, requests.Timeout) as exc:
                log.warning("poll_transient_error", error=str(exc), job_id=job.job_id)
            except Exception as exc:
                # Schema/unexpected: never swallow silently - surface as upstream change.
                log.error("poll_history_error", job_id=job.job_id, error=str(exc))
                raise UpstreamChangedError(
                    f"Unexpected error while polling history: {exc}"
                ) from exc

            await asyncio.sleep(poll_interval)

        raise GenerationTimeout(f"Video generation timed out after {timeout}s (job={job.job_id})")

    async def download(self, workflow: dict[str, Any], dest_dir: str | Path) -> list[Path]:
        from flow_cli._downloader import download_media_from_workflow

        return await asyncio.to_thread(
            download_media_from_workflow, workflow, dest_dir, cookies=self.cookies
        )

    async def download_url(
        self,
        url: str,
        dest_dir: str | Path,
        media_type: str,
        allowed_hosts: set[str],
    ) -> Path:
        from flow_cli._downloader import download_file

        suffix = ".mp4" if media_type == "video" else ".png"
        destination = Path(dest_dir) / f"download{suffix}"
        return await asyncio.to_thread(
            download_file,
            url,
            destination,
            cookies=self.cookies,
            kind=media_type,
            allowed_hosts=allowed_hosts,
        )

    # Sync wrappers for CLI convenience
    def get_credits_sync(self) -> Credits:
        return asyncio.run(self.get_credits())

    def fetch_history_sync(
        self, media_type: str = "VIDEO", limit: int = 20
    ) -> list[dict[str, Any]]:
        return asyncio.run(self.fetch_history(media_type=media_type, limit=limit))
